@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 goto error
)
rem Install only when requirements changed, including after an application update.
.venv\Scripts\python.exe -c "import hashlib,pathlib,sys; p=pathlib.Path('.venv/astroguru-requirements.sha256'); digest=hashlib.sha256(pathlib.Path('requirements.txt').read_bytes()).hexdigest(); sys.exit(0 if p.exists() and p.read_text()==digest else 1)"
if errorlevel 1 (
  echo Preparing Astroguru dependencies. Internet is required for this step.
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto error
  .venv\Scripts\python.exe -c "import hashlib,pathlib; pathlib.Path('.venv/astroguru-requirements.sha256').write_text(hashlib.sha256(pathlib.Path('requirements.txt').read_bytes()).hexdigest())"
  if errorlevel 1 goto error
)
.venv\Scripts\python.exe app.py
if errorlevel 1 goto error
exit /b 0
:error
 echo Astroguru could not start. Confirm Python 3.12 x64 is installed.
 echo See README.md for setup and troubleshooting.
 pause
 exit /b 1
