"""Documented baseline North Indian Ashtakoota. Explicit roles, no exceptions."""
from core import manglik, aspects
from matching_tables import *
NADI=[0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2]
GANA=[0,1,2,1,0,1,0,0,2,2,1,1,0,2,0,2,0,2,2,1,1,0,2,2,1,1,0]
MEANINGS={'Varna':'Traditional symbolic disposition ranking; not a measure of human worth or social caste.','Vashya':'Traditional symbolic responsiveness and influence.','Tara':'Nakshatra-based supportive rhythms; not a prediction of health or lifespan.','Yoni':'Traditional animal-symbol affinity; not a factual claim about sexuality.','Graha Maitri':'Symbolic friendship of Moon-sign rulers and communication style.','Gana':'Traditional temperament categories.','Bhakoot':'Relative Moon-sign relationship and household themes.','Nadi':'Traditional constitutional grouping; no fertility, genetic, or medical inference.'}

def vashya(moon):
    if 'vashya_category' in moon:return moon['vashya_category']
    sign=moon['sign'];degree=moon['degree']
    if sign in [0,1] or (sign==8 and degree>=15) or (sign==9 and degree<15):return 0
    if sign in [2,5,6,10] or (sign==8 and degree<15):return 1
    if sign in [3,11] or sign==9:return 2
    if sign==4:return 3
    return 4

def score_moons(groom,bride):
    """Role names are traditional table columns, not inferred personal identities."""
    a=groom['sign'];b=bride['sign'];na=groom['nakshatra_index'];nb=bride['nakshatra_index']
    # Inclusive counting in both directions. 3,5,7 are adverse residues.
    tara=sum(1.5 for x,y in [(na,nb),(nb,na)] if ((y-x)%27+1)%9 not in [3,5,7])
    distance=(b-a)%12+1
    values=[('Varna',VarnaArray[vasiya_raasi_list[b]][vasiya_raasi_list[a]],1),('Vashya',VasiyaArray[vashya(bride)][vashya(groom)],2),('Tara',tara,3),('Yoni',YoniArray[yoni_mappings[nb]][yoni_mappings[na]],4),('Graha Maitri',raasi_adhipathi_array[raasi_adhipathi_mappings[b]][raasi_adhipathi_mappings[a]],5),('Gana',gana_array[GANA[nb]][GANA[na]],6),('Bhakoot',0 if distance in [2,12,5,9,6,8] else 7,7),('Nadi',NadiArray[NADI[nb]][NADI[na]],8)]
    return [{'factor':name,'score':score,'maximum':maximum,'meaning':MEANINGS[name]} for name,score,maximum in values]

def match(a,b,role_a,options=None):
    if role_a not in ['groom','bride']:raise ValueError('Explicitly assign the traditional bride/groom table roles.')
    options=options or {}
    usable=bool(a.get('matching_moon')) and bool(b.get('matching_moon')) and a.get('moon_stable',False) and b.get('moon_stable',False)
    factors=score_moons(a['matching_moon'],b['matching_moon']) if usable and role_a=='groom' else score_moons(b['matching_moon'],a['matching_moon']) if usable else []
    out={'tradition':'Baseline North Indian Ashtakoota; Saravali-style tables as published by PyJHora; inclusive Tara counting','role_a':role_a,'role_b':'bride' if role_a=='groom' else 'groom','pairing_limitation':'The source tradition uses bride/groom roles. Operator-assigned roles permit symbolic comparison but do not establish validation for pairings outside that tradition. Roles are never inferred from names or gender.','reference':'See RULES.md and matching_tables.py. Exceptions/cancellations: none.','factors':factors,'total':sum(x['score'] for x in factors) if factors else None,'maximum':36,'manglik':[manglik(a),manglik(b)],'options':options,'warning':'Traditional compatibility points are not a probability of marriage success. Never decide to marry or reject a partner solely from these results.'}
    out['accuracy_explanation']='A single Ashtakoota score is shown only when Moon sign, nakshatra and Vashya category remain stable throughout each stated uncertainty interval (sampled every 15 minutes or less). Ascendant, D9 and precise dasha timing require confirmed time.'
    if not usable:out['unavailable_reason']='Confirmed Moon sign and nakshatra required. Unknown time or a Moon boundary within the stated uncertainty prevents a single score.'
    if options.get('western') and a.get('tropical') and b.get('tropical'):out['western_synastry']=aspects(a['tropical'],b['tropical'])
    if options.get('numerology'):out['numerology']={'a':a.get('numerology'),'b':b.get('numerology'),'meaning':'Separate Pythagorean reflection; no contribution to Guna Milan.'}
    return out
