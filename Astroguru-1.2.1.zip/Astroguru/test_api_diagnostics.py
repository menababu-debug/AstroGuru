"""Offline regression checks; never send client data or billable requests."""
from types import SimpleNamespace
import pytest
from ai import Provider,validate_section,request_error

@pytest.mark.parametrize('body',['Outcomes are not guaranteed. Choices and circumstances matter.','No outcomes are guaranteed. Consider practical reflection.','There are no guaranteed outcomes. Discuss needs openly.'])
def test_negated_guarantee_is_allowed(body):
    assert validate_section({'title':'Reflection','body':body},'Reflection')

@pytest.mark.parametrize('body',['A successful marriage is guaranteed by this reading.','There is a 72% chance of success in marriage.','There is a 72.5% chance of success in marriage.'])
def test_claimed_guarantees_and_percentages_are_rejected(body):
    with pytest.raises(ValueError):validate_section({'title':'Reflection','body':body},'Reflection')

def test_quota_failure_does_not_retry_or_expose_error_content():
    class QuotaError(Exception):
        status_code=429
        body={'error':{'code':'insufficient_quota','message':'SECRET KEY AND CLIENT CONTENT'}}
    class Fake(Provider):
        attempts=0
        def call(self,title,data):self.attempts+=1;raise QuotaError()
    provider=Fake('OpenAI','model','SECRET')
    with pytest.raises(RuntimeError,match='API billing') as error:provider.section('Reflection',{})
    assert provider.attempts==1 and 'SECRET' not in str(error.value)

@pytest.mark.parametrize('status,expected',[(401,'key rejected'),(403,'Access denied'),(404,'Model unavailable'),(400,'structured JSON'),(429,'Rate limit')])
def test_status_errors_are_actionable_and_redacted(status,expected):
    error=Exception('PRIVATE DATA');error.status_code=status
    message,_=request_error('Gemini',error)
    assert expected in message and 'PRIVATE DATA' not in message

def test_progress_reports_response_even_if_invalid():
    provider=Provider('OpenAI','model','unused');events=[];provider.progress=events.append
    with pytest.raises(ValueError,match='Provider responded'):provider.decode('')
    assert 'response received' in events[0]

def test_connection_test_does_not_depend_on_report_language(monkeypatch):
    import openai
    class Client:
        def __init__(self,**kwargs):self.responses=self
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def create(self,**kwargs):
            assert 'text' not in kwargs and 'client information' in kwargs['input']
            return SimpleNamespace(output_text='OK')
    monkeypatch.setattr(openai,'OpenAI',Client)
    assert Provider('OpenAI','test','unused').test_connection()
