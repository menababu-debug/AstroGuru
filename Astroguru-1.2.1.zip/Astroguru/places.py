"""Offline birthplace suggestions. GeoNames CC BY 4.0; geonamescache MIT."""
from functools import lru_cache
import unicodedata

def normalized(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',value).casefold() if not unicodedata.combining(c)).strip()

@lru_cache(maxsize=1)
def catalog():
    import geonamescache
    cache=geonamescache.GeonamesCache(min_city_population=15000)
    countries=cache.get_countries();rows=[]
    for city in cache.get_cities().values():
        country=countries.get(city['countrycode'],{}).get('name',city['countrycode'])
        rows.append({**city,'country':country,'label':f"{city['name']} · {country} · region {city['admin1code']} ({city['geonameid']})"})
    return sorted(rows,key=lambda row:row['label'].casefold())

@lru_cache(maxsize=1)
def labels():return [row['label'] for row in catalog()]

@lru_cache(maxsize=1)
def by_label():return {row['label']:row for row in catalog()}

def exact_matches(name):return [row for row in catalog() if normalized(row['name'])==normalized(name)]

def online_place(row):
    address=row.get('address',{})
    return {'city':address.get('city') or address.get('town') or address.get('village') or address.get('municipality') or row.get('name',''),
            'state':address.get('state') or address.get('province') or address.get('region',''),
            'country':address.get('country',''),'countrycode':address.get('country_code','').upper(),
            'latitude':float(row['lat']),'longitude':float(row['lon']),'timezone':row.get('timezone',''),'geonameid':None}
