# Official interfaces checked 2026-10-08

- OpenAI SDK: https://github.com/openai/openai-python — Responses API, image inputs, JSON schema structured output; image-generation endpoint with base64 image output.
- OpenAI image generation: https://developers.openai.com/api/reference/python/resources/images/methods/generate — gpt-image-1.5 remains supported; account access is required.
- Google SDK: https://github.com/googleapis/python-genai — generate_content, structured JSON, inline image parts, native image output.
- Gemini keys: https://ai.google.dev/gemini-api/docs/api-key — API key associated with Google Cloud project, obtained via Google AI Studio/Google account.
- Gemini image generation: https://ai.google.dev/gemini-api/docs/image-generation — native image models include gemini-3.1-flash-image; current recommended aliases can change, model selection remains configurable. Retired Imagen endpoints are not adopted for this update.

Adapters use installed/pinned SDKs. Tests fake response transports; no live provider credentials or billable calls were available here.
