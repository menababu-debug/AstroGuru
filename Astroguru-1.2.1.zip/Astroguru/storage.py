"""Encrypted payloads in SQLite; encrypted assets and authenticated backups."""
import os, json, sqlite3, uuid, zipfile, io, datetime, hashlib, tempfile, shutil
from pathlib import Path
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class Store:
    def __init__(self,folder,password):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.assets=self.folder/'assets';self.assets.mkdir(exist_ok=True)
        self.conn=sqlite3.connect(self.folder/'astroguru.db');self.conn.execute('PRAGMA foreign_keys=ON');self.conn.execute('PRAGMA secure_delete=ON')
        self.conn.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY,value BLOB)')
        row=self.conn.execute("SELECT value FROM meta WHERE key='salt'").fetchone()
        salt=bytes(row[0]) if row else os.urandom(16)
        key=Scrypt(salt=salt,length=32,n=2**15,r=8,p=1).derive(password.encode());self.aes=AESGCM(key)
        if row:
            try:self.decrypt(self.conn.execute("SELECT value FROM meta WHERE key='check'").fetchone()[0])
            except Exception:self.conn.close();raise ValueError('Incorrect password or damaged vault.')
        else:
            if len(password)<10:self.conn.close();raise ValueError('Choose a vault password of at least 10 characters.')
            self.conn.execute('INSERT INTO meta VALUES (?,?)',('salt',salt));self.conn.execute('INSERT INTO meta VALUES (?,?)',('check',self.encrypt(b'Astroguru vault v1')))
        self.conn.executescript('''CREATE TABLE IF NOT EXISTS clients(id TEXT PRIMARY KEY,payload BLOB NOT NULL);
          CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,payload BLOB NOT NULL);
          CREATE TABLE IF NOT EXISTS links(report_id TEXT REFERENCES reports(id) ON DELETE CASCADE,client_id TEXT REFERENCES clients(id) ON DELETE CASCADE,PRIMARY KEY(report_id,client_id));''');self.conn.commit()
    def encrypt(self,data):
        nonce=os.urandom(12);return nonce+self.aes.encrypt(nonce,data,b'Astroguru-v1')
    def decrypt(self,data):return self.aes.decrypt(bytes(data[:12]),bytes(data[12:]),b'Astroguru-v1')
    def save(self,table,payload,identifier=None):
        if table not in ['clients','reports']:raise ValueError('Invalid record type')
        identifier=identifier or str(uuid.uuid4());data=self.encrypt(json.dumps(payload,ensure_ascii=False).encode())
        self.conn.execute(f'INSERT INTO {table}(id,payload) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(identifier,data));self.conn.commit();return identifier
    def get(self,table,identifier):
        if table not in ['clients','reports']:raise ValueError('Invalid record type')
        row=self.conn.execute(f'SELECT payload FROM {table} WHERE id=?',(identifier,)).fetchone()
        return json.loads(self.decrypt(row[0])) if row else None
    def all(self,table):
        if table not in ['clients','reports']:raise ValueError('Invalid record type')
        return [(key,json.loads(self.decrypt(data))) for key,data in self.conn.execute(f'SELECT id,payload FROM {table}')]
    def link(self,report_id,clients):
        for client in clients:self.conn.execute('INSERT OR IGNORE INTO links VALUES (?,?)',(report_id,client))
        self.conn.commit()
    def linked_reports(self,client):return [row[0] for row in self.conn.execute('SELECT report_id FROM links WHERE client_id=?',(client,))]
    def duplicates(self,profile):return [key for key,p in self.all('clients') if p['birth_date']==profile['birth_date'] and p['first_name'].casefold()==profile['first_name'].casefold() and p.get('last_name','').casefold()==profile.get('last_name','').casefold()]
    def asset(self,data):
        key=str(uuid.uuid4());(self.assets/key).write_bytes(self.encrypt(data));return key
    def read_asset(self,key):
        if Path(key).name!=key:raise ValueError('Invalid asset ID')
        return self.decrypt((self.assets/key).read_bytes())
    def delete_client(self,key):
        # A matchmaking report contains both profiles: delete the whole linked report.
        for report in self.linked_reports(key):self.conn.execute('DELETE FROM reports WHERE id=?',(report,))
        profile=self.get('clients',key)
        for image in (profile or {}).get('palms',{}).values():
            for field in ['original','aligned']:
                if image.get(field):(self.assets/image[field]).unlink(missing_ok=True)
        self.conn.execute('DELETE FROM clients WHERE id=?',(key,));self.conn.commit();self.prune_assets();self.conn.execute('VACUUM')
    def backup(self,path):
        mem=io.BytesIO()
        with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('records.json',json.dumps({'clients':self.all('clients'),'reports':self.all('reports'),'links':list(self.conn.execute('SELECT * FROM links'))},ensure_ascii=False))
            for p in self.assets.iterdir():z.writestr('assets/'+p.name,self.decrypt(p.read_bytes()))
        # Include salt so this vault's password can also open a backup in a new installation.
        salt=self.conn.execute("SELECT value FROM meta WHERE key='salt'").fetchone()[0]
        Path(path).write_bytes(b'AGBK1'+salt+self.encrypt(mem.getvalue()))
    def restore(self,path,password):
        blob=Path(path).read_bytes()
        if blob[:5]!=b'AGBK1':raise ValueError('Not an Astroguru backup')
        aes=AESGCM(Scrypt(salt=blob[5:21],length=32,n=2**15,r=8,p=1).derive(password.encode()))
        payload=blob[21:];data=aes.decrypt(payload[:12],payload[12:],b'Astroguru-v1')
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            records=json.loads(z.read('records.json'))
            assets={Path(n).name:z.read(n) for n in z.namelist() if n.startswith('assets/')}
        # Validate every record before changing live state; restore atomically in one DB transaction.
        for table in ['clients','reports']:
            for key,p in records[table]:uuid.UUID(key);json.dumps(p)
        for key in assets:uuid.UUID(key)
        # Stage the complete encrypted asset set before touching live records.
        stage=Path(tempfile.mkdtemp(prefix='restore-',dir=self.folder))
        old_assets=self.folder/('assets-old-'+str(uuid.uuid4()))
        swapped=False
        try:
            for key,value in assets.items():(stage/key).write_bytes(self.encrypt(value))
            with self.conn:
                self.conn.execute('DELETE FROM links');self.conn.execute('DELETE FROM reports');self.conn.execute('DELETE FROM clients')
                for table in ['clients','reports']:
                    for key,p in records[table]:self.conn.execute(f'INSERT INTO {table} VALUES (?,?)',(key,self.encrypt(json.dumps(p).encode())))
                for link in records['links']:self.conn.execute('INSERT INTO links VALUES (?,?)',link)
                self.assets.rename(old_assets)
                try:stage.rename(self.assets)
                except Exception:old_assets.rename(self.assets);raise
                swapped=True
        except Exception:
            if swapped:
                shutil.rmtree(self.assets);old_assets.rename(self.assets)
            raise
        finally:
            if stage.exists():shutil.rmtree(stage)
        if old_assets.exists():shutil.rmtree(old_assets)
    def prune_assets(self):
        referenced=set()
        for table in ['clients','reports']:
            for key,record in self.all(table):
                if table=='reports' and record.get('artwork',{}).get('asset'):referenced.add(record['artwork']['asset'])
                profiles=[record] if table=='clients' else [c.get('profile',{}) for c in record.get('calculations',[])]
                for profile in profiles:
                    for palm in profile.get('palms',{}).values():
                        for field in ['original','aligned']:
                            if palm.get(field):referenced.add(palm[field])
        for path in self.assets.iterdir():
            if path.name not in referenced:path.unlink()
    def close(self):self.conn.close();self.aes=None
