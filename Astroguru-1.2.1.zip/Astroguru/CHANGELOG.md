# Astroguru 1.2.1

Fix silent local-template submission: saving a new API key enables automatic generation for natal and matchmaking workflows; local-only and cancelled-consent paths explain that no request was sent. Show request/response progress, independent minimal connection testing and actionable redacted billing, credential, model and network errors. Do not retry exhausted OpenAI credit quota. Accept negated guarantee disclaimers while rejecting guarantees and fabricated percentages. Invalid/truncated JSON is identified as a received response. 78 offline regression tests passed; live account access remains unverified.

# Astroguru 1.2.0

Automatic detailed OpenAI/Gemini report generation after explicit submission consent; all appropriate life domains and every locally bounded year; optional voluntary client context, separately consented aligned palm-photo observations and decorative AI cover artwork; original fact tables and scores preserved; resumable section checkpoints and automatic PDF output; Google AI Studio account/key setup shortcut and honest manual Gemini website fallback. API credentials and real account/model access are required for live generation. Windows binaries remain unbuilt in this Linux environment.

# Astroguru 1.1.0

Updated intake and desktop styling. Separate right/left palm pages with explicit client-hand labels; rectangular clipping and no mirroring; local background removal with tolerance, preview, restoration and preserved original; ten-step wizard and five-page client editor; automatic country from offline city selection, with manual correction and historical timezone verification.

Vault encryption/format and data location remain compatible with 1.0.0. Existing photos are not silently swapped. Original generated report versions remain preserved. Windows binary compilation and real-printer testing are still unverified in this Linux environment.
