"""Local, deterministic plain-background removal. No model or upload required."""
import io
import numpy as np
from PIL import Image,ImageDraw

def clear_background(data,tolerance=35):
    if not 5<=tolerance<=100:raise ValueError('Background tolerance must be between 5 and 100.')
    image=Image.open(io.BytesIO(data)).convert('RGBA');image.thumbnail((2000,2000))
    rgba=np.array(image);rgb=rgba[:,:,:3].astype(np.int16)
    border=np.concatenate((rgb[0],rgb[-1],rgb[:,0],rgb[:,-1]))
    background=np.median(border,axis=0)
    candidate=(np.max(np.abs(rgb-background),axis=2)<=tolerance).astype(np.uint8)*255
    mask=Image.fromarray(candidate).copy();width,height=image.size
    # Only similar pixels connected to an image edge are removed. Interior detail is retained.
    for x in range(width):
        for y in (0,height-1):
            if mask.getpixel((x,y))==255:ImageDraw.floodfill(mask,(x,y),128,thresh=0)
    for y in range(height):
        for x in (0,width-1):
            if mask.getpixel((x,y))==255:ImageDraw.floodfill(mask,(x,y),128,thresh=0)
    removed=np.array(mask)==128
    if not removed.any():raise ValueError('No plain border background found. Try a different tolerance or keep the original.')
    rgba[removed,3]=0
    buffer=io.BytesIO();Image.fromarray(rgba).save(buffer,format='PNG');return buffer.getvalue()
