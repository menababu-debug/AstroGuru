# Licensing and commercial distribution

Checked against current PyPI metadata and official upstream repositories on **2026-10-08**. Versioned requirements record tested versions, even where a newer release exists. Full metadata, official OpenAI/Gemini SDK README snapshots and reference hashes are in `references/`.

This Astroguru source release is **AGPL-3.0-or-later**, provided without warranty. Commercial use and charging for consultations are permitted under those terms; redistribution and applicable network deployment require corresponding-source availability and notices. It is not a closed-source license.

| Dependency | License / commercial consideration |
|---|---|
| Swiss Ephemeris / pyswisseph | AGPL-3.0 with Swiss Ephemeris professional commercial licensing alternatives. This distribution uses the AGPL path. Proprietary deployment requires a suitable license AND independently resolving PyJHora table rights. |
| PyJHora reference tables | AGPL-3.0-or-later. Copyright Open Astro Technologies; modified by Sundar Sundaresan. Full license and original reference snapshot included. |
| PySide6 / Qt | LGPL-3.0 / GPL alternatives. Dynamic one-directory packaging preserves replaceable libraries; retain notices, permit lawful replacement and supply required source information. Review Qt module notices for the exact distribution. |
| SQLite / Python | SQLite public domain; Python PSF license. |
| Pillow | MIT-CMU. |
| ReportLab | BSD-style license; installed 4.4.9 verified (newer 5.0.1 metadata also recorded). |
| cryptography | Apache-2.0 / BSD-3-Clause. |
| keyring | MIT. |
| OpenAI Python SDK / Google GenAI SDK | Apache-2.0. API service agreements, privacy terms and usage charges are separate from SDK licenses. |
| Pydantic | MIT. |
| tzdata | Apache-2.0 packaged IANA data; retain bundled notices. |
| TimezoneFinder | MIT code. |
| geonamescache 3.0.2 | MIT code; included GeoNames city/country data is CC BY 4.0. Attribution: GeoNames (geonames.org). See included license and upstream README snapshots. |
| NumPy 2.3.5 | BSD-3-Clause code plus bundled dependency notices. Retain installed package notices in frozen builds. |
| timezonefinder-data | ODbL 1.0 database; attribute timezone-boundary-builder/OpenStreetMap contributors and preserve applicable database/license obligations. Current boundaries are suggestions requiring historical verification. |
| PyInstaller | GPL with bootloader exception allowing commercial application bundling. |
| Inno Setup | Upstream Inno Setup license permits commercial installer creation; install a current supported Inno Setup 6 distribution and retain applicable notices. |

No Swiss `.se1` files are downloaded or redistributed. Built-in Moshier ephemeris is explicitly identified in saved calculations. An ephemeris professional license does not remove the AGPL status of adapted PyJHora tables; a proprietary edition would need independently licensed/reimplemented matching tables too.

Geocoding attribution: **© OpenStreetMap contributors**; public Nominatim service policy applies. Coordinate-to-zone suggestion data attribution: **timezone-boundary-builder, OpenStreetMap contributors**. Include the package's ODbL notices when distributing its bundled data.

Before shipping a commercial installer, audit the generated bundle's third-party notices and dependency licenses, provide corresponding source, and verify Windows installation on the target platform. This application is not represented as proprietary-ready merely because Python packages install successfully.

Offline birthplace suggestions: **GeoNames, https://www.geonames.org/**, licensed **CC BY 4.0**, https://creativecommons.org/licenses/by/4.0/. Astroguru derives display labels and country mappings from the dataset; coordinates are suggestions rather than historical boundary verification. geonamescache code is MIT.
