import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import datetime as dt,json,io,threading,xml.etree.ElementTree as ET
import pytest
import core,charts,matching,reports,ai
from storage import Store
from PIL import Image

@pytest.fixture
def profile():return dict(first_name='Fictional',last_name='Example',current_name='',birth_date='1990-01-01',birth_time='12:00:00',accuracy='exact',latitude=28.6139,longitude=77.209,timezone='Asia/Kolkata',city='New Delhi',country='India',location_verified=True,notes='',dominant_hand='Right')
@pytest.fixture
def settings():return dict(as_of='2026-10-08',ayanamsa='Lahiri',western_house_system='P')
@pytest.fixture
def calc(profile,settings):return core.calculate(profile,settings)
@pytest.fixture(scope='session')
def qapp():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])

@pytest.mark.parametrize('years,expected',[(0,5),(26,5),(27,10),(30,10),(31,12),(35,12),(36,15),(40,15),(41,25),(45,25),(46,27),(49,27),(50,30),(70,30),(90,30)])
def test_age_bands(years,expected):assert core.lookback(years)==expected
@pytest.mark.parametrize('birth,asof,expected',[('2000-10-09','2026-10-08',25),('2000-10-08','2026-10-08',26),('2000-02-29','2025-02-27',24),('2000-02-29','2025-02-28',25)])
def test_completed_age(birth,asof,expected):assert core.age(dt.date.fromisoformat(birth),dt.date.fromisoformat(asof))==expected

def test_horizons():
    h=core.horizons(dt.date(2024,5,3),dt.date(2026,10,8));assert h['history'][0]['start']=='2024-05-03';assert h['history'][-1]['end']=='2026-10-08';assert h['future_end']=='2061-10-08'
    h=core.horizons(dt.date(1960,2,29),dt.date(2026,10,8));assert h['future_end']=='2030-02-28'
    assert core.horizons(dt.date(1956,10,8),dt.date(2026,10,8))['future']==[]

def test_invalid_dates(profile,settings):
    with pytest.raises(ValueError):core.validate(dict(profile,birth_date='2023-02-29'))
    with pytest.raises(ValueError):core.validate(dict(profile,birth_date='2099-01-01'))
    with pytest.raises(ValueError):core.calculate(profile,dict(settings,as_of='1989-12-31'))

def test_timezone(profile):
    assert core.utc_time(profile).isoformat()=='1990-01-01T06:30:00+00:00'
    summer=dict(profile,birth_date='2020-07-01',timezone='America/New_York');assert core.utc_time(summer).hour==16
    winter=dict(summer,birth_date='2020-01-01');assert core.utc_time(winter).hour==17
    with pytest.raises(ValueError):core.utc_time(dict(summer,birth_date='2020-03-08',birth_time='02:30:00'))
    with pytest.raises(ValueError):core.utc_time(dict(summer,birth_date='2020-11-01',birth_time='01:30:00'))
    first=core.utc_time(dict(summer,birth_date='2020-11-01',birth_time='01:30:00',fold=0,fold_confirmed=True));second=core.utc_time(dict(summer,birth_date='2020-11-01',birth_time='01:30:00',fold=1,fold_confirmed=True));assert second-first==dt.timedelta(hours=1)
    historical=dict(profile,birth_date='1943-07-01');assert core.utc_time(historical).hour==5 and core.utc_time(historical).minute==30

def test_numerology(profile):
    n=core.numerology(dict(profile,first_name='John',last_name='Doe'),2026)
    assert n['Life Path']['total']==21 and n['Life Path']['number']==3
    assert n['birth_name']['Expression']['total']==35 and n['birth_name']['Expression']['number']==8
    assert n['birth_name']['Soul Urge']['total']==17 and n['birth_name']['Personality']['total']==18
    assert core.spelling('Éva O’Neil')=='EVAONEIL'
    assert core.reduce_number(29)['number']==11
    assert core.reduce_number(33)['number']==33
    assert core.reduce_number(29,False)['number']==2

def test_j2000_ephemeris_reference():
    # Published Swiss Ephemeris J2000 ecliptic positions (Moshier).
    sun=core.swe.calc_ut(2451545,core.swe.SUN,core.swe.FLG_MOSEPH)[0][0]
    moon=core.swe.calc_ut(2451545,core.swe.MOON,core.swe.FLG_MOSEPH)[0][0]
    assert sun==pytest.approx(280.36892,abs=.0001);assert moon==pytest.approx(223.32378,abs=.0001)

def test_sidereal_and_d9(calc):
    for name,p in calc['vedic'].items():
        diff=(calc['tropical'][name]['longitude']-p['longitude'])%360
        assert diff==pytest.approx(calc['ayanamsa_degrees'],abs=.001)
        assert p['navamsha_sign']==int(p['longitude']/(10/3))%12
        assert 1<=p['house']<=12 and 1<=p['pada']<=4
    assert len(calc['dashas'])==10
    for row in calc['dashas']:assert len(row['antardashas'])==9 and abs((dt.datetime.fromisoformat(row['end'])-dt.datetime.fromisoformat(row['antardashas'][-1]['end'])).total_seconds())<1

def test_unknown_approximate(profile,settings):
    unknown=core.calculate(dict(profile,accuracy='unknown',birth_time=''),settings)
    assert unknown['ascendant'] is None and not unknown['vedic'] and not unknown['dashas'] and not unknown['d9_allowed']
    assert 'possible' in reports.placement_lines(unknown)
    approx=core.calculate(dict(profile,accuracy='approximate',uncertainty_minutes=60),settings)
    assert not approx['d9_allowed'] and approx['dashas']==[] and approx['warnings']
    assert not core.manglik(approx)['available']
    with pytest.raises(ValueError):charts.svg(approx,division='D9')

def test_guna_reference_examples():
    # Hand-worked baseline examples using the published tables, inclusive Tara.
    ash=core.placement(5);roh=core.placement(45);rev=core.placement(355)
    same=matching.score_moons(ash,ash);assert [r['score'] for r in same]==[1,2,3,4,5,6,7,0]
    r=matching.score_moons(ash,roh);assert [v['score'] for v in r]==[1,2,1.5,3,3,5,0,8];assert sum(v['score'] for v in r)==23.5
    # Asymmetry must follow the explicitly assigned table role.
    reverse=matching.score_moons(roh,ash);assert reverse[0]['score']==0 and reverse[5]['score']==6

def test_score_bounds_exhaustive():
    for na in range(108):
        for nb in range(108):
            a=core.placement((na+.5)*10/3);b=core.placement((nb+.5)*10/3);rows=matching.score_moons(a,b)
            assert len(rows)==8 and all(0<=r['score']<=r['maximum'] for r in rows)
            assert 0<=sum(r['score'] for r in rows)<=36

def test_roles(calc):
    with pytest.raises(ValueError):matching.match(calc,calc,'inferred')
    assert matching.match(calc,calc,'bride')['role_b']=='groom'
    m=matching.match(dict(calc,moon_stable=False),calc,'groom');assert m['total'] is None

def test_storage_and_backup(tmp_path,profile,calc):
    s=Store(tmp_path/'vault','secure-password');key=s.save('clients',profile);assert s.get('clients',key)['first_name']==profile['first_name'];assert s.duplicates(profile)==[key]
    asset=s.asset(b'private-photo');profile['palms']={'right':{'original':asset,'aligned':asset}};s.save('clients',profile,key)
    r=s.save('reports',{'calculations':[calc]});s.link(r,[key]);assert s.linked_reports(key)==[r]
    raw=(tmp_path/'vault'/'astroguru.db').read_bytes();assert b'Fictional' not in raw and b'private-photo' not in raw
    backup=tmp_path/'backup.agbk';s.backup(backup);assert b'Fictional' not in backup.read_bytes();s.delete_client(key);assert not s.all('clients') and not s.all('reports') and not (s.assets/asset).exists()
    s.restore(backup,'secure-password');assert s.get('clients',key)==profile;assert s.read_asset(asset)==b'private-photo';assert s.linked_reports(key)==[r]
    s.close()
    with pytest.raises(ValueError):Store(tmp_path/'vault','wrong-password')
    new=Store(tmp_path/'new-vault','different-password');new.restore(backup,'secure-password');assert new.get('clients',key)==profile;new.close()

def test_tampered_backup(tmp_path,profile):
    s=Store(tmp_path/'v','secure-password');s.save('clients',profile);p=tmp_path/'b';s.backup(p);data=bytearray(p.read_bytes());data[-1]^=1;p.write_bytes(data)
    with pytest.raises(Exception):s.restore(p,'secure-password')
    assert len(s.all('clients'))==1;s.close()

def test_svg_png(calc,tmp_path,qapp):
    for layout in ['North Indian','South Indian']:
        for div in ['D1','D9']:
            value=charts.svg(calc,layout,div);root=ET.fromstring(value);assert len(root.findall('{http://www.w3.org/2000/svg}polygon'))==12
            for name in core.ABBR.values():assert name in value
            p=tmp_path/(layout+div+'.png');charts.png(value,p);assert Image.open(p).size==(1280,1500)

def test_pdf_export(calc,tmp_path):
    from pypdf import PdfReader
    m=matching.match(calc,calc,'groom',{'western':True,'numerology':True})
    for kind in ['natal','matchmaking']:
        cs=[calc] if kind=='natal' else [calc,calc]
        sections=reports.natal_sections(calc) if kind=='natal' else reports.match_sections(calc,calc,m)
        r=dict(id='demonstration',title='Fictional example',kind=kind,as_of=calc['settings']['as_of'],calculations=cs,original_text=reports.text(sections))
        p=tmp_path/(kind+'.pdf');reports.export_pdf(r,p);pdf=PdfReader(p);text=''.join(page.extract_text() for page in pdf.pages);assert len(pdf.pages)>3 and 'Table of contents' in text and 'Final balanced summary' in text
        assert 'Calculated Kundali charts' in text and 'Moon' in text

def test_minors(profile,settings):
    c=core.calculate(dict(profile,birth_date='2015-01-01'),settings);sections=reports.natal_sections(c,intimacy=True);titles=[title for title,_ in sections];assert not any('intimacy' in t.lower() or 'Marriage' in t for t in titles)

def test_ai_minimization(calc):
    data=ai.payload(dict(calculations=[calc],kind='natal'))
    raw=json.dumps(data);assert 'Fictional' not in raw and '1990-01-01' not in raw and 'latitude' not in raw and 'palms' not in raw

def test_ai_validation_and_retries():
    with pytest.raises(ValueError):ai.validate_section({'title':'Wrong','body':'This is a long enough valid sentence.'},'Expected')
    with pytest.raises(ValueError):ai.validate_section({'title':'Expected','body':'Your relationship will divorce guaranteed.'},'Expected')
    class Fake(ai.Provider):
        def __init__(self):super().__init__('OpenAI','test','never-real');self.calls=0
        def call(self,title,data):
            self.calls+=1
            if self.calls<2:
                class Temporary(Exception):status_code=429
                raise Temporary()
            return ai.Section(title=title,body='A safe interpretive reflection for operator review.'),{'tokens':10}
    f=Fake();s,u=f.section('Reflection',{});assert f.calls==2
    f.cancel.set()
    with pytest.raises(InterruptedError):ai.Provider('OpenAI','test','never-real',f.cancel).call('Reflection',{})

def test_desktop_workflow_and_palm(qapp,tmp_path,profile,settings,monkeypatch):
    from app import MainWindow
    from PySide6.QtWidgets import QFileDialog,QMessageBox
    s=Store(tmp_path/'vault','secure-password');w=MainWindow(s);w.show();qapp.processEvents();assert w.pages.count()==6
    form=w.wizard.form;form.load(profile);assert form.checked()['accuracy']=='exact'
    panel=w.wizard.palms['right'];original=tmp_path/'hand.png';Image.new('RGB',(600,900),(150,150,150)).save(original)
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(original),''));panel.upload();assert panel.item is not None
    for c in panel.checks:c.setChecked(True)
    panel.reason.setText('Synthetic test fixture: manual alignment accepted for testing only.');panel.confirm();record=panel.record();assert record['review'].startswith('manual');assert Image.open(io.BytesIO(s.read_asset(record['aligned']))).size==(800,1240)
    assert s.read_asset(record['original'])==original.read_bytes()
    old=panel.item.scale();panel.zoom.setValue(150);assert panel.item.scale()==pytest.approx(old*1.5)
    with pytest.raises(ValueError):panel.record()
    w.wizard.asof.setDate(__import__('PySide6.QtCore',fromlist=['QDate']).QDate(2026,10,8));w.wizard.confirm.setChecked(True);w.wizard.generate();assert len(s.all('clients'))==1 and len(s.all('reports'))==1
    page=w.report_page;old=page.current['id'];page.editor.appendPlainText('\nOperator review note.');page.save_edits();assert page.current['parent_version']==old;assert s.get('reports',old)['edited_text']==''
    w.close();s.close()

def test_time_boundary_matching_uncertainty(profile,settings):
    # This interval crosses a nakshatra boundary and must not receive a total.
    p=dict(profile,birth_date='1990-01-02',birth_time='12:00:00',accuracy='approximate',uncertainty_minutes=720)
    c=core.calculate(p,settings);exact=core.calculate(profile,settings)
    assert matching.match(c,exact,'groom')['total'] is None
    with pytest.raises(ValueError):core.calculate(dict(profile,birth_date='2011-12-30',timezone='Pacific/Apia',accuracy='unknown',birth_time=''),settings)

def test_transit_horizon_and_dasha_context(calc):
    assert len(calc['annual_transits']['history'])==len(calc['horizons']['history'])
    for row in calc['annual_transits']['future']:assert row['sample_date']<=calc['horizons']['future_end']
    text=reports.timeline(calc,True);assert 'Transit context sampled' in text and 'Vimshottari' in text
    assert 'Not combined with Vedic interpretations' in reports.western_text(calc)
    assert len(calc['yogas'])==2 and all('rule' in x for x in calc['yogas'])

def test_saved_ai_resumption(qapp,tmp_path,calc):
    from app import MainWindow,AIWorker
    s=Store(tmp_path/'vault','secure-password');w=MainWindow(s)
    client=s.save('clients',calc['profile']);report={'id':__import__('uuid').uuid4().hex,'title':'Synthetic AI resume test','kind':'natal','as_of':calc['settings']['as_of'],'version':1,'client_ids':[client],'calculations':[calc],'original_text':reports.text([('Reflection one','Original safe text.'),('Reflection two','Original safe text.')]),'edited_text':'','status':'AI paused','consents':[],'ai_sections':{'0':{'title':'Reflection one','body':'Already completed safe section.'}},'ai_titles':['Reflection one','Reflection two'],'ai_provider':'OpenAI','ai_model':'test-model'}
    s.save('reports',report,report['id']);s.link(report['id'],[client]);w.open_report(report['id'])
    worker=AIWorker(report,'OpenAI','test-model','never-real');calls=[]
    class Fake:
        def section(self,title,data):calls.append(title);return ai.Section(title=title,body='A completed safe interpretation for review.'),{'total_tokens':12}
    worker.provider=Fake();w.report_page.worker=worker;worker.section_ready.connect(w.report_page.ai_section);worker.complete.connect(w.report_page.ai_complete);worker.start()
    import time
    deadline=time.monotonic()+5
    while (worker.isRunning() or w.report_page.current['id']==report['id']) and time.monotonic()<deadline:qapp.processEvents()
    assert calls==['Reflection two'];assert len(s.all('reports'))==2
    assert w.report_page.current['parent_version']==report['id'];assert 'Already completed safe section.' in w.report_page.current['edited_text']
    assert s.get('reports',report['id'])['original_text']==report['original_text'];w.close();s.close()

def test_storage_restore_failed_asset_stage_preserves_data(tmp_path,profile,monkeypatch):
    from pathlib import Path
    s=Store(tmp_path/'vault','secure-password');key=s.save('clients',profile);asset=s.asset(b'original');profile['palms']={'right':{'original':asset,'aligned':asset}};s.save('clients',profile,key);backup=tmp_path/'backup';s.backup(backup)
    original_write=Path.write_bytes
    def fail_stage(path,data):
        if path.parent.name.startswith('restore-'):raise OSError('Synthetic disk failure')
        return original_write(path,data)
    monkeypatch.setattr(Path,'write_bytes',fail_stage)
    with pytest.raises(OSError):s.restore(backup,'secure-password')
    assert s.get('clients',key)==profile and s.read_asset(asset)==b'original';s.close()

def test_ai_fact_consistency_gate():
    with pytest.raises(ValueError):ai.validate_section({'title':'Reflection','body':'The Moon is in Capricorn and it determines the result.'},'Reflection')
    with pytest.raises(ValueError):ai.validate_section({'title':'Reflection','body':'The compatibility score is 35 / 36 which is the result.'},'Reflection')
    with pytest.raises(ValueError):ai.validate_section({'title':'Reflection','body':'This event date is 2027-01-03 and should be remembered.'},'Reflection')
