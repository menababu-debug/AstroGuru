"""Qt client form and uniform-scale, manually reviewed palm alignment."""
import io,datetime as dt
from PIL import Image,ImageOps,ImageStat,ImageFilter
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QDate,QTime,QRectF,QBuffer,QIODevice,Signal,QThread
from PySide6.QtGui import QPixmap,QImage,QPainter,QPainterPath,QPen,QColor
from core import validate,spelling

class ProfileForm(QWidget):
    page_changed=Signal(int)
    TITLES=['Client identity','Birth date & time','Birthplace','Reading preferences','Consultation notes']
    DESCRIPTIONS=[
        'Start with the client’s names. Family names are stored as information only.',
        'Record only what is known. Uncertain birth times remain clearly identified.',
        'Choose a city to fill its country automatically, then verify the location.',
        'Choose the report preferences and review the spelling used for numerology.',
        'Add voluntarily supplied interests and confirmed events, or leave these blank.'
    ]
    def __init__(self,profile=None,external_navigation=False):
        super().__init__();self.fields={};self.profile_id=None;self.palms={};self.external_navigation=external_navigation;self._loading=False;self.place_metadata={}
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0);layout.setSpacing(16)
        self.intake_heading=QLabel();self.intake_heading.setObjectName('SectionTitle');layout.addWidget(self.intake_heading)
        self.intake_description=QLabel();self.intake_description.setObjectName('Subtitle');self.intake_description.setWordWrap(True);layout.addWidget(self.intake_description)
        self.stack=QStackedWidget();layout.addWidget(self.stack,1);self.forms=[]
        for _ in self.TITLES:
            page=QScrollArea();page.setWidgetResizable(True);page.setFrameShape(QFrame.NoFrame)
            card=QFrame();card.setObjectName('FormCard');body=QVBoxLayout(card);body.setContentsMargins(28,24,28,24)
            form=QFormLayout();form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow);form.setRowWrapPolicy(QFormLayout.WrapLongRows);form.setHorizontalSpacing(24);form.setVerticalSpacing(16);body.addLayout(form);body.addStretch();page.setWidget(card);self.stack.addWidget(page);self.forms.append(form)
        def add(page,key,label,widget):
            widget.setObjectName(key);self.fields[key]=widget;self.forms[page].addRow(label,widget);return widget
        def line(page,key,label,placeholder=''):
            widget=QLineEdit();widget.setPlaceholderText(placeholder);return add(page,key,label,widget)
        for key,label,hint in [('first_name','Birth first name *','As recorded at birth'),('last_name','Last name','Family name'),('current_name','Current name','Optional name used now'),('father_name','Father’s name','Optional'),('mother_name','Mother’s name','Optional')]:line(0,key,label,hint)
        gender=QComboBox();gender.addItems(['Decline to specify','Woman','Man','Nonbinary','Self-describe']);add(0,'gender','Gender',gender);description=line(0,'gender_description','Self-description','Optional');description.setVisible(False);description_label=self.forms[0].labelForField(description);description_label.setVisible(False);gender.currentTextChanged.connect(lambda text:(description.setVisible(text=='Self-describe'),description_label.setVisible(text=='Self-describe')))
        date=QDateEdit(QDate(1990,1,1));date.setCalendarPopup(True);date.setDisplayFormat('yyyy-MM-dd');date.setMaximumDate(QDate.currentDate());date.setMinimumDate(QDate(1800,1,1));add(1,'birth_date','Birth date *',date)
        time=QTimeEdit(QTime(12,0));time.setDisplayFormat('HH:mm:ss');add(1,'birth_time','Birth time',time)
        accuracy=QComboBox();accuracy.addItems(['unknown','approximate','exact']);add(1,'accuracy','Time accuracy *',accuracy)
        uncertainty=QSpinBox();uncertainty.setRange(1,720);uncertainty.setValue(60);uncertainty.setSuffix(' minutes');add(1,'uncertainty_minutes','Approximate time ±',uncertainty)
        self.time_hint=QLabel();self.time_hint.setObjectName('InfoBanner');self.time_hint.setWordWrap(True);self.forms[1].addRow(self.time_hint)
        def accuracy_changed(value):
            time.setEnabled(value!='unknown');time.setDisplayFormat("'Unknown'" if value=='unknown' else 'HH:mm:ss');uncertainty.setEnabled(value=='approximate')
            self.time_hint.setText({'unknown':'Time unknown: no invented ascendant, houses, D9 or precise dasha dates.','approximate':'Approximate time: houses are provisional. D9 and precise dasha dates are withheld.','exact':'Exact time: ascendant and time-sensitive charts use this confirmed birth time.'}[value])
        accuracy.currentTextChanged.connect(accuracy_changed);accuracy_changed('unknown')
        fold=QComboBox();fold.addItems(['First occurrence (fold 0)','Second occurrence (fold 1)']);add(1,'fold','Ambiguous DST time',fold)
        add(1,'fold_confirmed','',QCheckBox('I verified the occurrence if the clock time is ambiguous'))
        city=line(2,'city','Birth city / town *','Type a city and select its country from the suggestions')
        from places import labels
        self.completer=QCompleter(labels(),self);self.completer.setCaseSensitivity(Qt.CaseInsensitive);self.completer.setFilterMode(Qt.MatchContains);self.completer.setCompletionMode(QCompleter.PopupCompletion);self.completer.setMaxVisibleItems(8);city.setCompleter(self.completer);self.completer.activated[str].connect(self.choose_offline_place)
        city.textEdited.connect(self.birthplace_edited);city.editingFinished.connect(self.autofill_unique_city)
        line(2,'state','State / province','Optional; verify if needed').textEdited.connect(self.invalidate_location)
        country=line(2,'country','Country · automatic','Filled when you select a birthplace');country.setReadOnly(True);country.textEdited.connect(self.invalidate_location)
        self.country_override=QCheckBox('Correct the country manually');self.country_override.toggled.connect(lambda value:country.setReadOnly(not value));self.forms[2].addRow('',self.country_override)
        self.place_status=QLabel('Offline city suggestions are available. Country comes from the selected birthplace, not the PC location.');self.place_status.setWordWrap(True);self.place_status.setObjectName('InfoBanner');self.forms[2].addRow(self.place_status)
        self.geo=QPushButton('Find smaller town online');self.geo.clicked.connect(self.resolve);self.forms[2].addRow('',self.geo)
        for key,label,minimum,maximum in [('latitude','Latitude',-90,90),('longitude','Longitude',-180,180)]:
            widget=QDoubleSpinBox();widget.setRange(minimum,maximum);widget.setDecimals(6);add(2,key,label,widget);widget.valueChanged.connect(self.invalidate_location)
        timezone=line(2,'timezone','Historical timezone *','Example: Asia/Kolkata');timezone.textEdited.connect(self.invalidate_location)
        add(2,'location_verified','',QCheckBox('I verified the coordinates and timezone on the birth date'))
        hand=QComboBox();hand.addItems(['Right','Left','Ambidextrous','Unknown']);add(3,'dominant_hand','Dominant hand',hand)
        language=QComboBox();language.addItems(['English']);add(3,'language','Report language',language)
        line(3,'numerology_birth_spelling','Latin birth spelling','Optional override; original names remain unchanged')
        line(3,'numerology_current_spelling','Latin current spelling','Optional override')
        self.name_preview=QLabel();self.name_preview.setWordWrap(True);self.name_preview.setObjectName('InfoBanner');self.forms[3].addRow('Numerology spelling',self.name_preview)
        for key in ['first_name','last_name','current_name','numerology_birth_spelling','numerology_current_spelling']:self.fields[key].textChanged.connect(self.preview_names)
        self.preview_names()
        for key,label,hint in [('interests','Interests & skills','Voluntary interests, learning goals and preferred work environments'),('notes','Confirmed events & notes','Only events supplied by the client. These are not chart-discovered facts.')]:
            widget=QPlainTextEdit();widget.setPlaceholderText(hint);widget.setMinimumHeight(130);add(4,key,label,widget)
        self.nav=QWidget();nav=QHBoxLayout(self.nav);nav.setContentsMargins(0,0,0,0);self.back=QPushButton('← Back');self.back.clicked.connect(self.previous_page);self.counter=QLabel();self.next=QPushButton('Continue →');self.next.setObjectName('Primary');self.next.clicked.connect(self._next_clicked);nav.addWidget(self.back);nav.addStretch();nav.addWidget(self.counter);nav.addWidget(self.next);layout.addWidget(self.nav);self.nav.setVisible(not external_navigation)
        self.stack.currentChanged.connect(self.update_page);self.update_page(0)
        if profile:self.load(profile)
    def update_page(self,index):
        self.intake_heading.setText(self.TITLES[index]);self.intake_description.setText(self.DESCRIPTIONS[index]);self.back.setEnabled(index>0);self.next.setVisible(index<len(self.TITLES)-1);self.counter.setText(f'{index+1} / {len(self.TITLES)}');self.page_changed.emit(index)
    def preview_names(self):
        birth=self.fields['numerology_birth_spelling'].text() or self.fields['first_name'].text()+' '+self.fields['last_name'].text();current=self.fields['numerology_current_spelling'].text() or self.fields['current_name'].text()
        self.name_preview.setText('Birth: '+(spelling(birth) or 'Enter a reviewed Latin spelling')+'\nCurrent: '+(spelling(current) or 'Not supplied'))
    def invalidate_location(self,*args):
        if not self._loading and 'location_verified' in self.fields:self.fields['location_verified'].setChecked(False)
    def birthplace_edited(self,*args):
        self.invalidate_location();self.place_metadata={}
        if not self.country_override.isChecked():self.fields['country'].clear()
        self.place_status.setText('Select a matching birthplace to populate its country. Same-name cities are never chosen silently.')
    def choose_offline_place(self,label):
        from places import by_label
        row=by_label().get(label)
        if row:self.apply_place(row,'offline GeoNames')
    def autofill_unique_city(self):
        if self._loading or self.country_override.isChecked() or self.fields['country'].text().strip():return
        from places import exact_matches
        rows=exact_matches(self.fields['city'].text())
        if len(rows)==1:self.apply_place(rows[0],'offline GeoNames')
        elif len(rows)>1:self.place_status.setText('Several cities share this name. Select the correct country/region from the suggestions.')
    def apply_place(self,row,source):
        self._loading=True
        try:
            self.fields['city'].setText(row['name'] if 'name' in row else row['city']);self.fields['country'].setText(row.get('country',''))
            if row.get('state'):self.fields['state'].setText(row['state'])
            else:self.fields['state'].clear()
            self.fields['latitude'].setValue(float(row['latitude']));self.fields['longitude'].setValue(float(row['longitude']))
            zone=row.get('timezone')
            if not zone:
                from timezonefinder import TimezoneFinder
                zone=TimezoneFinder().timezone_at(lat=float(row['latitude']),lng=float(row['longitude']))
            self.fields['timezone'].setText(zone or '')
            self.place_metadata={'source':source,'place_id':row.get('geonameid'),'country_code':row.get('countrycode'),'selected_at':dt.datetime.now(dt.timezone.utc).isoformat()}
            self.fields['location_verified'].setChecked(False);self.country_override.setChecked(False)
            self.place_status.setText(f"Country filled: {row.get('country') or 'not available'}. Check city coordinates and the historical timezone before continuing.")
        finally:self._loading=False
    def check_page(self,index=None):
        index=self.stack.currentIndex() if index is None else index;p=self.value()
        if index==0 and not p['first_name']:raise ValueError('Enter the client’s birth first name.')
        if index==1:
            if dt.date.fromisoformat(p['birth_date'])>dt.date.today():raise ValueError('Future birth dates are not accepted.')
            if p['accuracy']!='unknown':dt.time.fromisoformat(p['birth_time'])
        if index==2:
            self.autofill_unique_city();p=self.value()
            if not p['city'] or not p['country']:raise ValueError('Select a birthplace to fill the country, or use the manual correction option.')
            from zoneinfo import ZoneInfo
            ZoneInfo(p['timezone'])
            if not p['location_verified']:raise ValueError('Verify the coordinates and historical timezone before continuing.')
        return p
    def _next_clicked(self):
        try:self.next_page()
        except Exception as error:QMessageBox.warning(self,'Check this page',str(error))
    def next_page(self):self.check_page();self.stack.setCurrentIndex(min(self.stack.currentIndex()+1,len(self.TITLES)-1))
    def previous_page(self):self.stack.setCurrentIndex(max(0,self.stack.currentIndex()-1))
    def reset(self):
        fresh=ProfileForm()
        try:self.load(fresh.value());self.place_metadata={};self.country_override.setChecked(False);self.stack.setCurrentIndex(0)
        finally:fresh.deleteLater()
    def resolve(self):
        query=', '.join(self.fields[k].text() for k in ['city','state','country'] if self.fields[k].text().strip())
        if not self.fields['city'].text().strip():QMessageBox.information(self,'Birthplace','Enter a city or town first.');return
        if getattr(self,'lookup',None) and self.lookup.isRunning():return
        class Lookup(QThread):
            done=Signal(object);failed=Signal(str)
            def run(self):
                import urllib.request,urllib.parse,json
                try:
                    url='https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&accept-language=en&limit=5&q='+urllib.parse.quote(query)
                    req=urllib.request.Request(url,headers={'User-Agent':'Astroguru/1.1 (desktop birthplace lookup)'})
                    self.done.emit(json.load(urllib.request.urlopen(req,timeout=20)))
                except Exception:self.failed.emit('Online search unavailable. Use offline suggestions or enter a verified location with manual country correction.')
        self.lookup=Lookup(QApplication.instance());self.geo.setEnabled(False);self.lookup.done.connect(self.resolved);self.lookup.failed.connect(self.place_status.setText);self.lookup.finished.connect(self.lookup_finished);self.lookup.start()
    def lookup_finished(self):self.geo.setEnabled(True)
    def resolved(self,rows):
        if not rows:self.place_status.setText('No matching town found. Use offline search or manual correction.');return
        names=[row['display_name'] for row in rows];choice,ok=QInputDialog.getItem(self,'Select birthplace','OpenStreetMap © contributors. Choose the correct birthplace:',names,0,False)
        if ok:
            from places import online_place
            self.apply_place(online_place(rows[names.index(choice)]),'OpenStreetMap Nominatim')
    def value(self):
        p={}
        for key,w in self.fields.items():
            if isinstance(w,QDateEdit):p[key]=w.date().toString('yyyy-MM-dd')
            elif isinstance(w,QTimeEdit):p[key]=w.time().toString('HH:mm:ss')
            elif isinstance(w,QComboBox):p[key]=w.currentIndex() if key=='fold' else w.currentText()
            elif isinstance(w,QCheckBox):p[key]=w.isChecked()
            elif isinstance(w,(QSpinBox,QDoubleSpinBox)):p[key]=w.value()
            elif isinstance(w,QPlainTextEdit):p[key]=w.toPlainText()
            else:p[key]=w.text().strip()
        if p['gender']=='Self-describe':p['gender']='Self-describe: '+p['gender_description']
        if p['accuracy']=='unknown':p['birth_time']=''
        p['palms']=dict(self.palms);p['birthplace_resolution']=dict(self.place_metadata)
        return p
    def load(self,p):
        self._loading=True;self.palms=dict(p.get('palms',{}));self.place_metadata=dict(p.get('birthplace_resolution',{}))
        for key,w in self.fields.items():
            if key not in p:continue
            v=p[key]
            if isinstance(w,QDateEdit):w.setDate(QDate.fromString(v,'yyyy-MM-dd'))
            elif isinstance(w,QTimeEdit):
                if v:w.setTime(QTime.fromString(v,'HH:mm:ss'))
            elif isinstance(w,QComboBox):
                if key=='fold':w.setCurrentIndex(int(v))
                elif str(v).startswith('Self-describe:'):w.setCurrentText('Self-describe');self.fields['gender_description'].setText(v.split(':',1)[1].strip())
                else:w.setCurrentText(str(v))
            elif isinstance(w,QCheckBox):w.setChecked(bool(v))
            elif isinstance(w,(QSpinBox,QDoubleSpinBox)):w.setValue(v)
            elif isinstance(w,QPlainTextEdit):w.setPlainText(v)
            else:w.setText(str(v))
        self._loading=False
        self.place_status.setText("Saved location loaded. Country, coordinates and historical timezone can be reviewed and corrected.")
    def checked(self):
        for index in range(len(self.TITLES)):
            try:self.check_page(index)
            except Exception:self.stack.setCurrentIndex(index);raise
        p=self.value();validate(p);return p

class PalmPanel(QWidget):
    def __init__(self,hand,store):
        if hand not in ('right','left'):raise ValueError('Choose the client’s right or left hand explicitly.')
        super().__init__();self.hand=hand;self.store=store;self.original=None;self.display_data=None;self.item=None;self.confirmed_record=None;self.background_removed=False
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0);layout.setSpacing(16)
        title=QLabel('Client’s '+hand.upper()+' hand');title.setObjectName('SectionTitle');layout.addWidget(title)
        info=QLabel('Use the client’s own '+hand+' hand, regardless of where it appears on screen. Photographs are never mirrored. Include every finger, the complete palm and a small section of wrist.');info.setWordWrap(True);info.setObjectName('Subtitle');layout.addWidget(info)
        body=QHBoxLayout();layout.addLayout(body,1)
        self.scene=QGraphicsScene(0,0,400,620);self.view=QGraphicsView(self.scene);self.view.setObjectName('PalmCanvas');self.view.setMinimumSize(280,360);self.view.setRenderHint(QPainter.Antialiasing);self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.view.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff);body.addWidget(self.view,3)
        self.clip=QGraphicsRectItem(0,0,400,620);self.clip.setPen(QPen(Qt.NoPen));self.clip.setBrush(Qt.NoBrush);self.clip.setFlag(QGraphicsItem.ItemClipsChildrenToShape);self.scene.addItem(self.clip)
        self.guide=QGraphicsRectItem(1,1,398,618);self.guide.setPen(QPen(QColor('#9677c3'),2,Qt.DashLine));self.guide.setZValue(10);self.scene.addItem(self.guide)
        self.placeholder=self.scene.addText(hand.upper()+' HAND\n\nUpload a photograph\nRectangular alignment area');self.placeholder.setDefaultTextColor(QColor('#716482'));self.placeholder.setPos(65,245)
        controls=QScrollArea();controls.setWidgetResizable(True);controls.setMinimumWidth(300);controls.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);controls.setFrameShape(QFrame.NoFrame);card=QFrame();card.setObjectName('FormCard');control=QVBoxLayout(card);control.setContentsMargins(20,20,20,20);control.setSpacing(14);controls.setWidget(card);body.addWidget(controls,2)
        upload=QPushButton('Upload '+hand+' palm');upload.setObjectName('Primary');upload.clicked.connect(self.upload);control.addWidget(upload)
        row=QHBoxLayout();reset=QPushButton('Reset position');reset.clicked.connect(self.reset);row.addWidget(reset);clear=QPushButton('Remove photo');clear.clicked.connect(self.clear);row.addWidget(clear);control.addLayout(row)
        instructions=QLabel('Drag to reposition. Zoom keeps the original proportions. The rectangle crops only the aligned copy.');instructions.setWordWrap(True);control.addWidget(instructions)
        form=QFormLayout();self.zoom=QSlider(Qt.Horizontal);self.zoom.setRange(10,300);self.zoom.setValue(100);self.rotation=QSlider(Qt.Horizontal);self.rotation.setRange(-180,180);form.addRow('Zoom',self.zoom);form.addRow('Rotate',self.rotation);control.addLayout(form);self.zoom.valueChanged.connect(self.transform);self.rotation.valueChanged.connect(self.transform)
        self.background_button=QPushButton('Clear background');self.background_button.clicked.connect(self.remove_background);self.background_button.setEnabled(False);control.addWidget(self.background_button)
        self.tolerance=QSlider(Qt.Horizontal);self.tolerance.setRange(5,100);self.tolerance.setValue(35);form2=QFormLayout();form2.addRow('Background tolerance',self.tolerance);control.addLayout(form2)
        self.restore_button=QPushButton('Restore original background');self.restore_button.clicked.connect(self.restore_background);self.restore_button.setEnabled(False);control.addWidget(self.restore_button)
        background_hint=QLabel('Local plain-background removal. Best with an even, contrasting background. Preview carefully: similar skin/background colors can erase hand edges. Restore the original if needed.');background_hint.setWordWrap(True);background_hint.setObjectName('Subtitle');control.addWidget(background_hint)
        self.quality=QLabel('No photograph uploaded. Finger completeness and hand identity require manual review.');self.quality.setWordWrap(True);self.quality.setObjectName('InfoBanner');control.addWidget(self.quality)
        self.checks=[]
        for label in [f'I confirm this is the client’s {hand} hand','All fingers, palm and wrist are visible','Focus, exposure and alignment have been manually reviewed']:
            import textwrap
            check=QCheckBox('\n'.join(textwrap.wrap(label,width=34)));self.checks.append(check);control.addWidget(check)
        self.reason=QLineEdit();self.reason.setPlaceholderText('Manual acceptance reason / observations');control.addWidget(self.reason)
        confirm=QPushButton('Confirm '+hand+' palm');confirm.setObjectName('Primary');confirm.clicked.connect(self.confirm);control.addWidget(confirm)
        self.status=QLabel('Optional · you can skip this palm.');self.status.setWordWrap(True);control.addWidget(self.status);control.addStretch()
    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'view'):self.view.fitInView(self.scene.sceneRect(),Qt.KeepAspectRatio)
    def set_photo(self,data,reset=True):
        image=ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert('RGBA');image.thumbnail((3000,3000));buffer=io.BytesIO();image.save(buffer,format='PNG');self.display_data=buffer.getvalue();pix=QPixmap();pix.loadFromData(self.display_data)
        old=None
        if self.item:
            old=(self.item.pos(),self.item.scale(),self.item.rotation());self.scene.removeItem(self.item)
        self.item=QGraphicsPixmapItem(pix,self.clip);self.item.setFlag(QGraphicsItem.ItemIsMovable);self.item.setFlag(QGraphicsItem.ItemIsSelectable);self.item.setTransformOriginPoint(pix.width()/2,pix.height()/2);self.placeholder.hide()
        if reset or old is None:self.reset()
        else:
            self.item.setPos(old[0]);self.item.setScale(old[1]);self.item.setRotation(old[2]);self.invalidate()
        self.view.fitInView(self.scene.sceneRect(),Qt.KeepAspectRatio)
    def upload(self):
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():return
        filename,_=QFileDialog.getOpenFileName(self,'Upload client’s '+self.hand+' palm','','Images (*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff)')
        if not filename:return
        try:
            from pathlib import Path
            raw=Path(filename).read_bytes()
            if len(raw)>25*1024*1024:raise ValueError('Use an image under 25 MB.')
            image=Image.open(io.BytesIO(raw));image.verify();image=ImageOps.exif_transpose(Image.open(io.BytesIO(raw)))
            if image.width*image.height>30_000_000:raise ValueError('Use an image under 30 megapixels.')
            self.original=raw;self.background_removed=False;self.set_photo(raw);self.background_button.setEnabled(True);self.restore_button.setEnabled(False)
            gray=image.convert('L');gray.thumbnail((1000,1000));mean=ImageStat.Stat(gray).mean[0];contrast=ImageStat.Stat(gray).stddev[0];edge=ImageStat.Stat(gray.filter(ImageFilter.FIND_EDGES)).mean[0];hints=[]
            if mean<50 or mean>220:hints.append('Possible poor exposure')
            if contrast<20 or edge<3:hints.append('Possible blur / low detail')
            self.quality.setText('Heuristic warnings: '+('; '.join(hints) if hints else 'none detected; this is not a quality approval')+'. Review hand identity, fingers, wrist and any background changes manually.');self.reason.clear()
            for check in self.checks:check.setChecked(False)
        except Exception as error:QMessageBox.warning(self,'Upload error',str(error))
    def invalidate(self):self.confirmed_record=None;self.status.setText('Preview changed. Review and confirm again.')
    def clear(self):
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():return
        if self.item:self.scene.removeItem(self.item)
        self.item=None;self.original=None;self.display_data=None;self.confirmed_record=None;self.background_removed=False;self.placeholder.show();self.background_button.setEnabled(False);self.restore_button.setEnabled(False);self.reason.clear();self.status.setText('No photograph · this palm may be skipped.')
        for check in self.checks:check.setChecked(False)
    def reset(self):
        if not self.item:return
        self.base_scale=min(400/self.item.pixmap().width(),620/self.item.pixmap().height());self.zoom.blockSignals(True);self.rotation.blockSignals(True);self.zoom.setValue(100);self.rotation.setValue(0);self.zoom.blockSignals(False);self.rotation.blockSignals(False);self.item.setRotation(0);self.item.setScale(self.base_scale);self.item.setPos((400-self.item.pixmap().width())/2,(620-self.item.pixmap().height())/2);self.invalidate()
    def transform(self):
        if self.item:self.item.setScale(self.base_scale*self.zoom.value()/100);self.item.setRotation(self.rotation.value());self.invalidate()
    def remove_background(self):
        if not self.original:return
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():return
        data=self.original;tolerance=self.tolerance.value()
        class BackgroundWorker(QThread):
            done=Signal(bytes);failed=Signal(str)
            def run(self):
                try:
                    from imaging import clear_background
                    self.done.emit(clear_background(data,tolerance))
                except Exception as error:self.failed.emit(str(error))
        self.background_worker=BackgroundWorker(self);self.background_worker.done.connect(self.background_ready);self.background_worker.failed.connect(lambda message:QMessageBox.warning(self,'Background preview',message));self.background_worker.finished.connect(lambda:self.background_button.setEnabled(self.original is not None));self.background_button.setEnabled(False);self.status.setText('Clearing a plain background locally…');self.background_worker.start()
    def background_ready(self,data):
        self.set_photo(data);self.background_removed=True;self.restore_button.setEnabled(True)
        for check in self.checks:check.setChecked(False)
        self.status.setText('Background preview ready. Check every finger and wrist; restore the original if edges were removed.')
    def restore_background(self):
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():return
        if self.original:self.set_photo(self.original);self.background_removed=False;self.restore_button.setEnabled(False)
    def load_record(self,record):
        self.clear()
        if not record:return
        if record.get('hand') not in (None,self.hand):raise ValueError('Saved hand label does not match this step. Re-upload and confirm the correct client hand.')
        self.original=self.store.read_asset(record['original']);self.set_photo(self.store.read_asset(record['aligned']));self.background_removed=bool(record.get('background_removed'));self.reason.setText(record.get('reason','Previously accepted photograph'))
        for check in self.checks:check.setChecked(True)
        self.background_button.setEnabled(True);self.restore_button.setEnabled(self.background_removed)
        self.confirmed_record=dict(record,transform=self.current_transform());self.status.setText('Previously confirmed '+self.hand+' palm loaded. Review before continuing.')
    def current_transform(self):return {'scale':self.item.scale(),'rotation':self.item.rotation(),'x':self.item.x(),'y':self.item.y(),'crop':[0,0,400,620]}
    def confirm(self):
        if not self.item:QMessageBox.warning(self,'Manual review','Upload a photograph first.');return
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():return
        if not all(check.isChecked() for check in self.checks) or not self.reason.text().strip():QMessageBox.warning(self,'Manual review','Confirm all review items and record an acceptance reason.');return
        try:
            image=QImage(800,1240,QImage.Format_ARGB32);image.fill(Qt.transparent);painter=QPainter(image);self.guide.hide();self.item.setSelected(False)
            try:self.scene.render(painter,QRectF(0,0,800,1240),self.scene.sceneRect())
            finally:painter.end();self.guide.show()
            buffer=QBuffer();buffer.open(QIODevice.WriteOnly);image.save(buffer,'PNG')
            self.confirmed_record={'hand':self.hand,'original':self.store.asset(self.original),'aligned':self.store.asset(bytes(buffer.data())),'reason':self.reason.text().strip(),'observations':self.reason.text().strip(),'review':'manual; no anatomical automation','confirmed_at':dt.datetime.now(dt.timezone.utc).isoformat(),'transform':self.current_transform(),'background_removed':self.background_removed,'background_method':'edge-connected plain-color removal; operator reviewed' if self.background_removed else 'original background','mirrored':False};self.status.setText('Accepted. Original and rectangular aligned copy encrypted locally.')
        except Exception as error:QMessageBox.warning(self,'Alignment error',str(error))
    def record(self):
        if getattr(self,'background_worker',None) and self.background_worker.isRunning():raise ValueError('Wait for the background preview to finish.')
        if self.item and self.confirmed_record:
            if self.current_transform()!=self.confirmed_record['transform']:raise ValueError(f'{self.hand.title()} palm was repositioned. Confirm the new alignment.')
        if self.item and not self.confirmed_record:raise ValueError(f'Confirm the {self.hand} palm, or use Remove photo / Skip palm.')
        return self.confirmed_record
