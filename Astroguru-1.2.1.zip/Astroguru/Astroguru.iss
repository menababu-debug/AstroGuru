#define MyAppName "Astroguru"
#define MyAppVersion "1.2.1"
[Setup]
AppId={{DDB3EA50-9C76-442A-9A50-391D9D126F4C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Astroguru
DefaultDirName={localappdata}\Programs\Astroguru
DefaultGroupName=Astroguru
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=windows-delivery
OutputBaseFilename=Astroguru-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
LicenseFile=LICENSE
UninstallDisplayIcon={app}\Astroguru.exe
[Files]
Source: "dist\Astroguru\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{group}\Astroguru"; Filename: "{app}\Astroguru.exe"
Name: "{autodesktop}\Astroguru"; Filename: "{app}\Astroguru.exe"; Tasks: desktopicon
[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked
[Run]
Filename: "{app}\Astroguru.exe"; Description: "Launch Astroguru"; Flags: nowait postinstall skipifsilent
