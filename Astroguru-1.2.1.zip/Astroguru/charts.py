"""Data-only SVG Kundali rendering; no image generation."""
import html,xml.etree.ElementTree as ET
from core import SIGNS,HINDI,ABBR
POLYGONS=[[(300,0),(450,150),(300,300),(150,150)],[(0,0),(300,0),(150,150)],[(0,0),(150,150),(0,300)],[(0,300),(150,150),(300,300),(150,450)],[(0,300),(150,450),(0,600)],[(0,600),(150,450),(300,600)],[(300,300),(450,450),(300,600),(150,450)],[(300,600),(450,450),(600,600)],[(600,300),(600,600),(450,450)],[(300,300),(450,150),(600,300),(450,450)],[(600,0),(600,300),(450,150)],[(300,0),(600,0),(450,150)]]
CENTERS=[(300,140),(150,42),(62,145),(150,290),(62,440),(150,545),(300,440),(450,545),(538,440),(450,290),(538,145),(450,42)]
SOUTH=[(1,0),(2,0),(3,0),(3,1),(3,2),(3,3),(2,3),(1,3),(0,3),(0,2),(0,1),(0,0)]

def span_at(points,y):
    hits=[]
    for a,b in zip(points,points[1:]+points[:1]):
        if a[1]!=b[1] and min(a[1],b[1])<=y<=max(a[1],b[1]):hits.append(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]))
    return (min(hits),max(hits)) if hits else (0,600)

def svg(chart,layout='North Indian',division='D1',language='English'):
    labels=HINDI if language=='Hindi' else SIGNS
    parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 750" width="640" height="750">','<rect width="640" height="750" fill="#fffdf7"/>']
    def text(x,y,value,size=13,anchor='middle',color='#35324b'):
        parts.append(f'<text x="{x}" y="{y}" font-family="sans-serif" font-size="{size}" fill="{color}" text-anchor="{anchor}">{html.escape(str(value))}</text>')
    if not chart.get('vedic'):
        text(320,100,'Birth time unknown — precise Kundali unavailable',17)
        text(320,140,'Ascendant, houses, degrees and D9 require birth time.')
        for i,(name,p) in enumerate(chart.get('available_ranges',{}).items()):text(320,190+i*30,name+': '+', '.join(SIGNS[s] for s in p['signs']))
        parts.append('</svg>');return ''.join(parts)
    if division=='D9' and not chart.get('d9_allowed'):raise ValueError('D9 requires confirmed exact birth time.')
    asc=chart['ascendant']['sign'] if division=='D1' else chart['ascendant']['navamsha_sign']
    table=chart['vedic'];text(320,25,f'{division} · {layout} · '+('Provisional' if chart['accuracy']=='approximate' else 'Calculated'),18)
    for i in range(12):
        sign=(asc+i)%12 if layout=='North Indian' else i
        house=(sign-asc)%12+1
        if layout=='North Indian':
            points=' '.join(f'{x+20},{y+50}' for x,y in POLYGONS[i]);x,y=CENTERS[i]
            if i in [1,11]:y=24
            elif i in [5,7]:y=493
            elif i in [2,10]:y=98
            elif i in [4,8]:y=398
            x+=20;y+=50
        else:
            col,row=SOUTH[i];x0=20+col*150;y0=50+row*150
            points=f'{x0},{y0} {x0+150},{y0} {x0+150},{y0+150} {x0},{y0+150}';x=x0+75;y=y0+24
        parts.append(f'<polygon points="{points}" fill="#faf7ff" stroke="#8976aa" stroke-width="1.5"/>')
        label=f'H{house} · {sign+1} {labels[sign]}'
        header_x=x;header_size=min(16,138/(max(1,len(label))*.6)) if layout=='South Indian' else 16
        if layout=='North Indian':
            low,high=span_at(POLYGONS[i],y-50);header_x=20+(low+high)/2;header_size=min(16,max(7,(high-low-12)/(max(1,len(label))*.6)))
        side_triangle=layout=='North Indian' and i in [2,4,8,10]
        if side_triangle:
            text(header_x,y,f'H{house} · {sign+1}',16)
            low,high=span_at(POLYGONS[i],y+14-50);text(20+(low+high)/2,y+14,labels[sign],14)
        else:text(header_x,y,label,header_size)
        if sign==asc:text(x,y+16,'Asc',11,color='#745614')
        contents=[]
        for name,p in table.items():
            ps=p['sign'] if division=='D1' else p['navamsha_sign']
            if ps==sign:
                degree=p['degree'] if division=='D1' else (p['longitude']*9)%30
                contents.append(f"{ABBR[name]} {degree:.2f}°"+(' R' if p['retrograde'] else ''))
        # With many occupants reduce font/leading to keep all labels inside cell.
        leading=10 if len(contents)>5 else 17; size=12 if len(contents)>5 else 16
        if layout=='North Indian' and i in [1,11] and len(contents)>3:
            leading=10 if len(contents)>5 else 14
            size=8 if len(contents)>5 else 14
        size=min(size,leading-.5)
        for j,line in enumerate(contents):
            offset=18 if layout=='North Indian' and i in [1,11] and len(contents)>5 else 40 if side_triangle else 30
            line_y=y+offset+j*leading;line_x=x;line_size=size
            if layout=='North Indian':
                low,high=span_at(POLYGONS[i],line_y-50);line_x=20+(low+high)/2;line_size=min(size,max(6,(high-low-12)/(max(1,len(line))*.6)))
            text(line_x,line_y,line,line_size)
    asc_degree=chart['ascendant']['degree'] if division=='D1' else (chart['ascendant']['longitude']*9)%30
    text(320,666,f'Ascendant: {SIGNS[asc]} {asc_degree:.3f}°',12)
    moon=table['Moon'];text(320,689,f"Moon: {SIGNS[moon['sign']]} · {moon['nakshatra']} · Pada {moon['pada']}",14)
    text(320,711,'Su Sun · Mo Moon · Me Mercury · Ve Venus · Ma Mars',12)
    text(320,733,'Ju Jupiter · Sa Saturn · Ra Rahu · Ke Ketu · R retrograde · H house',11)
    parts.append('</svg>');return ''.join(parts)

def drawing(svg_text):
    """Render the same SVG elements into ReportLab vector primitives."""
    from reportlab.graphics.shapes import Drawing,Polygon,String,Rect
    from reportlab.lib.colors import HexColor
    root=ET.fromstring(svg_text);d=Drawing(640,750)
    for el in root:
        tag=el.tag.split('}')[-1];a=el.attrib
        if tag=='rect':d.add(Rect(float(a.get('x',0)),750-float(a.get('y',0))-float(a['height']),float(a['width']),float(a['height']),fillColor=HexColor(a['fill']),strokeColor=None))
        elif tag=='polygon':
            coords=[]
            for point in a['points'].split():x,y=map(float,point.split(','));coords.extend([x,750-y])
            d.add(Polygon(coords,fillColor=HexColor(a['fill']),strokeColor=HexColor(a['stroke']),strokeWidth=float(a['stroke-width'])))
        elif tag=='text':d.add(String(float(a['x']),750-float(a['y']),el.text or '',fontSize=float(a['font-size']),textAnchor=a.get('text-anchor','middle'),fillColor=HexColor(a['fill']),fontName='Helvetica'))
    return d

def png(svg_text,path):
    from PySide6.QtSvg import QSvgRenderer
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtCore import QByteArray
    image=QImage(1280,1500,QImage.Format_ARGB32);image.fill(0xffffffff);p=QPainter(image);QSvgRenderer(QByteArray(svg_text.encode())).render(p);p.end()
    if not image.save(str(path),'PNG'):raise ValueError('PNG export failed.')
