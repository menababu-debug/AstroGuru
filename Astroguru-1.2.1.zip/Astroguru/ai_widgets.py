"""Per-reading AI options and explicit consent for the exact section requests."""
import json,hashlib,textwrap
from pathlib import Path
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QUrl
from PySide6.QtGui import QPixmap,QDesktopServices
from ai import payload,COVER_PROMPT
from generation import job_data

class AIOptions(QFrame):
    def __init__(self,window):
        super().__init__();self.window=window;self.setObjectName('FormCard');layout=QVBoxLayout(self);layout.setContentsMargins(22,18,22,18)
        self.automatic=QCheckBox('Automatically generate the detailed AI report after submission');self.automatic.setChecked(window.config.value('auto_ai',False,type=bool));layout.addWidget(self.automatic)
        self.depth=QComboBox();self.depth.addItems(['Detailed','Very detailed']);self.depth.setCurrentText(window.config.value('report_depth','Very detailed'));form=QFormLayout();form.addRow('Report depth',self.depth);layout.addLayout(form)
        self.context=QCheckBox('Include voluntary interests and client-confirmed notes (review for private names)');self.palms=QCheckBox('Optional AI palm observations · separate photo consent required');self.cover=QCheckBox('Generate one decorative cover illustration · additional API charges');self.pdf=QCheckBox('Automatically assemble and save a PDF when generation completes');self.pdf.setChecked(True)
        for check in (self.context,self.palms,self.cover,self.pdf):layout.addWidget(check)
        hint=QLabel('Provider and model come from Settings. API credentials are required for automation. Review the exact data and record consent at submission. Charts and traditional scores always come from local calculations.');hint.setWordWrap(True);hint.setObjectName('Subtitle');layout.addWidget(hint)
        for check in (self.automatic,self.context,self.palms,self.cover,self.pdf):check.setText('\n'.join(textwrap.wrap(check.text(),width=65)))
        self.automatic.toggled.connect(self.update_enabled);self.update_enabled(self.automatic.isChecked())
    def update_enabled(self,enabled):
        for widget in (self.depth,self.context,self.palms,self.cover,self.pdf):widget.setEnabled(enabled)
    def value(self):
        provider=self.window.config.value('ai_provider','OpenAI')
        return {'automatic':self.automatic.isChecked(),'depth':self.depth.currentText(),'client_context':self.context.isChecked(),'palm_images':self.palms.isChecked(),'cover':self.cover.isChecked(),'auto_pdf':self.pdf.isChecked(),'image_model':self.window.config.value('image_model_'+provider,'gpt-image-1.5' if provider=='OpenAI' else 'gemini-3.1-flash-image'),'pdf_dir':self.window.config.value('export_dir',str(self.window.store.folder/'exports'))}

class AIConsentDialog(QDialog):
    def __init__(self,parent,report,provider,model,images):
        super().__init__(parent);self.setWindowTitle('Review & submit automatic AI generation');self.resize(900,760);self.report=report;self.images=images;self.provider=provider;self.model=model;outer=QVBoxLayout(self);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame);content=QWidget();layout=QVBoxLayout(content);scroll.setWidget(content);outer.addWidget(scroll)
        jobs=report.get('ai_jobs',[]);count=len(jobs) or len(report.get('ai_titles',[]));options=report.get('ai_options',{})
        info=QLabel(f'{provider} · {model}\n{count} section requests; completed sections are saved for resumption. Names, parental names, raw birth details and precise birthplace are excluded. API charges and rate limits apply. A consumer ChatGPT/Gemini subscription does not supply this API credential.');info.setWordWrap(True);layout.addWidget(info)
        selector=QComboBox();selector.addItem('Calculated report context',None)
        for index,job in enumerate(jobs):selector.addItem(job['title'],index)
        layout.addWidget(selector);self.preview=QPlainTextEdit();self.preview.setReadOnly(True);self.preview.setMinimumHeight(220);layout.addWidget(self.preview,1)
        def show_request():
            index=selector.currentData();data=payload(report) if index is None else job_data(report,jobs[index]);self.preview.setPlainText(json.dumps(data,ensure_ascii=False,indent=2))
        selector.currentIndexChanged.connect(show_request);show_request()
        if options.get('auto_pdf'):
            label=QLabel('Automatic PDF location: '+options.get('pdf_dir','')+'. Exported PDFs are unencrypted client documents.');label.setWordWrap(True);layout.addWidget(label)
        if options.get('cover'):
            label=QLabel('Optional image model: '+options['image_model']+'\nArtwork request (no client data): '+COVER_PROMPT);label.setWordWrap(True);layout.addWidget(label)
        self.checks=[]
        for person in range(len(report['calculations'])):
            check=QCheckBox('\n'.join(textwrap.wrap(f'Person {person+1} explicitly consents to {provider}, these calculated results and any selected voluntary context',width=85)));layout.addWidget(check);self.checks.append(check)
            photos=[image for image in images if image['person']==person]
            if photos:
                names=', '.join(image['hand'] for image in photos);row=QHBoxLayout()
                for image in photos:
                    pix=QPixmap();pix.loadFromData(image['data']);label=QLabel();label.setPixmap(pix.scaled(90,120,Qt.KeepAspectRatio,Qt.SmoothTransformation));row.addWidget(label)
                row.addStretch();layout.addLayout(row);check=QCheckBox(f'Person {person+1} separately consents to sending the shown aligned {names} palm photos');layout.addWidget(check);self.checks.append(check)
        if options.get('cover'):
            check=QCheckBox('Authorize the additional decorative image request and its API charges');layout.addWidget(check);self.checks.append(check)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Ok).setText('Submit & generate automatically');buttons.button(QDialogButtonBox.Ok).setEnabled(False);layout.addWidget(buttons)
        for check in self.checks:check.toggled.connect(lambda _:buttons.button(QDialogButtonBox.Ok).setEnabled(all(c.isChecked() for c in self.checks)))
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject)
    def record(self):
        if not all(check.isChecked() for check in self.checks):raise ValueError('Explicit consent is required from each person before sending data.')
        import datetime as dt
        requests=[job_data(self.report,job) for job in self.report.get('ai_jobs',[])] or [payload(self.report)]
        manifest={'requests':requests,'photos':[{'person':image['person'],'hand':image['hand'],'sha256':hashlib.sha256(image['data']).hexdigest()} for image in self.images],'cover_prompt':COVER_PROMPT if self.report.get('ai_options',{}).get('cover') else None}
        return {'provider':self.provider,'model':self.model,'image_model':self.report.get('ai_options',{}).get('image_model') if manifest['cover_prompt'] else None,'payload_hash':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),'people':len(self.report['calculations']),'consented':True,'timestamp':dt.datetime.now(dt.timezone.utc).isoformat(),'palm_images':bool(self.images),'photo_manifest':manifest['photos'],'voluntary_context':bool(self.report.get('ai_options',{}).get('client_context')),'decorative_artwork':bool(manifest['cover_prompt']),'prompt_version':'Astroguru-1.2'}
