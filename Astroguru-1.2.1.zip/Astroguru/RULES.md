# Deterministic rules and references

## Astronomical calculation

Swiss Ephemeris 2.10.03 via pyswisseph 2.10.3.2. Positions are geocentric ecliptic longitudes using built-in **Moshier** ephemeris with speed. Sidereal modes: Lahiri, Raman, Krishnamurti; tropical view is separate. Nodes are mean nodes; Ketu is opposite Rahu. The engine's sidereal house calculation supplies the ascendant in the same sidereal frame as planets (including the engine's nutation convention), not a hand-subtracted approximate ayanamsa. Vedic houses are Whole Sign. Western options are Placidus, Whole Sign and Equal; undefined high-latitude systems fail visibly rather than silently falling back.

For each placement: sign = floor(longitude/30), sign degree = longitude mod 30, nakshatra = floor(longitude/(360/27)), pada = floor(remainder/(360/108))+1. D9 sign = floor(longitude/(10/3)) mod 12; divisional longitude = (longitude×9) mod 360. Retrograde is a negative longitude speed. D9 requires operator-confirmed exact time; the label records this dependency. No planetary placement comes from AI.

Vimshottari uses the Moon's nakshatra, sequence Ketu/Venus/Sun/Moon/Mars/Rahu/Jupiter/Saturn/Mercury and years 7/20/6/10/7/18/16/19/17. The fraction of the birth nakshatra already traversed determines the initial balance. A dasha year is **365.2425 days**; antardasha duration is major-years × sub-years /120. Results depend on this explicit convention and may differ from packages using 360-day or other years. Precise timing is withheld for approximate and unknown time. Stored dates before birth represent the partially elapsed birth mahadasha, not a pre-birth reading.

Yearly historical and future transit snapshots use Jupiter/Saturn at 12:00 UTC on the midpoint of the actual covered interval. They supply broad symbolic context, never guaranteed events. Natal houses are not inferred from collective transits where birth time is uncertain. As-of transits use 12:00 UTC on the selected date. No mundane chart is presented as proof of personal events.

Baseline yogas: Budha Aditya = Sun/Mercury in the same sidereal sign; Gajakesari = Jupiter at 1/4/7/10 Whole Sign positions from Moon. Dignity, combustion, strength and cancellation rules are not assessed; descriptions remain measured. Baseline Manglik = Mars in Whole Sign houses 1,2,4,7,8,12 from ascendant; exact time required. No cancellation/exception rules are applied. This is not a danger or relationship-outcome classification.

Moshier's approximate supported date range is 3000 BCE–3000 CE; the client UI supports 1800 CE through today. Coordinates are operator-verifiable. TimezoneFinder supplies a **current boundary suggestion**, not historical boundary proof. IANA ZoneInfo applies historical UTC offsets and DST after the operator confirms the proper zone. Nonexistent clock times fail; ambiguous times require an explicit fold choice.

## Birth-time uncertainty

Unknown time samples the complete local civil date at 97 points (15 minutes or less, depending on DST day length). Approximate time samples the stated ± interval at ≤15-minute steps. Sign/nakshatra possibilities are estimates from these samples; confirm times near boundaries. Unknown time never displays precise natal longitudes, degrees, ascendant, houses, D9 or dasha timing. Approximate houses/ascendant are provisional; D9 and precise dasha dates are withheld.

Moon-based Ashtakoota remains available only if Moon sign, nakshatra and Vashya group remain unchanged through the entire sampled interval. A stable category does not establish a precise birth time. Boundary changes suppress the single total, rather than averaging incompatible results. Uncertain Western placements/aspects are provisional; specialized synastry should use confirmed time.

## Ashtakoota / Guna Milan

One documented **baseline North Indian** convention is implemented. North/South chart layout selection is graphical and does not change matching tradition. Traditional groom and bride **table roles are explicit operator choices**, not inferences from gender or names. The source convention does not establish validity for every pairing; application text states this limitation. No exceptions or cancellations are applied. The total is traditional points out of 36, not a percentage or scientific likelihood.

Reference matrices: PyJHora `src/jhora/horoscope/match/compatibility.py`, which identifies Saravali-style matrices; downloaded 2026-10-08, with a source snapshot and SHA-256 in `references/`. Copyright Open Astro Technologies; modified by Sundar Sundaresan; AGPL-3.0-or-later. Matrices are reproduced in `matching_tables.py`, not imported as a full unreviewed calculation package. Row = bride role; column = groom role for asymmetric tables.

- **Varna (1):** Moon-sign symbolic ranks: water→Brahmin, fire→Kshatriya, earth→Vaishya, air→Shudra. `VarnaArray` assigns one when groom-role rank is at least bride-role rank. These are historical symbolic labels, not a measure of worth or a claim about actual caste.
- **Vashya (2):** quadruped = Aries/Taurus, latter Sagittarius, first Capricorn; human = Gemini/Virgo/Libra/Aquarius and first Sagittarius; aquatic = Cancer/Pisces and latter Capricorn; forest = Leo; insect = Scorpio. Splits occur at 15°. `VasiyaArray` supplies points.
- **Tara (3):** inclusive count `((otherIndex−ownIndex) mod27)+1` in each direction, residue mod9. Adverse residues 3,5,7 get zero; each other direction gets 1.5. This uses the explicitly documented conventional favorable-count rule. The downloaded upstream source currently appears to award points to adverse residues; that code is **not** copied. Thus Astroguru is not claimed to reproduce every upstream total.
- **Yoni (4):** nakshatra animal mapping and full 14×14 `YoniArray`; no sexuality, fertility or anatomical conclusion.
- **Graha Maitri (5):** Moon-sign rulers and the 7×7 natural-friendship score matrix, not compound temporary friendship.
- **Gana (6):** Deva indices 0,4,6,7,12,14,16,21,26; Manushya 1,3,5,10,11,19,20,24,25; remaining indices Rakshasa. Asymmetric `gana_array` uses explicit roles. Categories do not establish behavior.
- **Bhakoot (7):** zero for inclusive Moon-sign distances 2/12,5/9,6/8; seven otherwise.
- **Nadi (8):** standard Adi/Madhya/Antya nakshatra mapping; equal grouping zero, different grouping eight. No health/genetic/fertility prediction is made.

Hand-worked reference fixtures: Ashwini→Ashwini (both Aries, quadruped) = [1,2,3,4,5,6,7,0] = **28**. Groom-role Ashwini/Aries vs bride-role Rohini/Taurus = [1,2,1.5,3,3,5,0,8] = **23.5**; reversing roles changes Varna and Gana. These fixtures check against the reproduced reference matrices and independently counted Tara. All 108×108 pada-center combinations are tested for factor/total bounds. This is reference-table verification, not certification against an independent professional matching service; expert comparison with the provider's preferred convention remains advisable.

## Numerology

Pythagorean only. A–Z map cyclically 1–9; NFKD accent decomposition, ASCII letters retained, punctuation/spaces removed. Optional separate reviewed Latin spelling overrides preserve the original client names. The client form previews the normalized spelling before calculation. Names with no retained Latin letters receive no invented zero-valued name numbers. Non-Latin names need reviewed Latin transliteration; no hidden transliteration is inferred. Y is consonant. Expression sums all letters; Soul Urge vowels A/E/I/O/U; Personality consonants. Birth and current names are calculated separately. Intermediate mappings/totals are reported. Life Path uses a direct digit sum of YYYYMMDD; Birthday uses day of month. Repeated digit reduction retains 11/22/33 in these final totals. Personal Year digit-sums month/day/as-of year and reduces to 1–9 without master retention. Other traditions may use component-wise reductions; these are not silently combined. Chaldean is not offered.

## Date windows

All entered dates use the proleptic Gregorian calendar; the operator must convert any historical local-calendar date before entry. Completed age uses exact anniversaries. Feb 29 anniversaries and year additions use Feb 28 in non-leap years. Bands 0–26→5,27–30→10,31–35→12,36–40→15,41–45→25,46–49→27,50+→30. Historical start=max(birth, as-of minus lookback); first/last partial years show exact ranges. Future end=min(as-of+35 calendar years,70th birthday); future starts the day after as-of. At or after the cutoff no future interval is created. The cutoff does not predict lifespan.

## AI explanation and artwork (1.2.0)

The deterministic generation plan chooses eligible report domains and one job per actual historical/future year interval. Covered dates, life phases, chart values, Guna scores and local rule tables remain authoritative. AI prose is appended to the applicable section/year, with historical content labeled retrospective themes. Jobs outside the local horizon are never created; unknown-time D9/dashas remain withheld. Input names/parental names are omitted. Voluntary notes/interests are opt-in untrusted context. Palm input is limited to aligned photos after separate consent and requires distinct visible-observation/traditional-symbolism labels. No image-less palm observations are generated. A fixed, client-free decorative cover prompt explicitly excludes charts, placements, palm reconstructions and factual labels. Text and images are sent only to the selected API provider after recorded consent. Model outputs are structured and checked, but never certified as truth. Original generated tables/text are preserved with AI-derived versions.
