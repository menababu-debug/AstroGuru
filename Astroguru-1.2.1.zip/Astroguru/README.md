# Astroguru 1.2.1

A runnable local desktop application for client records, palm review, deterministic astrology/numerology, Kundali charts, matchmaking and versioned reports. Python 3.12 + maintained Qt/PySide6; local SQLite with encrypted payloads and photographs; Swiss Ephemeris calculations; ReportLab vector PDF export. No browser server or AI key is required for the local workflow.

## Update from an earlier version

Close Astroguru, make an encrypted backup in Settings, then extract this update into a **new folder** and run `Start-Astroguru.cmd`. Use your existing vault password. The default data location and vault format are unchanged, so existing clients/reports are retained. If you use `ASTROGURU_DATA_DIR`, keep its same value. Do not delete or replace your vault folder.

## Automatic detailed AI reports (1.2.0)

1. In Settings, choose OpenAI or Gemini and set a model you can access. Enter and save your API key; saving a new key enables automatic generation. It is stored in the OS credential manager, never in this source, report or logs. Test the connection (a small API request may be billed).
2. Gemini **does have an official API**: use **Google account · get Gemini API key** to open https://aistudio.google.com/apikey in your browser, sign into Google and create a key. A Google/Gemini website session cannot authorize API calls from Astroguru. OpenAI API keys: https://platform.openai.com/api-keys. Consumer subscriptions are separate from API access/billing.
3. Enable Default to automatic AI generation, choose Detailed or Very detailed, set the automatic PDF folder, and save Settings.
4. Complete a reading or matchmaking profile. On submission choose optional voluntary context, separately consented palm-photo observations and/or one decorative cover image. Review the exact section inputs and record consent from every person. Submit once; section generation, checkpointing, assembly, version saving and PDF export then run automatically.
5. The very detailed plan expands all appropriate life domains and every permitted historical/future year. Actual boundaries, chart tables, traditional scores and uncertainty remain locally calculated. Optional image requests produce decorative artwork only; Kundali charts are never drawn by AI.
6. API limits or cancellation preserve completed sections. Reports → AI generate / resume continues them after renewed consent. Optional artwork failure retains the text/charts. Review the completed report before sharing.

OpenAI cover default: gpt-image-1.5. Gemini cover default: gemini-3.1-flash-image (native generateContent image output); image model is configurable and account-dependent. Some accounts need image-model billing or access approval. No live text/image calls were made here without your credentials.

Without a Gemini API key, Reports → Gemini website · manual prompt prepares a bounded, reviewed prompt and records consent before copying; open Gemini in your own browser and paste it. This alternative is **manual**, not an automated website-login integration. Astroguru does not collect Google passwords or browser session cookies.

Automatic PDFs are unencrypted exported client documents. By default they are saved in the vault directory’s exports folder, or your configured output folder. They are separate from encrypted backups; encrypted report text and artwork remain in the vault and can be exported again.

## Troubleshooting API requests

Settings → Test connection performs a minimal request with no client information, independently of report validation. Saving a new key enables automatic AI for both workflows. Submission still requires the consent dialog to be accepted. Reports show awaiting consent, contacting the provider, received response and paused failures. If automatic generation is off, the local report explicitly says no request was sent; use AI generate / resume. API billing/quota, permissions, unavailable models and network failures have specific redacted errors. Report checkpoints can be resumed. A safe statement that outcomes are not guaranteed no longer triggers rejection; actual guarantees and fabricated percentages remain blocked.

## What changed in 1.1.0

- Modern studio dashboard, dark sidebar, spacious cards and a ten-step reading workflow.
- Five separate client-information pages, then client-right palm and client-left palm on separate pages.
- Rectangular palm alignment with uniform scaling and no mirroring or hand silhouette.
- Optional local plain-background removal, tolerance control, preview and original-background restoration. Original files remain preserved; review fingers and wrist manually.
- Offline city selection fills country, coordinates and a suggested timezone. Same-name cities require explicit selection; manual correction remains available.

## Run locally

Windows 10/11 x64: install **CPython 3.12 x64**, extract this folder, then double-click **Start-Astroguru.cmd**. The first launch installs dependencies in a project-local `.venv`. Alternatively:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

Linux (tested with CPython 3.12):

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

Linux may need Qt's XCB system libraries (`libxcb-cursor0`, `libxkbcommon-x11-0`, plus a desktop display). A source build of pyswisseph needs GCC/G++ and Python development headers if a platform wheel is unavailable. In this Linux environment the interpreter's compiler setting referenced missing clang; `CC=gcc CXX=g++` resolved this. That setting is not required for Windows wheels.

On first launch create a vault password of at least ten characters. There is no recovery backdoor. Default data location is Qt `AppLocalDataLocation` (typically `%LOCALAPPDATA%\Astroguru\Astroguru` on Windows); `ASTROGURU_DATA_DIR` overrides it for a deployment or test. Never point this at a shared unprotected directory.

## Build the Windows executable and installer

Windows builds cannot be produced by the supplied Linux environment. No Windows executable or installer is claimed to be built or tested here.

1. On Windows x64 install CPython 3.12 x64 and **Inno Setup 6**.
2. Extract the complete source directory to a writable local folder.
3. In PowerShell run `powershell -ExecutionPolicy Bypass -File .\build-windows.ps1`.
4. The script installs pinned dependencies, runs tests, and builds `dist\Astroguru\Astroguru.exe` using `Astroguru.spec`.
5. It then creates `windows-delivery\Astroguru-Setup.exe` using `Astroguru.iss`.
6. Distribute the installer, or the **entire** `dist\Astroguru` folder for portable use; the EXE alone is insufficient.
7. Test installation, launch, Credential Manager, a real print driver, SVG/PNG/PDF export, backup/restore and uninstall on a clean Windows machine before commercial rollout. Authenticode signing is optional and requires your signing certificate; this build is unsigned.

The installer is per-user and does not need administrator permission. Uninstall intentionally preserves the client vault; deleting records or deleting the vault is a separate operator action. Corresponding source, license, dependency and build files are included under the bundle's `_internal/source` directory. Qt is dynamically loaded; do not remove license notices or prevent lawful library replacement.

## Test

```sh
python -m pip install -r requirements-dev.txt
QT_QPA_PLATFORM=offscreen python -m pytest -q
```

PowerShell: `$env:QT_QPA_PLATFORM='offscreen'; .venv\Scripts\python.exe -m pytest -q`.

Read **OPERATOR-GUIDE.md**, **RULES.md**, **LICENSING.md**, **LIMITATIONS.md** and **VERIFICATION.md** before using real client records.

## External services and credentials

- **OpenAI / Gemini:** optional API credentials stored only in the OS credential manager. Configure provider/model in Settings; model availability is account-dependent. Explicit consent from each person is required for every generation/resumption. The exact minimized payload is shown. Live requests have not been tested without credentials. The network configuration in this build environment does not allow their API hosts.
- **Offline birthplace search:** geonamescache/GeoNames CC BY 4.0 city/country data, approximately 34,000 cities at the 15,000 population threshold. Selecting a city fills its country; small towns may need manual entry or optional online lookup. No API key, geolocation or internet is needed. Confirm historical timezone/DST and location.
- **OpenStreetMap Nominatim:** optional, user-triggered birthplace lookup, sending only the city/state/country query. No API key required for the public endpoint. Follow public service limits and attribution; this desktop client makes one lookup per explicit action. Network lookup was unavailable for a live test here. Coordinates and historical timezone remain operator-verifiable and editable; manual entry works offline.
- **Swiss Ephemeris:** local built-in Moshier ephemeris, no calculation-service account. This source release is AGPL-3.0-or-later. A proprietary distribution requires resolving both Swiss Ephemeris and PyJHora-table copyleft licensing; purchasing an ephemeris license alone does not relicense the reference tables.
- No cloud storage, telemetry or automatic palm-anatomy validation is used. Optional AI palm interpretation sends only selected aligned images after separate consent. Optional AI artwork is decorative; chart rendering and placement calculations remain deterministic.
