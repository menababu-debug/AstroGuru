$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) {
    py -3.12 -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Install CPython 3.12 x64 from python.org first.' }
}
$AstroguruPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $AstroguruPython -m pip install -r requirements-dev.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
$env:QT_QPA_PLATFORM = 'offscreen'
& $AstroguruPython -m pytest -q
if ($LASTEXITCODE -ne 0) { throw 'Verification failed; packaging stopped.' }
Remove-Item Env:QT_QPA_PLATFORM
& $AstroguruPython -m PyInstaller --clean --noconfirm Astroguru.spec
if ($LASTEXITCODE -ne 0) { throw 'Executable build failed.' }
$AstroguruIscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
if ($AstroguruIscc) { $AstroguruCompiler = $AstroguruIscc.Source }
else { $AstroguruCompiler = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe' }
if (-not (Test-Path $AstroguruCompiler)) {
    throw 'Astroguru.exe built. Install Inno Setup 6, then run ISCC.exe Astroguru.iss to create the installer.'
}
& $AstroguruCompiler Astroguru.iss
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed.' }
Write-Host 'Executable: dist\Astroguru\Astroguru.exe'
Write-Host 'Installer: windows-delivery\Astroguru-Setup.exe'
Write-Host 'Windows live-provider, print-driver and clean-machine installation checks still require operator verification.'
