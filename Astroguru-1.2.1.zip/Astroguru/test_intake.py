"""Regression tests for the operator-requested 1.1 intake improvements."""
import io,os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PIL import Image,ImageDraw
from PySide6.QtWidgets import QApplication,QFileDialog
from PySide6.QtCore import QDate
from widgets import ProfileForm,PalmPanel
from storage import Store
from imaging import clear_background

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])

def test_pages_and_country_autofill(app):
    form=ProfileForm();assert form.stack.count()==5;assert form.fields['country'].isReadOnly();assert form.value()['birth_time']==''
    with pytest.raises(ValueError):form.next_page()
    form.fields['first_name'].setText('Fictional');form.next_page();assert form.stack.currentIndex()==1;form.next_page();assert form.stack.currentIndex()==2
    form.fields['city'].setText('New Delhi');form.autofill_unique_city();value=form.value();assert value['country']=='India' and value['timezone']=='Asia/Kolkata';assert value['birthplace_resolution']['source']=='offline GeoNames';assert not value['location_verified']
    with pytest.raises(ValueError):form.next_page()
    form.fields['location_verified'].setChecked(True);form.next_page();assert form.stack.currentIndex()==3;form.next_page();assert form.stack.currentIndex()==4
    form.previous_page();assert form.fields['first_name'].text()=='Fictional';form.deleteLater()

def test_same_name_city_requires_choice(app):
    from places import exact_matches
    rows=exact_matches('Springfield');assert len(rows)>1
    form=ProfileForm();form.fields['city'].setText('Springfield');form.autofill_unique_city();assert not form.fields['country'].text()
    form.choose_offline_place(rows[0]['label']);assert form.fields['country'].text()==rows[0]['country'];assert form.fields['city'].text()=='Springfield'
    form.country_override.setChecked(True);assert not form.fields['country'].isReadOnly();form.fields['country'].setText('Manually corrected');assert form.value()['country']=='Manually corrected';form.deleteLater()

def test_verification_reset_and_new_profile(app):
    form=ProfileForm();form.fields['first_name'].setText('Fictional');form.fields['city'].setText('New Delhi');form.autofill_unique_city();form.fields['location_verified'].setChecked(True);form.fields['latitude'].setValue(20);assert not form.value()['location_verified']
    form.fields['notes'].setPlainText('Old profile note');form.palms={'right':{'hand':'right'}};form.reset();assert form.value()['notes']=='' and form.value()['palms']=={} and form.value()['country']=='' and form.stack.currentIndex()==0;form.deleteLater()

def fixture_image():
    image=Image.new('RGB',(300,450),'white');draw=ImageDraw.Draw(image);draw.rectangle((70,50,230,400),fill=(120,80,50));draw.rectangle((120,180,160,220),fill='white');buffer=io.BytesIO();image.save(buffer,format='PNG');return buffer.getvalue()

def test_background_preserves_internal_detail_and_original():
    original=fixture_image();result=Image.open(io.BytesIO(clear_background(original,35))).convert('RGBA');assert result.getpixel((0,0))[3]==0;assert result.getpixel((130,190))==(255,255,255,255);assert result.getpixel((80,60))==(120,80,50,255);assert Image.open(io.BytesIO(original)).getpixel((0,0))==(255,255,255)
    with pytest.raises(ValueError):clear_background(original,101)

@pytest.mark.parametrize('hand',['right','left'])
def test_rectangular_hand_alignment_background_restore(app,tmp_path,monkeypatch,hand):
    store=Store(tmp_path/'vault','secure-password');panel=PalmPanel(hand,store);photo=tmp_path/'photo.png';photo.write_bytes(fixture_image());monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(photo),''));panel.upload()
    assert panel.guide.rect().width()==398 and panel.item.parentItem() is panel.clip;assert panel.original==photo.read_bytes();assert panel.item.scale()>0 and panel.item.transform().isIdentity()
    panel.background_ready(clear_background(panel.original));assert panel.background_removed
    for check in panel.checks:check.setChecked(True)
    panel.reason.setText('Synthetic fixture reviewed');panel.confirm();record=panel.record();assert record['hand']==hand and record['mirrored'] is False and record['background_removed'];assert store.read_asset(record['original'])==photo.read_bytes()
    aligned=Image.open(io.BytesIO(store.read_asset(record['aligned'])));assert aligned.size==(800,1240) and aligned.mode=='RGBA';assert aligned.getpixel((10,10))[3]==0
    panel.restore_background();assert not panel.background_removed
    with pytest.raises(ValueError):panel.record()
    panel.item.setPos(-1000,-1000)
    for check in panel.checks:check.setChecked(True)
    panel.confirm();assert Image.open(io.BytesIO(store.read_asset(panel.record()['aligned']))).getbbox() is None
    panel.clear();assert panel.record() is None;panel.deleteLater();store.close()

def test_wizard_ten_steps_and_back(app,tmp_path):
    from app import MainWindow
    store=Store(tmp_path/'vault','secure-password');window=MainWindow(store);wizard=window.wizard;assert wizard.pages.count()==6 and wizard.progress.maximum()==10
    wizard.form.fields['first_name'].setText('Fictional');wizard.advance();assert wizard.form.stack.currentIndex()==1 and wizard.progress.value()==2;wizard.previous();assert wizard.form.stack.currentIndex()==0
    wizard.form.fields['city'].setText('New Delhi');wizard.form.autofill_unique_city();wizard.form.fields['location_verified'].setChecked(True)
    for _ in range(5):wizard.advance()
    assert wizard.pages.currentIndex()==1 and wizard.steps.text().startswith('STEP 06');assert wizard.palms['right'].hand=='right'
    wizard.skip_palm();assert wizard.pages.currentIndex()==2 and wizard.palms['left'].hand=='left';wizard.skip_palm();assert wizard.pages.currentIndex()==3
    wizard.asof.setDate(QDate(2026,10,8));wizard.advance();assert wizard.pages.currentIndex()==4 and 'India' in wizard.review.toPlainText()
    with pytest.raises(ValueError):wizard.advance()
    wizard.confirm.setChecked(True);wizard.advance();assert wizard.progress.value()==10;wizard.previous();assert not wizard.confirm.isChecked();window.close();store.close()

def test_online_country_comes_from_selected_place():
    from places import online_place
    row=online_place({'name':'Small Town','lat':'25','lon':'73','address':{'town':'Small Town','state':'Rajasthan','country':'India','country_code':'in'}});assert row['country']=='India' and row['city']=='Small Town' and row['countrycode']=='IN'

def test_background_worker_completes_and_requires_review(app,tmp_path,monkeypatch):
    import time
    store=Store(tmp_path/'vault','secure-password');panel=PalmPanel('right',store);photo=tmp_path/'photo.png';photo.write_bytes(fixture_image());monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(str(photo),''));panel.upload();panel.remove_background()
    deadline=time.monotonic()+10
    while panel.background_worker.isRunning() and time.monotonic()<deadline:app.processEvents();panel.background_worker.wait(10)
    app.processEvents();assert panel.background_removed and panel.restore_button.isEnabled();assert not any(check.isChecked() for check in panel.checks);assert panel.original==photo.read_bytes();panel.deleteLater();store.close()
