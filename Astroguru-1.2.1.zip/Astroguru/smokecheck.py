"""Offline synthetic-data smoke test for source and frozen distributions."""
import tempfile,json,uuid,datetime as dt
from pathlib import Path

def run(app):
    from storage import Store
    from app import MainWindow
    import core,reports,matching,charts
    from PySide6.QtCore import QDate
    result={}
    with tempfile.TemporaryDirectory(prefix='astroguru-self-test-') as folder:
        folder=Path(folder);s=Store(folder/'vault','synthetic-test-password');w=MainWindow(s);w.show();app.processEvents();result['desktop']=w.pages.count()==6
        p={'first_name':'Fictional','last_name':'Test','birth_date':'1990-01-01','birth_time':'12:00:00','accuracy':'exact','latitude':28.6139,'longitude':77.209,'timezone':'Asia/Kolkata','city':'New Delhi','country':'India','location_verified':True,'notes':'Synthetic diagnostic data only.'}
        w.wizard.form.load(p);w.wizard.confirm.setChecked(True);w.wizard.asof.setDate(QDate(2026,10,8));w.wizard.generate();result['report_saved']=len(s.all('reports'))==1
        report=w.report_page.current;c=report['calculations'][0];reports.export_pdf(report,folder/'natal.pdf');result['pdf']=(folder/'natal.pdf').stat().st_size>1000
        charts.png(charts.svg(c),folder/'chart.png');result['png']=(folder/'chart.png').stat().st_size>1000
        m=matching.match(c,c,'groom',{'western':True,'numerology':True});pair=dict(report,calculations=[c,c],kind='matchmaking',original_text=reports.text(reports.match_sections(c,c,m)));reports.export_pdf(pair,folder/'matching.pdf');result['matchmaking']=0<=m['total']<=36
        key=s.all('clients')[0][0];backup=folder/'test.agbk';s.backup(backup);s.delete_client(key);s.restore(backup,'synthetic-test-password');result['backup_restore']=len(s.all('clients'))==1 and len(s.all('reports'))==1
        result['timezonefinder']=False
        from timezonefinder import TimezoneFinder
        result['timezonefinder']=TimezoneFinder().timezone_at(lat=28.6139,lng=77.209)=='Asia/Kolkata'
        w.close();s.close()
    print(json.dumps(result,sort_keys=True));return 0 if all(result.values()) else 1

if __name__=='__main__':
    import os
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    raise SystemExit(run(QApplication([])))
