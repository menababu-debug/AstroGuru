# Verification record

Environment: Linux x86_64, CPython 3.12.14, Qt/PySide6 6.12.0; verification date 2026-10-08. Headless Qt used the genuine offscreen platform; there is no display server in this environment.

## Verified

- **42 automated tests** (`QT_QPA_PLATFORM=offscreen python -m pytest -q`).
- Every requested historical band boundary, completed-age anniversary, pre-birth rejection, partial years, future 35-year/70th-birthday cutoff, ended horizon and Feb 29 policy.
- India standard/historical wartime offset, New York DST summer/winter, nonexistent/ambiguous local times and explicit fold handling. A historically skipped Samoa date is rejected.
- Pythagorean arithmetic, intermediate/name normalization and master-number policies.
- J2000 Sun/Moon Swiss Ephemeris fixtures; consistent engine sidereal frame, D9 mapping, house/pada bounds and dasha subperiod coverage. The J2000 fixture verifies the selected ephemeris regression, not an independent NASA-service certification.
- Unknown/approximate times, boundary-crossing matching uncertainty, D9/Manglik withholding and annual-transit horizon limits.
- Explicit matching-role validation, role asymmetry, hand-worked reference-table cases and exhaustive bounds for **11,664** pada-center pairings (108×108).
- Both SVG layouts and D1/D9 parsing; PNG encoding/dimensions; real Qt form/palm uniform alignment; preserved original and encrypted aligned crop; changed alignment requires reconfirmation.
- Vault/client CRUD, duplicate detection, deletion and report links; authenticated encrypted backup/restore across differently keyed vaults; tamper rejection; staged-asset disk-failure rollback.
- Natal and side-by-side matchmaking PDF creation; text extraction confirms contents, chart sections and final summary across multipage reports. Graphics are vector ReportLab primitives translated from the same SVG data. Print preview renders the exact exported PDF; a physical printer was not available.
- Structured AI output schema/language checks, chart-fact/date restatement rejection, transient retry, cancellation, minimized payload and saved-section resumption into a new report version. Provider failures/resumption are tested with fakes; no live provider calls are claimed.
- Genuine Qt desktop mounting with six sidebar pages; full source smoke test creates a synthetic client, calculates, saves, exports natal/matching PDF and PNG, authenticates backup/restore and loads timezone-boundary data.
- **Linux PyInstaller desktop bundle compiled and passed `--self-test`** with all seven checks true. This verifies frozen dependency imports and local flow on this Linux host. It does not establish Windows installer compatibility.

## Not verified here

Windows compilation and clean-machine installer, real Windows Credential Manager, actual provider/model authorization, live Nominatim lookup, a physical printer, Authenticode signing or specialist certification against an independent commercial matching service. See LIMITATIONS.md and licensing requirements before rollout.

## Reproduce

```sh
python -m pip install -r requirements-dev.txt
QT_QPA_PLATFORM=offscreen python -m pytest -q
python app.py --self-test
python -m PyInstaller --noconfirm Astroguru.spec
QT_QPA_PLATFORM=offscreen dist/Astroguru/Astroguru --self-test
```

On Windows, `build-windows.ps1` runs the tests before building the exact requested EXE and installer names. Source and frozen `--self-test` use only temporary synthetic records; they never send data to an external service.
