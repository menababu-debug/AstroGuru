"""Qt client form and uniform-scale, manually reviewed palm alignment."""
import io,datetime as dt
from PIL import Image,ImageOps,ImageStat,ImageFilter
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QDate,QTime,QRectF,QBuffer,QIODevice
from PySide6.QtGui import QPixmap,QImage,QPainter,QPainterPath,QPen,QColor
from PySide6.QtSvgWidgets import QGraphicsSvgItem
from PySide6.QtSvg import QSvgRenderer
from core import validate,spelling

class ProfileForm(QWidget):
    def __init__(self,profile=None):
        super().__init__();self.fields={};self.profile_id=None;self.palms={}
        layout=QVBoxLayout(self);hint=QLabel('Birth information stays in the encrypted local vault. Verify coordinates and the historical timezone before calculating.');hint.setWordWrap(True);layout.addWidget(hint)
        scroll=QScrollArea();scroll.setWidgetResizable(True);inside=QWidget();form=QFormLayout(inside);form.setSpacing(12);scroll.setWidget(inside);layout.addWidget(scroll)
        def line(key,label,default=''):
            w=QLineEdit(default);self.fields[key]=w;form.addRow(label,w);return w
        for key,label in [('first_name','Birth first name *'),('last_name','Last name'),('current_name','Current name (optional)'),('father_name','Father’s name'),('mother_name','Mother’s name')]:line(key,label)
        line('numerology_birth_spelling','Reviewed Latin birth spelling (optional override)')
        line('numerology_current_spelling','Reviewed Latin current spelling (optional override)')
        name_preview=QLabel();name_preview.setWordWrap(True);form.addRow('Spelling used for name numbers',name_preview)
        def preview_names():
            birth=self.fields['numerology_birth_spelling'].text() or self.fields['first_name'].text()+' '+self.fields['last_name'].text()
            current=self.fields['numerology_current_spelling'].text() or self.fields['current_name'].text()
            name_preview.setText('Birth: '+(spelling(birth) or 'unavailable — enter reviewed Latin spelling')+'; Current: '+(spelling(current) or 'not supplied'))
        for key in ['first_name','last_name','current_name','numerology_birth_spelling','numerology_current_spelling']:self.fields[key].textChanged.connect(preview_names)
        preview_names()
        gender=QComboBox();gender.addItems(['Decline to specify','Woman','Man','Nonbinary','Self-describe']);self.fields['gender']=gender;form.addRow('Gender',gender);line('gender_description','Self-description')
        date=QDateEdit(QDate(1990,1,1));date.setCalendarPopup(True);date.setDisplayFormat('yyyy-MM-dd');date.setMaximumDate(QDate.currentDate());date.setMinimumDate(QDate(1800,1,1));self.fields['birth_date']=date;form.addRow('Birth date *',date)
        time=QTimeEdit(QTime(12,0));time.setDisplayFormat('HH:mm:ss');self.fields['birth_time']=time;form.addRow('Birth time (seconds if known)',time)
        accuracy=QComboBox();accuracy.addItems(['unknown','approximate','exact']);self.fields['accuracy']=accuracy;form.addRow('Time accuracy *',accuracy)
        uncertainty=QSpinBox();uncertainty.setRange(1,720);uncertainty.setValue(60);self.fields['uncertainty_minutes']=uncertainty;form.addRow('Approximate time ± minutes',uncertainty)
        accuracy.currentTextChanged.connect(lambda value:(time.setEnabled(value!='unknown'),uncertainty.setEnabled(value=='approximate')));time.setEnabled(False);uncertainty.setEnabled(False)
        for key,label in [('city','Birth city / town *'),('state','State / province'),('country','Birth country *')]:line(key,label)
        geo=QPushButton('Look up birthplace coordinates (OpenStreetMap)');form.addRow('',geo);geo.clicked.connect(self.resolve)
        for key,label,minimum,maximum in [('latitude','Latitude *',-90,90),('longitude','Longitude *',-180,180)]:
            w=QDoubleSpinBox();w.setRange(minimum,maximum);w.setDecimals(6);self.fields[key]=w;form.addRow(label,w)
        line('timezone','IANA historical timezone *','Asia/Kolkata')
        verified=QCheckBox('Operator has verified coordinates and historical timezone');self.fields['location_verified']=verified;form.addRow('',verified)
        fold=QComboBox();fold.addItems(['First occurrence (fold 0)','Second occurrence (fold 1)']);self.fields['fold']=fold;form.addRow('Ambiguous DST birth time',fold)
        foldcheck=QCheckBox('DST occurrence verified, if this time is ambiguous');self.fields['fold_confirmed']=foldcheck;form.addRow('',foldcheck)
        hand=QComboBox();hand.addItems(['Right','Left','Ambidextrous','Unknown']);self.fields['dominant_hand']=hand;form.addRow('Dominant hand',hand)
        lang=QComboBox();lang.addItems(['English']);self.fields['language']=lang;form.addRow('Report language',lang)
        for key,label in [('interests','Voluntary interests and skills'),('notes','Client-confirmed events / consultation notes')]:
            w=QPlainTextEdit();w.setMaximumHeight(100);self.fields[key]=w;form.addRow(label,w)
        label=QLabel('Unknown time: no invented ascendant, houses, D9 or precise dasha dates. Approximate time: provisional houses; D9 is withheld. Parental names do not improve astronomical accuracy. Non-Latin names require reviewed Latin spelling for numerology.');label.setWordWrap(True);form.addRow(label)
        if profile:self.load(profile)
    def value(self):
        p={}
        for key,w in self.fields.items():
            if isinstance(w,QDateEdit):p[key]=w.date().toString('yyyy-MM-dd')
            elif isinstance(w,QTimeEdit):p[key]=w.time().toString('HH:mm:ss')
            elif isinstance(w,QComboBox):p[key]=w.currentIndex() if key=='fold' else w.currentText()
            elif isinstance(w,QCheckBox):p[key]=w.isChecked()
            elif isinstance(w,(QSpinBox,QDoubleSpinBox)):p[key]=w.value()
            elif isinstance(w,QPlainTextEdit):p[key]=w.toPlainText()
            else:p[key]=w.text().strip()
        if p['gender']=='Self-describe':p['gender']='Self-describe: '+p['gender_description']
        if p['accuracy']=='unknown':p['birth_time']=''
        p['palms']=self.palms
        return p
    def load(self,p):
        self.palms=p.get('palms',{})
        for key,w in self.fields.items():
            if key not in p:continue
            v=p[key]
            if isinstance(w,QDateEdit):w.setDate(QDate.fromString(v,'yyyy-MM-dd'))
            elif isinstance(w,QTimeEdit):
                if v:w.setTime(QTime.fromString(v,'HH:mm:ss'))
            elif isinstance(w,QComboBox):
                if key=='fold':w.setCurrentIndex(int(v))
                elif str(v).startswith('Self-describe:'):w.setCurrentText('Self-describe');self.fields['gender_description'].setText(v.split(':',1)[1].strip())
                else:w.setCurrentText(str(v))
            elif isinstance(w,QCheckBox):w.setChecked(bool(v))
            elif isinstance(w,(QSpinBox,QDoubleSpinBox)):w.setValue(v)
            elif isinstance(w,QPlainTextEdit):w.setPlainText(v)
            else:w.setText(str(v))
    def checked(self):
        p=self.value();validate(p)
        if not p['city'] or not p['country']:raise ValueError('Birth city and country are required.')
        if not p['location_verified']:raise ValueError('Verify coordinates and historical timezone before continuing.')
        return p
    def resolve(self):
        query=', '.join(self.fields[k].text() for k in ['city','state','country'])
        # Explicit user-triggered location-only query; no names, date/time, palms or notes.
        from PySide6.QtCore import QThread,Signal
        class Lookup(QThread):
            done=Signal(object);failed=Signal(str)
            def run(self):
                import urllib.request,urllib.parse,json
                try:
                    req=urllib.request.Request('https://nominatim.openstreetmap.org/search?format=json&limit=5&q='+urllib.parse.quote(query),headers={'User-Agent':'Astroguru/1.0 (desktop birthplace lookup)'})
                    data=json.load(urllib.request.urlopen(req,timeout=20));self.done.emit(data)
                except Exception:self.failed.emit('Location lookup unavailable. Enter verified coordinates and an IANA timezone manually. No automatic lookup result was accepted.')
        if getattr(self,'lookup',None) and self.lookup.isRunning():return
        self.lookup=Lookup(self);self.lookup.done.connect(self.resolved);self.lookup.failed.connect(lambda msg:QMessageBox.information(self,'Birthplace lookup',msg));self.lookup.start()
    def resolved(self,rows):
        if not rows:QMessageBox.information(self,'Birthplace lookup','No match. Enter verified coordinates manually.');return
        names=[r['display_name'] for r in rows];choice,ok=QInputDialog.getItem(self,'Verify birthplace','OpenStreetMap © contributors. Select the correct location:',names,0,False)
        if not ok:return
        r=rows[names.index(choice)];self.fields['latitude'].setValue(float(r['lat']));self.fields['longitude'].setValue(float(r['lon']));self.fields['location_verified'].setChecked(False)
        try:
            from timezonefinder import TimezoneFinder
            zone=TimezoneFinder().timezone_at(lat=float(r['lat']),lng=float(r['lon']))
            if zone:self.fields['timezone'].setText(zone)
        except ImportError:pass
        QMessageBox.information(self,'Verify historical timezone','Coordinates are populated. Verify the timezone on the birth date, including historical boundary changes. IANA timezone data applies historical DST rules after the zone is confirmed.')

GUIDE='M 165 585 C 156 550 130 520 100 480 L 45 390 C 27 360 42 332 65 346 L 118 406 L 120 200 C 120 166 151 162 156 197 L 166 332 L 167 100 C 167 63 200 64 204 100 L 212 326 L 214 70 C 214 34 248 35 251 70 L 257 328 L 265 105 C 269 73 300 78 299 112 L 301 344 L 321 205 C 327 173 357 185 352 214 L 337 406 C 342 487 308 535 300 585 Z'

class PalmPanel(QWidget):
    def __init__(self,hand,store):
        super().__init__();self.hand=hand;self.store=store;self.original=None;self.item=None;self.confirmed_record=None
        l=QVBoxLayout(self);info=QLabel(f'{hand.title()} palm · Show all fingers, complete palm and a little wrist. Use soft even light, a plain background and a sharp photograph. Drag to position; zoom uniformly and rotate. The frame crops the aligned copy.');info.setWordWrap(True);l.addWidget(info)
        self.scene=QGraphicsScene(0,0,400,620);self.view=QGraphicsView(self.scene);self.view.setMinimumSize(320,390);self.view.setRenderHint(QPainter.Antialiasing);l.addWidget(self.view,1)
        transform='translate(400 0) scale(-1 1)' if hand=='left' else ''
        guide=f'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="620"><path d="{GUIDE}" transform="{transform}" fill="none" stroke="#8b6bb3" stroke-width="3" stroke-dasharray="8 5"/></svg>'
        self.renderer=QSvgRenderer(guide.encode());self.guide=QGraphicsSvgItem();self.guide.setSharedRenderer(self.renderer);self.guide.setZValue(10);self.scene.addItem(self.guide)
        row=QHBoxLayout();upload=QPushButton('Upload original');upload.clicked.connect(self.upload);row.addWidget(upload);reset=QPushButton('Reset position');reset.clicked.connect(self.reset);row.addWidget(reset);l.addLayout(row)
        form=QFormLayout();self.zoom=QSlider(Qt.Horizontal);self.zoom.setRange(10,300);self.zoom.setValue(100);self.rotation=QSlider(Qt.Horizontal);self.rotation.setRange(-180,180);form.addRow('Uniform zoom',self.zoom);form.addRow('Rotation',self.rotation);l.addLayout(form);self.zoom.valueChanged.connect(self.transform);self.rotation.valueChanged.connect(self.transform)
        self.quality=QLabel('No photograph uploaded. Automatic finger/hand/wrist detection is unavailable.');self.quality.setWordWrap(True);l.addWidget(self.quality)
        self.checks=[]
        for label in [f'I confirm this is the {hand} hand','All fingers, palm and wrist are visible','Focus, exposure and alignment have been manually reviewed']:
            c=QCheckBox(label);self.checks.append(c);l.addWidget(c)
        self.reason=QLineEdit();self.reason.setPlaceholderText('Required manual acceptance reason / observations');l.addWidget(self.reason)
        confirm=QPushButton('Confirm aligned '+hand+' palm');confirm.clicked.connect(self.confirm);l.addWidget(confirm)
        self.status=QLabel('Palm interpretation is optional.');l.addWidget(self.status)
    def resizeEvent(self,event):super().resizeEvent(event);self.view.fitInView(self.scene.sceneRect(),Qt.KeepAspectRatio)
    def upload(self):
        filename,_=QFileDialog.getOpenFileName(self,'Upload '+self.hand+' palm','','Images (*.jpg *.jpeg *.png *.webp *.bmp *.tif *.tiff)')
        if not filename:return
        try:
            from pathlib import Path
            raw=Path(filename).read_bytes()
            if len(raw)>25*1024*1024:raise ValueError('Use an image under 25 MB.')
            im=Image.open(io.BytesIO(raw));im.verify();im=ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert('RGB')
            if im.width*im.height>30_000_000:raise ValueError('Use an image under 30 megapixels.')
            im.thumbnail((3000,3000));self.original=raw
            buf=io.BytesIO();im.save(buf,format='PNG');pix=QPixmap();pix.loadFromData(buf.getvalue())
            if self.item:self.scene.removeItem(self.item)
            self.item=self.scene.addPixmap(pix);self.item.setFlag(QGraphicsItem.ItemIsMovable);self.item.setFlag(QGraphicsItem.ItemIsSelectable);self.item.setTransformOriginPoint(pix.width()/2,pix.height()/2);self.reset()
            gray=im.convert('L');mean=ImageStat.Stat(gray).mean[0];contrast=ImageStat.Stat(gray).stddev[0]
            edge=ImageStat.Stat(gray.filter(ImageFilter.FIND_EDGES)).mean[0]
            hints=[]
            if mean<50 or mean>220:hints.append('Possible poor exposure')
            if contrast<20 or edge<3:hints.append('Possible blur / low detail')
            self.quality.setText('Heuristic warnings: '+('; '.join(hints) if hints else 'none detected; this is not a quality approval')+'. Finger completeness, wrist visibility and hand identity require manual review.')
            self.confirmed_record=None;self.status.setText('Awaiting manual review.')
            for c in self.checks:c.setChecked(False)
        except Exception as e:QMessageBox.warning(self,'Upload error',str(e))
    def reset(self):
        if not self.item:return
        self.base_scale=min(400/self.item.pixmap().width(),620/self.item.pixmap().height());self.zoom.setValue(100);self.rotation.setValue(0);self.item.setRotation(0);self.item.setScale(self.base_scale);self.item.setPos((400-self.item.pixmap().width())/2,(620-self.item.pixmap().height())/2);self.transform()
    def transform(self):
        if self.item:self.item.setScale(self.base_scale*self.zoom.value()/100);self.item.setRotation(self.rotation.value());self.confirmed_record=None;self.status.setText('Alignment changed. Confirm again before continuing.')
    def confirm(self):
        if not self.item:QMessageBox.warning(self,'Manual review','Upload a photograph first.');return
        if not all(c.isChecked() for c in self.checks) or not self.reason.text().strip():QMessageBox.warning(self,'Manual review','Confirm all review items and record an acceptance reason.');return
        try:
            image=QImage(800,1240,QImage.Format_RGB32);image.fill(Qt.white);p=QPainter(image);self.guide.setVisible(False);self.item.setSelected(False);self.scene.render(p,QRectF(0,0,800,1240),self.scene.sceneRect());p.end();self.guide.setVisible(True)
            buf=QBuffer();buf.open(QIODevice.WriteOnly);image.save(buf,'PNG')
            self.confirmed_record={'hand':self.hand,'original':self.store.asset(self.original),'aligned':self.store.asset(bytes(buf.data())),'reason':self.reason.text().strip(),'observations':self.reason.text().strip(),'review':'manual; no anatomical automation','confirmed_at':dt.datetime.now(dt.timezone.utc).isoformat(),'transform':{'scale':self.item.scale(),'rotation':self.item.rotation(),'x':self.item.x(),'y':self.item.y(),'crop':[0,0,400,620]}}
            self.status.setText('Operator acceptance recorded. Original and aligned copies encrypted locally.')
        except Exception as e:QMessageBox.warning(self,'Alignment error',str(e))
    def record(self):
        if self.item and self.confirmed_record:
            pos=self.confirmed_record['transform']
            if self.item.x()!=pos['x'] or self.item.y()!=pos['y']:raise ValueError(f'{self.hand.title()} palm was repositioned. Confirm the new alignment.')
        if self.item and not self.confirmed_record:raise ValueError(f'Confirm {self.hand} palm alignment, or remove it by restarting the reading.')
        return self.confirmed_record
