@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 goto error
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto error
)
.venv\Scripts\python.exe app.py
if errorlevel 1 goto error
exit /b 0
:error
 echo Astroguru could not start. See README.md for setup and troubleshooting.
 pause
 exit /b 1
