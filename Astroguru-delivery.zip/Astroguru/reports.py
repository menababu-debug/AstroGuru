"""Editable, versioned reports built exclusively from calculation snapshots."""
import datetime as dt,json,html
from core import SIGNS,numerology,manglik,positions
from charts import svg,drawing
DISCLAIMER='Astrology, palmistry and numerology are interpretive traditions, not scientific forecasts or verified biography. Choices, communication and circumstances matter. The age-70 cutoff is a report limit, never a lifespan prediction.'
THEMES={'Sun':'identity, purpose and self-expression','Moon':'emotional rhythms and belonging','Mercury':'learning and communication','Venus':'values, appreciation and connection','Mars':'initiative, boundaries and constructive effort','Jupiter':'learning, perspective and generosity','Saturn':'routines, responsibility and patience','Rahu':'novelty and changing priorities','Ketu':'reflection and simplification'}

def placement_lines(c):
    if not c.get('vedic'):return '\n'.join(f"{p}: possible {', '.join(SIGNS[s] for s in r['signs'])}; nakshatra possibilities {', '.join(r['nakshatras'])}" for p,r in c['available_ranges'].items())
    return '\n'.join(f"{p}: {SIGNS[v['sign']]} {v['degree']:.4f}°, house {v['house']}, {v['nakshatra']} pada {v['pada']}"+(' · retrograde' if v['retrograde'] else '') for p,v in c['vedic'].items())

def dasha_at(c,date):
    for row in c.get('dashas',[]):
        if row['start'][:10]<=date<row['end'][:10]:
            sub=next((s['lord'] for s in row['antardashas'] if s['start'][:10]<=date<s['end'][:10]),'')
            return row['lord'],sub
    return None

def timeline(c,future=False):
    h=c['horizons'];rows=h['future' if future else 'history'];out=[];last_phase=None
    if not rows:return 'The permitted future horizon has ended. Natal, historical and present-focused reflection remain available.'
    for r in rows:
        completed=r['year']-int(c['profile']['birth_date'][:4]);phase='Childhood and learning' if completed<18 else 'Young adult development' if completed<30 else 'Adult priorities' if completed<50 else 'Later adult reflection'
        if phase!=last_phase:out.append('Life phase: '+phase);last_phase=phase
        support=dasha_at(c,r['start'])
        if support:
            lord,sub=support;basis=f'Vimshottari {lord}/{sub} at interval start (not necessarily the entire year)';theme=THEMES[lord]
            text=f'Traditional theme: {theme}. Opportunity: review how this theme fits your circumstances. Challenge: avoid treating symbolism as a fixed event. Practical action: record one achievable goal and discuss support needs.'
        else:basis='Birth-time limits prevent reliable dasha timing';text='Present-focused reflection: review learning, relationships, routines and priorities with the client. No specific dated chart interpretation is assigned.'
        transit=next((x for x in c.get('annual_transits',{}).get('future' if future else 'history',[]) if x['year']==r['year']),None)
        context=''
        if transit:
            j=transit['sidereal']['Jupiter'];sat=transit['sidereal']['Saturn'];context=f"\nTransit context sampled {transit['sample_date']}: Jupiter in {SIGNS[j['sign']]} (learning/perspective), Saturn in {SIGNS[sat['sign']]} (routines/responsibility). This is broad sky symbolism; natal-house links are not inferred with uncertain birth time."
        out.append(f"{r['year']} · {r['start']} to {r['end']}\n{basis}. {text}{context}")
    return '\n\n'.join(out)

def western_text(c):
    if not c.get('tropical'):return 'Precise Western natal placements, houses and aspects require confirmed birth time. Collective transit context may still be reviewed separately.'
    out='Separate tropical view. House system: '+c['settings'].get('western_house_system','P')+'. Major aspects use a 6° orb. Not combined with Vedic interpretations.\n'
    for name,p in c['tropical'].items():out+=f"{name}: {SIGNS[p['sign']]} {p['degree']:.4f}°"+(' R' if p['retrograde'] else '')+'\n'
    out+='House cusps: '+', '.join(f"{i+1}: {SIGNS[int(lon/30)]} {lon%30:.3f}°" for i,lon in enumerate(c['western_cusps']))+'\n'
    for x in c['western_aspects']:out+=f"{x['a']} {x['aspect']} {x['b']}; orb {x['orb']}°\n"
    out+='Birth-time accuracy: '+c['accuracy']+'. Moon aspects and houses are time-sensitive; approximate-time results are provisional.\n'
    for name in ['Jupiter','Saturn']:
        p=c['western_transits'][name];out+=f"As-of tropical transit {name}: {SIGNS[p['sign']]} {p['degree']:.3f}°. Reflection: {THEMES[name]}.\n"
    return out

def d9_text(c):
    if not c.get('d9_allowed'):return 'D9 interpretation withheld: birth-time accuracy does not support precise divisional interpretation.'
    out='Confirmed-time D9 sign symbolism, interpreted separately from D1; advanced spouse/outcome rules are not assigned.\n'
    for name,p in c['vedic'].items():out+=name+' in '+SIGNS[p['navamsha_sign']]+': reflect on '+THEMES[name]+'.\n'
    return out

def natal_sections(c,palms=None,intimacy=False):
    p=c['profile'];n=c.get('numerology') or numerology(p,int(c['settings']['as_of'][:4]));adult=c['horizons']['age']>=18
    details='\n'.join(f'{key.replace("_"," ").title()}: {p.get(key,"")}' for key in ['first_name','last_name','current_name','father_name','mother_name','gender','birth_date','birth_time','accuracy','city','state','country','latitude','longitude','timezone','dominant_hand','language'])
    settings=json.dumps(c['settings'],indent=2)+'\n'+c['engine']+' · '+c['backend']+'\nCalculated '+c['calculated_at']+'\nUTC: '+c.get('utc','unavailable')+'; historical offset '+c.get('utc_offset','unavailable')+'\n'+'\n'.join(c['warnings'])+'\nParental names are client information; they do not affect astronomical calculations.'
    interpretation='\n'.join(f"{name} in {SIGNS[v['sign']]}: traditionally invites reflection on {THEMES[name]}." for name,v in c.get('vedic',{}).items())
    if c.get('ascendant'):interpretation+='\nAscendant: '+SIGNS[c['ascendant']['sign']]+(' (provisional)' if c['accuracy']!='exact' else '')
    num='System: '+n['system']+'\n'
    for key in ['Life Path','Birthday','Personal Year']:num+=f"{key}: {' → '.join(map(str,n[key]['steps']))}\n"
    for label in ['birth_name','current_name']:
        if n.get(label):
            if n[label].get('available') is False:
                num+=label+': '+n[label]['reason']+'\n';continue
            num+=label.replace('_',' ').title()+': '+n[label]['spelling']+'\nMapping '+str(n[label]['mapping'])+'\n'
            for key in ['Expression','Soul Urge','Personality']:num+=key+': '+' → '.join(map(str,n[label][key]['steps']))+'\n'
    palm='Palmistry is optional. No automated anatomical quality check or AI image interpretation has been performed.'
    for hand,record in (palms or p.get('palms',{})).items():palm+=f"\n{hand.title()} palm: operator-confirmed hand; manual acceptance reason: {record.get('reason','')}. Observations: {record.get('observations','None supplied')}. Observations are not medical findings or proof of future events."
    domains=[('Education and learning','Which interests and skills does the client want to develop? Plan a manageable learning routine.'),('Family life','Discuss support needs, boundaries and family expectations without assigning blame.'),('Relationships and communication','Discuss appreciation, listening and respectful disagreement. No claim about affairs or relationship outcomes is made.'),('Work and career exploration','Compare client-stated interests and skills with exploratory roles and environments. Avoid a prescribed career.'),('Money-management habits','Discuss budgeting, emergency savings and habits with appropriate professional advice when needed.'),('Travel and relocation','Reflect on practical constraints, goals and support networks; no guaranteed travel dates.'),('General wellbeing','Reflect on sleep, movement, rest and social support. Seek professional care for health concerns.'),('Resilience and personal development','Choose a small routine, track effort and identify people who can offer support.')]
    if adult:domains.extend([('Marriage and household themes','Explore shared expectations, responsibilities and communication; no instruction to marry or reject anyone.'),('Parenting themes','Discuss voluntarily stated caregiving values; no fertility, pregnancy or child-sex predictions.')])
    if adult and intimacy:domains.append(('Consented adult intimacy reflection','Discuss boundaries, mutual consent, privacy and comfort. No sexual behavior is inferred from charts or palms.'))
    sections=[('Client details',details),('Accuracy and calculation settings',settings),('Natal chart facts',placement_lines(c)),('Traditional natal interpretation',interpretation or 'Precise natal interpretation requires confirmed birth time.'),('D9 Navamsha reflection',d9_text(c)),('Traditional yogas and Manglik rules',json.dumps(c.get('yogas',[]),indent=2)+'\n'+json.dumps(manglik(c),indent=2)),('Separate modern Western view',western_text(c)),('Numerology',num),('Optional palm review',palm),('Historical retrospective themes',timeline(c)),('Future themes',timeline(c,True))]
    sections.extend(domains)
    sections+=[('Client-confirmed life events and notes','Supplied by the client/operator, not independently discovered:\n'+p.get('notes','None supplied.')),('Optional practices and practical suggestions','Traditional spiritual options: culturally appropriate prayer, meditation, charity or mantras, if desired. Practical actions: journaling, manageable routines and respectful conversation. No guaranteed outcome or costly ritual is required.'),('Final balanced summary','Recurring symbolic themes are invitations for reflection. Strengths can be developed through choices and habits. Birth accuracy and interpretive traditions limit certainty. Agree on practical next steps with the client.\n\n'+DISCLAIMER)]
    return sections

def match_sections(a,b,m):
    factors='\n'.join(f"{x['factor']}: {x['score']} / {x['maximum']} — {x['meaning']}" for x in m['factors'])
    total=str(m['total'])+' / 36 traditional points' if m['total'] is not None else m['unavailable_reason']
    profiles='\n\n'.join(f"Person {i+1}: {c['profile']['first_name']} {c['profile'].get('last_name','')}\nBirth: {c['profile']['birth_date']}; time: {c['profile']['birth_time'] if c['accuracy']!='unknown' else 'unknown'}; accuracy: {c['accuracy']}\nLocation: {c['profile']['city']}, {c['profile']['country']}; {c['profile']['latitude']}, {c['profile']['longitude']}; zone {c['profile']['timezone']}\n"+'\n'.join(c['warnings']) for i,c in enumerate([a,b]))
    rules=m['tradition']+f"\nPerson 1 role: {m['role_a']}; person 2 role: {m['role_b']}\n"+m['pairing_limitation']+'\n'+m['reference']+'\nCalculation snapshots and settings are preserved with this report.'
    assessments='\n\n'.join(f'Person {i+1}: '+json.dumps(x) for i,x in enumerate(m['manglik']))
    assessments+='\nD9: '+', '.join('available' if c['d9_allowed'] else 'withheld because birth-time accuracy does not support it' for c in [a,b])+'.\nPerson 1 D9 reflection: '+d9_text(a)+'\nPerson 2 D9 reflection: '+d9_text(b)
    sections=[('Both profiles and birth accuracy',profiles),('Calculation settings and matching roles',rules+'\nPerson 1: '+json.dumps(a['settings'])+'\nPerson 2: '+json.dumps(b['settings'])),('Both Kundali placement tables','Person 1\n'+placement_lines(a)+'\n\nPerson 2\n'+placement_lines(b)),('Ashtakoota score breakdown',total+'\n'+factors+'\n'+m.get('accuracy_explanation','')+'\n'+m['warning']),('Additional traditional assessments',assessments),('Emotional and communication themes','Compare each person’s stated needs, listening style and preferred approach to disagreement. Moon-sign symbolism is interpretive, not proof of behavior.'),('Values, family expectations and lifestyle','Discuss household roles, cultural practices, family involvement and the routines each person prefers.')]
    adult=all(c['horizons']['age']>=18 for c in [a,b])
    if m['options'].get('intimacy') and adult:sections.append(('Explicitly consented adult intimacy reflection','Discuss mutual consent, boundaries, privacy and comfort. No intimate behavior is predicted.'))
    sections.extend([('Work, money-management and travel','Discuss work schedules, spending habits, savings priorities and travel preferences. No financial returns are predicted.'),('Potential strengths and areas for discussion','Use the factor meanings as conversation prompts. Agree on one strength to support and one issue to discuss without using chart scores to blame either person.'),('Optional practices and practical suggestions','If both people wish, use culturally appropriate meditation, prayer or charity. Practical options include shared planning, journaling and respectful conversations. No practice is required.')])
    if 'western_synastry' in m:sections.append(('Optional Western synastry',json.dumps(m['western_synastry'],indent=2)+'\nTropical aspects, 6° orb, kept separate from Guna Milan.'))
    if 'numerology' in m:sections.append(('Optional Pythagorean numerology',json.dumps(m['numerology'],indent=2)+'\nSeparate symbolic reflection, with no combined percentage.'))
    if m['options'].get('reflection'):sections.append(('Voluntarily supplied concerns',m['options'].get('concerns','No concerns supplied.')))
    sections.append(('Permitted dasha and transit context','Person 1 future limit: '+a['horizons']['future_end']+'; person 2: '+b['horizons']['future_end']+'.\nDasha at as-of date: '+str(dasha_at(a,a['settings']['as_of']))+' / '+str(dasha_at(b,b['settings']['as_of']))+'.\nYear-by-year dasha and midpoint Jupiter/Saturn transit contexts are preserved below. These are symbolic reflection themes, not dated relationship predictions.'))
    sections.append(('Person 1 permitted future themes',timeline(a,True)))
    sections.append(('Person 2 permitted future themes',timeline(b,True)))
    sections.append(('Final balanced summary',m['warning']+'\nDiscuss strengths, differences, uncertainties and practical choices together. No prediction of affairs, divorce, abuse, fertility or children is made.\n\n'+DISCLAIMER))
    return sections

def text(sections):return '\n\n'.join('## '+title+'\n'+body for title,body in sections)

def parse_text(value):
    sections=[]
    for chunk in value.split('## '):
        if not chunk.strip():continue
        title,_,body=chunk.partition('\n');sections.append((title.strip(),body.strip()))
    return sections

def export_pdf(report,path,provider='Astroguru',logo=None):
    from reportlab.platypus import BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,PageBreak,Table,TableStyle,KeepTogether
    from reportlab.platypus.tableofcontents import TableOfContents
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4,landscape
    from reportlab.graphics import renderPDF
    chartlist=report['calculations'];page_size=landscape(A4) if len(chartlist)>1 else A4
    page_width,page_height=page_size
    styles=getSampleStyleSheet();styles['Normal'].fontSize=10;styles['Normal'].leading=15
    styles['Heading1'].textColor=colors.HexColor('#64537f')
    class Doc(BaseDocTemplate):
        def afterFlowable(self,f):
            if isinstance(f,Paragraph) and f.style.name=='Heading1':self.notify('TOCEntry',(0,f.getPlainText(),self.page))
    def footer(canvas,doc):
        canvas.setTitle('Astroguru report');canvas.setAuthor(provider);canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#64537f'));canvas.drawString(42,25,provider+' · Interpretive reading');canvas.drawRightString(page_width-42,25,str(doc.page))
    doc=Doc(str(path),pagesize=page_size,leftMargin=42,rightMargin=42,topMargin=45,bottomMargin=45)
    doc.addPageTemplates(PageTemplate(id='main',frames=[Frame(42,45,page_width-84,page_height-90,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=footer))
    story=[Spacer(1,80),Paragraph('Astroguru',styles['Title']),Paragraph(html.escape(report['title']),styles['Heading2']),Paragraph(html.escape(provider),styles['Normal']),Paragraph('As of '+report['as_of']+' · Report '+report['id'][:8]+' · version '+str(report.get('version',1)),styles['Normal']),Spacer(1,30),Paragraph(DISCLAIMER,styles['Normal']),PageBreak(),Paragraph('Table of contents',styles['Heading2'])]
    if logo:
        from reportlab.platypus import Image
        story.insert(0,Image(str(logo),width=100,height=60,kind='proportional'))
    toc=TableOfContents();toc.levelStyles=[styles['Normal']];story.extend([toc,PageBreak()])
    story.append(Paragraph('Calculated Kundali charts',styles['Heading1']))
    ds=[]
    for i,c in enumerate(chartlist):
        d=drawing(svg(c,report.get('layout','North Indian')));scale=.53 if len(chartlist)>1 else .70;d.scale(scale,scale);d.width*=scale;d.height*=scale
        caption=f"Person {i+1}: {c['profile']['first_name']} · {c['profile']['birth_date']} · {c['profile']['birth_time'] or 'unknown time'} · {c['accuracy']}<br/>{c['profile']['timezone']} · {c['settings']['ayanamsa']} · Whole Sign<br/>Traditional reflection: emotional rhythms, values and communication; not a forecast."
        ds.append([d,Spacer(1,7),Paragraph(html.escape(caption).replace('&lt;br/&gt;','<br/>'),styles['Normal'])])
    story.append(Table([ds],colWidths=[(page_width-84)/len(ds)]*len(ds)))
    for i,c in enumerate(chartlist):
        if c['d9_allowed']:
            story.append(PageBreak());story.append(Paragraph('Person '+str(i+1)+' · D9 Navamsha',styles['Heading2']));d=drawing(svg(c,report.get('layout','North Indian'),'D9'));d.scale(.55,.55);d.width*=.55;d.height*=.55;story.append(d)
    story.append(PageBreak())
    for title,body in parse_text(report.get('edited_text') or report['original_text']):
        story.append(Paragraph(html.escape(title),styles['Heading1']))
        for para in body.split('\n\n'):
            story.append(Paragraph(html.escape(para).replace('\n','<br/>'),styles['Normal']));story.append(Spacer(1,9))
    doc.multiBuild(story)
