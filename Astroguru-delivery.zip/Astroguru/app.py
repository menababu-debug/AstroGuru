"""Astroguru Windows-capable local desktop application. AGPL-3.0-or-later."""
from __future__ import annotations
import sys,os,json,uuid,datetime as dt,threading,hashlib
from pathlib import Path
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QDate,QThread,Signal,QByteArray,QTimer,QEvent,QStandardPaths
from PySide6.QtGui import QFont,QTextDocument,QImage,QPainter
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtPrintSupport import QPrintPreviewDialog,QPrinter
import core,charts,reports,matching
from storage import Store
from widgets import ProfileForm,PalmPanel
from ai import Provider,payload

STYLE='''
QWidget { background: #faf8f1; color: #35324b; font-family: "Segoe UI", "DejaVu Sans"; font-size: 13px; }
QMainWindow { background: #faf8f1; }
QLabel#Brand { font-size: 27px; font-weight: 700; color: #665283; padding: 20px 8px; }
QLabel#Title { font-size: 25px; font-weight: 650; padding: 8px 0; }
QLabel#Subtitle { color: #656176; padding-bottom: 12px; }
QFrame#Card { background: #ffffff; border: 1px solid #e5dfed; border-radius: 15px; padding: 16px; }
QFrame#Card QLabel { background: transparent; }
QLabel#Counts { background: #edf3fa; border: 1px solid #dfd8bf; border-radius: 10px; font-size: 22px; font-weight: 600; padding: 16px; }
QListWidget { background: #ffffff; border: 1px solid #e5dfed; border-radius: 12px; padding: 8px; }
QListWidget::item { padding: 13px; border-radius: 8px; }
QListWidget::item:selected { background: #e9e1f4; color: #47345f; }
QListWidget#Nav { background: #eeebf6; border: none; }
QPushButton { background: #e9e1f4; border: 1px solid #d8cce6; border-radius: 8px; padding: 10px 16px; font-weight: 600; }
QPushButton:hover { background: #ded2ef; }
QPushButton:disabled { color: #85818c; background: #efedf0; }
QPushButton#Primary { background: #6b5789; color: white; border: none; }
QLineEdit,QDateEdit,QTimeEdit,QSpinBox,QDoubleSpinBox,QComboBox,QPlainTextEdit,QTextEdit { background: white; border: 1px solid #cfc8d9; border-radius: 6px; padding: 7px; selection-background-color: #d9c9ed; }
QScrollArea { border: none; }
QTabWidget::pane { border: 1px solid #e5dfed; border-radius: 8px; }
QTabBar::tab { padding: 10px 18px; background: #f0ecf7; }
QTabBar::tab:selected { background: #ded2ef; }
QProgressBar { border: 1px solid #d8cce6; border-radius: 6px; text-align: center; height: 20px; }
QProgressBar::chunk { background: #b6a2d1; border-radius: 5px; }
'''

def button(label,callback,primary=False):
    b=QPushButton(label);b.clicked.connect(callback)
    if primary:b.setObjectName('Primary')
    return b

def heading(layout,title,subtitle=None):
    h=QLabel(title);h.setObjectName('Title');layout.addWidget(h)
    if subtitle:s=QLabel(subtitle);s.setWordWrap(True);s.setObjectName('Subtitle');layout.addWidget(s)

def safe(parent,action):
    try:return action()
    except Exception as e:QMessageBox.warning(parent,'Astroguru',str(e));return None

class AIWorker(QThread):
    section_ready=Signal(int,object,object);failed=Signal(str);complete=Signal()
    def __init__(self,report,provider,model,key):
        super().__init__();self.report=report;self.cancel=threading.Event();self.provider=Provider(provider,model,key,self.cancel)
    def run(self):
        try:
            data=payload(self.report)
            for i,title in enumerate(self.report['ai_titles']):
                if str(i) in self.report.get('ai_sections',{}):continue
                section,usage=self.provider.section(title,data);self.section_ready.emit(i,section.model_dump(),usage)
            self.complete.emit()
        except InterruptedError:self.failed.emit('Cancelled. Completed sections are saved; resume when ready.')
        except Exception as e:self.failed.emit(str(e))

class Wizard(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;self.client_id=None;self.calculation=None
        l=QVBoxLayout(self);heading(l,'New reading','A guided local workflow. Palm images and AI explanations are optional.')
        self.progress=QProgressBar();self.progress.setRange(0,4);self.progress.setValue(0);l.addWidget(self.progress)
        self.steps=QLabel();l.addWidget(self.steps);self.pages=QStackedWidget();l.addWidget(self.pages,1)
        self.form=ProfileForm();client=QWidget();cl=QVBoxLayout(client);r=QHBoxLayout();self.existing=QComboBox();self.existing.addItem('Enter a new client',None)
        for key,p in window.store.all('clients'):self.existing.addItem(p['first_name']+' '+p.get('last_name','')+' · '+key[:8],key)
        self.existing.currentIndexChanged.connect(self.load_client);r.addWidget(QLabel('Use existing client'));r.addWidget(self.existing,1);cl.addLayout(r);cl.addWidget(self.form);self.pages.addWidget(client)
        palm=QWidget();pl=QVBoxLayout(palm);pl.addWidget(QLabel('Upload right palm first, then left palm. Both may be skipped for a chart-only reading.'))
        tabs=QTabWidget();self.palms={}
        for hand in ['right','left']:panel=PalmPanel(hand,window.store);self.palms[hand]=panel;tabs.addTab(panel,hand.title()+' palm')
        pl.addWidget(tabs);self.pages.addWidget(palm)
        self.settings_page=QWidget();sl=QVBoxLayout(self.settings_page);sf=QFormLayout();sl.addLayout(sf)
        self.asof=QDateEdit(QDate.currentDate());self.asof.setCalendarPopup(True);self.asof.setDisplayFormat('yyyy-MM-dd');sf.addRow('Report as-of date',self.asof)
        self.ayanamsa=QComboBox();self.ayanamsa.addItems(core.AYANAMSAS);sf.addRow('Sidereal ayanamsa',self.ayanamsa)
        self.house=QComboBox();self.house.addItem('Placidus','P');self.house.addItem('Whole Sign','W');self.house.addItem('Equal','E');sf.addRow('Western house system',self.house)
        self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);sf.addRow('Kundali layout',self.layout)
        self.hindi=QCheckBox('Hindi sign labels in chart SVG / PNG');sf.addRow('Chart labels',self.hindi)
        self.intimacy=QCheckBox('Client explicitly consents to adult intimacy reflection (adults only)');sf.addRow('',self.intimacy)
        sl.addWidget(QLabel('Vedic houses: Whole Sign. Mean lunar nodes. Moshier ephemeris.\nBirth time sensitivity and all settings are recorded in the report.\nNo AI image generation is used for Kundali charts.'));sl.addStretch();self.pages.addWidget(self.settings_page)
        review=QWidget();rl=QVBoxLayout(review);self.review=QPlainTextEdit();self.review.setReadOnly(True);rl.addWidget(self.review);self.confirm=QCheckBox('I have reviewed and confirmed these birth details and settings');rl.addWidget(self.confirm);self.pages.addWidget(review)
        final=QWidget();fl=QVBoxLayout(final);heading(fl,'Ready to calculate','Calculations run locally. A complete editable template report works without an API key.');self.result=QLabel('');self.result.setWordWrap(True);fl.addWidget(self.result);fl.addWidget(button('Calculate and save template report',lambda:safe(self,self.generate),True));fl.addStretch();self.pages.addWidget(final)
        nav=QHBoxLayout();self.back=button('Back',self.previous);self.next=button('Continue',lambda:safe(self,self.advance),True);nav.addWidget(self.back);nav.addStretch();nav.addWidget(self.next);l.addLayout(nav);self.update_step()
    def load_client(self):
        key=self.existing.currentData();self.client_id=key
        if key:self.form.load(self.window.store.get('clients',key))
        else:self.form.load({'first_name':'','last_name':'','current_name':'','father_name':'','mother_name':'','notes':'','interests':'','accuracy':'unknown','palms':{},'location_verified':False})
    def settings(self):return {'as_of':self.asof.date().toString('yyyy-MM-dd'),'ayanamsa':self.ayanamsa.currentText(),'vedic_house_system':'Whole Sign','western_house_system':self.house.currentData(),'nodes':'Mean','ephemeris':'Moshier','leap_day_policy':'February 28 in non-leap years'}
    def update_step(self):
        i=self.pages.currentIndex();self.progress.setValue(i);self.steps.setText(['1 · Client information','2 · Palm images','3 · Calculation settings','4 · Review and confirm','5 · Generate report'][i]);self.back.setEnabled(i>0);self.next.setVisible(i<4)
    def previous(self):self.pages.setCurrentIndex(max(0,self.pages.currentIndex()-1));self.confirm.setChecked(False);self.update_step()
    def advance(self):
        i=self.pages.currentIndex()
        if i==0:self.form.checked()
        if i==1:
            for hand,panel in self.palms.items():
                record=panel.record()
                if record:self.form.palms[hand]=record
        if i==2:
            p=self.form.checked();core.validate(p,self.settings()['as_of']);h=core.horizons(dt.date.fromisoformat(p['birth_date']),dt.date.fromisoformat(self.settings()['as_of']))
            if h['age']<18 and self.intimacy.isChecked():raise ValueError('Adult intimacy sections are unavailable for children.')
            self.review.setPlainText(json.dumps({'birth_details':p,'settings':self.settings(),'report_limits':h,'palm_review':'manual' if p['palms'] else 'skipped'},ensure_ascii=False,indent=2));self.confirm.setChecked(False)
        if i==3 and not self.confirm.isChecked():raise ValueError('Confirm the reviewed birth details before calculating.')
        self.pages.setCurrentIndex(i+1);self.update_step()
    def generate(self):
        if not self.confirm.isChecked():raise ValueError('Birth details must be confirmed.')
        p=self.form.checked();settings=self.settings();calculation=core.calculate(p,settings)
        duplicates=self.window.store.duplicates(p)
        if not self.client_id and duplicates:
            if QMessageBox.question(self,'Possible duplicate','A client with the same name and birth date exists. Save a separate record?')!=QMessageBox.Yes:return
        self.client_id=self.window.store.save('clients',p,self.client_id)
        sections=reports.natal_sections(calculation,intimacy=self.intimacy.isChecked());identifier=str(uuid.uuid4())
        report={'id':identifier,'title':'Personal reading · '+p['first_name'],'kind':'natal','as_of':settings['as_of'],'version':1,'client_ids':[self.client_id],'calculations':[calculation],'original_text':reports.text(sections),'edited_text':'','layout':self.layout.currentText(),'chart_language':'Hindi' if self.hindi.isChecked() else 'English','intimacy':self.intimacy.isChecked(),'status':'template complete','consents':[],'ai_sections':{},'ai_titles':[title for title,_ in sections if title in ['Traditional natal interpretation','Relationships and communication','Resilience and personal development','Final balanced summary']]}
        self.window.store.save('reports',report,identifier);self.window.store.link(identifier,[self.client_id]);self.window.refresh_clients();self.window.open_report(identifier);self.result.setText('Report generated and saved.');self.window.nav.setCurrentRow(3)

class MatchPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;l=QVBoxLayout(self);heading(l,'Matchmaking','Two calculated profiles. Traditional points remain separate from optional compatibility views.')
        self.people=[];r=QHBoxLayout()
        for i in range(2):
            card=QFrame();card.setObjectName('Card');cl=QVBoxLayout(card);cl.addWidget(QLabel('Person '+str(i+1)));combo=QComboBox();cl.addWidget(combo);cl.addWidget(button('Enter a new profile',lambda checked=False,j=i:self.new_profile(j)));self.people.append(combo);r.addWidget(card)
        l.addLayout(r);self.roles=QComboBox();self.roles.addItem('Select explicit traditional table roles',None);self.roles.addItem('Person 1 = groom role; Person 2 = bride role','groom');self.roles.addItem('Person 1 = bride role; Person 2 = groom role','bride');l.addWidget(self.roles)
        explanation=QLabel('Roles are table conventions, never inferred from names or gender. This baseline North Indian tradition does not establish validation for all pairings. No cancellation rules are applied. Palm images have no effect on the score.');explanation.setWordWrap(True);l.addWidget(explanation)
        f=QFormLayout();self.asof=QDateEdit(QDate.currentDate());self.asof.setCalendarPopup(True);self.asof.setDisplayFormat('yyyy-MM-dd');f.addRow('As of',self.asof);self.ayan=QComboBox();self.ayan.addItems(core.AYANAMSAS);f.addRow('Ayanamsa',self.ayan);self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);f.addRow('Chart layout',self.layout);l.addLayout(f)
        self.western=QCheckBox('Separate Western synastry (tropical calculated aspects)');self.num=QCheckBox('Separate Pythagorean numerology');self.reflection=QCheckBox('Voluntary relationship reflection');self.intimacy=QCheckBox('Both adults explicitly consent to intimacy reflection');
        for w in [self.western,self.num,self.reflection,self.intimacy]:l.addWidget(w)
        self.concerns=QPlainTextEdit();self.concerns.setPlaceholderText('Voluntarily supplied preferences, values and concerns (local only)');self.concerns.setMaximumHeight(110);l.addWidget(self.concerns)
        self.confirm=QCheckBox('Both birth profiles and calculation settings have been reviewed and confirmed');l.addWidget(self.confirm)
        l.addWidget(button('Calculate and save matchmaking report',lambda:safe(self,self.generate),True));l.addStretch();self.refresh()
    def refresh(self):
        for combo in self.people:
            chosen=combo.currentData();combo.clear();combo.addItem('Select client',None)
            for key,p in self.window.store.all('clients'):combo.addItem(p['first_name']+' '+p.get('last_name','')+' · '+key[:8],key)
            if chosen:combo.setCurrentIndex(combo.findData(chosen))
    def new_profile(self,index):
        key=self.window.edit_client()
        if key:self.refresh();self.people[index].setCurrentIndex(self.people[index].findData(key))
    def generate(self):
        ids=[combo.currentData() for combo in self.people]
        if not all(ids) or ids[0]==ids[1]:raise ValueError('Select two distinct client records.')
        if not self.roles.currentData():raise ValueError('Assign both traditional table roles explicitly.')
        if not self.confirm.isChecked():raise ValueError('Confirm that both birth profiles and settings have been reviewed.')
        profiles=[self.window.store.get('clients',key) for key in ids]
        dialog=QMessageBox(self);dialog.setWindowTitle('Final birth-details confirmation');dialog.setText('Review both profiles before calculation.');dialog.setDetailedText(json.dumps(profiles,ensure_ascii=False,indent=2));dialog.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        if dialog.exec()!=QMessageBox.Ok:return
        settings={'as_of':self.asof.date().toString('yyyy-MM-dd'),'ayanamsa':self.ayan.currentText(),'vedic_house_system':'Whole Sign','western_house_system':'P','nodes':'Mean','ephemeris':'Moshier'}
        cs=[core.calculate(p,settings) for p in profiles]
        if self.intimacy.isChecked() and any(c['horizons']['age']<18 for c in cs):raise ValueError('Adult intimacy reflection requires two adults.')
        options={'western':self.western.isChecked(),'numerology':self.num.isChecked(),'reflection':self.reflection.isChecked(),'intimacy':self.intimacy.isChecked(),'concerns':self.concerns.toPlainText()}
        m=matching.match(*cs,self.roles.currentData(),options);sections=reports.match_sections(*cs,m);identifier=str(uuid.uuid4())
        report={'id':identifier,'title':'Matchmaking · '+profiles[0]['first_name']+' & '+profiles[1]['first_name'],'kind':'matchmaking','as_of':settings['as_of'],'version':1,'client_ids':ids,'calculations':cs,'matching':m,'original_text':reports.text(sections),'edited_text':'','layout':self.layout.currentText(),'chart_language':'English','intimacy':options['intimacy'],'status':'template complete','consents':[],'ai_sections':{},'ai_titles':['Emotional and communication themes','Values, family expectations and lifestyle','Potential strengths and areas for discussion','Final balanced summary']}
        self.window.store.save('reports',report,identifier);self.window.store.link(identifier,ids);self.window.open_report(identifier);self.window.nav.setCurrentRow(3)

class ReportPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;self.current=None;self.worker=None
        l=QVBoxLayout(self);heading(l,'Reports','Preserve calculation snapshots and generated text. Save operator edits as a new version before export.')
        r=QHBoxLayout();self.list=QComboBox();self.list.currentIndexChanged.connect(self.select);r.addWidget(self.list,1);r.addWidget(button('Refresh',self.refresh));l.addLayout(r)
        self.tabs=QTabWidget();l.addWidget(self.tabs,1)
        self.editor=QPlainTextEdit();self.tabs.addTab(self.editor,'Editable report')
        self.chart_page=QWidget();self.chart_l=QVBoxLayout(self.chart_page);controls=QHBoxLayout();self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);self.division=QComboBox();self.division.addItems(['D1','D9']);self.language=QComboBox();self.language.addItems(['English','Hindi']);
        for w in [self.layout,self.division,self.language]:controls.addWidget(w);w.currentTextChanged.connect(self.render_charts)
        controls.addWidget(button('SVG export',lambda:safe(self,lambda:self.export_chart('svg'))));controls.addWidget(button('PNG export',lambda:safe(self,lambda:self.export_chart('png'))));self.chart_l.addLayout(controls);self.chart_widgets=QHBoxLayout();self.chart_l.addLayout(self.chart_widgets,1);self.chart_hint=QLabel('');self.chart_hint.setWordWrap(True);self.chart_l.addWidget(self.chart_hint);self.chart_summary=QPlainTextEdit();self.chart_summary.setReadOnly(True);self.chart_summary.setMaximumHeight(160);self.chart_l.addWidget(self.chart_summary);self.tabs.addTab(self.chart_page,'Kundali charts')
        self.snapshot=QPlainTextEdit();self.snapshot.setReadOnly(True);self.tabs.addTab(self.snapshot,'Calculation snapshot');self.western_view=QPlainTextEdit();self.western_view.setReadOnly(True);self.tabs.addTab(self.western_view,'Western view')
        self.status=QLabel('Select a report.');self.status.setWordWrap(True);l.addWidget(self.status);self.progress=QProgressBar();self.progress.setRange(0,100);l.addWidget(self.progress)
        row=QHBoxLayout()
        for label,func in [('Save edited version',self.save_edits),('Regenerate',self.regenerate),('PDF export',self.pdf),('Print preview',self.print_preview),('AI explain / resume',self.start_ai),('Cancel AI',self.cancel_ai)]:row.addWidget(button(label,lambda checked=False,f=func:safe(self,f)))
        l.addLayout(row)
    def refresh(self,selected=None):
        selected=selected or (self.current or {}).get('id');self.list.blockSignals(True);self.list.clear();self.list.addItem('Select saved report',None)
        for key,p in self.window.store.all('reports'):self.list.addItem(p['title']+' · v'+str(p['version'])+' · '+p['status'],key)
        if selected:self.list.setCurrentIndex(self.list.findData(selected))
        self.list.blockSignals(False);self.select()
    def select(self):
        if self.worker and self.worker.isRunning():
            old=self.list.findData(self.current['id']);self.list.blockSignals(True);self.list.setCurrentIndex(old);self.list.blockSignals(False);return
        key=self.list.currentData();self.current=self.window.store.get('reports',key) if key else None
        if not self.current:self.editor.clear();self.snapshot.clear();return
        self.editor.setPlainText(self.current.get('edited_text') or self.current['original_text']);self.snapshot.setPlainText(json.dumps({k:v for k,v in self.current.items() if k not in ['original_text','edited_text','ai_sections']},ensure_ascii=False,indent=2));self.western_view.setPlainText('\n\n'.join('Person '+str(i+1)+'\n'+reports.western_text(c) for i,c in enumerate(self.current['calculations'])));self.layout.setCurrentText(self.current.get('layout','North Indian'));self.language.setCurrentText(self.current.get('chart_language','English'));self.render_charts();self.status.setText('Status: '+self.current['status']+' · '+('Operator edited' if self.current.get('edited_text') else 'Original generated template')+' · AI costs unavailable until provider usage is returned.');self.progress.setValue(int(100*len(self.current.get('ai_sections',{}))/max(1,len(self.current['ai_titles']))))
    def render_charts(self):
        while self.chart_widgets.count():
            item=self.chart_widgets.takeAt(0)
            if item.widget():item.widget().deleteLater()
        if not self.current:return
        if self.division.currentText()=='D9' and not all(c['d9_allowed'] for c in self.current['calculations']):
            self.chart_hint.setText('D9 withheld: a confirmed exact birth time is required for each displayed profile.');return
        self.chart_summary.setPlainText('\n\n'.join('Person '+str(i+1)+': '+c['profile']['first_name']+' · '+c['profile']['birth_date']+' · '+(c['profile']['birth_time'] or 'time unknown')+' · '+c['accuracy']+'\n'+c['profile']['city']+' / '+c['profile']['timezone']+' · '+c['settings']['ayanamsa']+' / Whole Sign\n'+reports.placement_lines(c)+'\nTraditional reflection: '+('; '.join(name+' — '+reports.THEMES[name] for name in ['Sun','Moon','Venus']) if c['vedic'] else 'Confirmed birth time is needed for precise natal interpretation.') for i,c in enumerate(self.current['calculations'])))
        for c in self.current['calculations']:
            w=QSvgWidget();w.load(QByteArray(charts.svg(c,self.layout.currentText(),self.division.currentText(),self.language.currentText()).encode()));self.chart_widgets.addWidget(w)
        self.chart_hint.setText('The same saved calculations supply chart graphics and written placement tables. R = retrograde; degrees in D9 are divisional degrees. Approximate-time ascendants/houses are provisional. Hindi sign labels are available in SVG/PNG; PDF currently uses English for font portability.')
    def export_chart(self,kind):
        if not self.current:raise ValueError('Select a report.')
        index=0
        if len(self.current['calculations'])>1:
            chosen,ok=QInputDialog.getItem(self,'Chart export','Person',['Person 1','Person 2'],0,False)
            if not ok:return
            index=0 if chosen=='Person 1' else 1
        value=charts.svg(self.current['calculations'][index],self.layout.currentText(),self.division.currentText(),self.language.currentText())
        filename,_=QFileDialog.getSaveFileName(self,'Export chart','Astroguru-chart-'+self.current['id'][:8]+'.'+kind,kind.upper()+' (*.'+kind+')')
        if filename:
            if kind=='svg':Path(filename).write_text(value,encoding='utf-8')
            else:charts.png(value,filename)
            self.status.setText('Chart exported.')
    def require(self):
        if not self.current:raise ValueError('Select a saved report.')
    def save_edits(self):
        self.require()
        if self.worker and self.worker.isRunning():raise ValueError('Wait for or cancel AI generation before saving edits.')
        value=self.editor.toPlainText()
        if value==(self.current.get('edited_text') or self.current['original_text']):return
        report=dict(self.current);old=report['id'];new=str(uuid.uuid4());report.update(id=new,version=report['version']+1,edited_text=value,parent_version=old,edited_at=dt.datetime.now(dt.timezone.utc).isoformat(),layout=self.layout.currentText(),chart_language=self.language.currentText());self.window.store.save('reports',report,new)
        links=[x[0] for x in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(old,))];self.window.store.link(new,links);self.refresh(new)
    def regenerate(self):
        self.require()
        links=self.current.get('client_ids') or [row[0] for row in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(self.current['id'],))]
        if self.current['kind']=='matchmaking':
            self.window.match_page.refresh()
            for combo,key in zip(self.window.match_page.people,links):combo.setCurrentIndex(combo.findData(key))
            self.window.match_page.roles.setCurrentIndex(self.window.match_page.roles.findData(self.current['matching']['role_a']));self.window.match_page.confirm.setChecked(False);self.window.nav.setCurrentRow(4)
        else:
            self.window.reset_wizard();wizard=self.window.wizard
            if links:wizard.existing.setCurrentIndex(wizard.existing.findData(links[0]))
            self.window.nav.setCurrentRow(2)
    def pdf(self):
        self.require();self.save_edits();filename,_=QFileDialog.getSaveFileName(self,'Export professional PDF','Astroguru-report-'+self.current['id'][:8]+'.pdf','PDF (*.pdf)')
        if filename:reports.export_pdf(self.current,filename,self.window.config.value('provider','Astroguru'),self.window.config.value('logo','') or None);self.status.setText('PDF exported with vector charts, contents and page numbers.')
    def print_preview(self):
        self.require();self.save_edits()
        from PySide6.QtPdf import QPdfDocument
        import tempfile
        # Preview/print the exact PDF export; keeps charts and pagination consistent.
        with tempfile.TemporaryDirectory(prefix='astroguru-print-') as folder:
            path=Path(folder)/'preview.pdf';reports.export_pdf(self.current,path,self.window.config.value('provider','Astroguru'),self.window.config.value('logo','') or None)
            pdf=QPdfDocument(self);pdf.load(str(path));printer=QPrinter(QPrinter.HighResolution)
            from PySide6.QtGui import QPageLayout,QPageSize
            printer.setPageSize(QPageSize(QPageSize.A4));printer.setPageOrientation(QPageLayout.Landscape if len(self.current['calculations'])>1 else QPageLayout.Portrait);preview=QPrintPreviewDialog(printer,self)
            def paint(p):
                painter=QPainter(p)
                for page in range(pdf.pageCount()):
                    if page:p.newPage()
                    rect=p.pageRect(QPrinter.DevicePixel);im=pdf.render(page,rect.size().toSize());painter.drawImage(rect,im)
                painter.end()
            preview.paintRequested.connect(paint);preview.exec();pdf.close();pdf.deleteLater()
    def start_ai(self):
        self.require()
        if self.worker and self.worker.isRunning():raise ValueError('Generation is already running.')
        self.save_edits();provider=self.window.config.value('ai_provider','OpenAI');model=self.window.config.value('model_'+provider,'gpt-4.1' if provider=='OpenAI' else 'gemini-2.5-flash')
        import keyring
        try:key=keyring.get_password('Astroguru',provider)
        except Exception:raise ValueError('Secure OS credential store unavailable. Configure Windows Credential Manager or a supported system keyring. Keys will not be written to files.')
        if not key:raise ValueError('Add an API key in Settings. Local template reports remain available.')
        data=payload(self.current);digest=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
        consent=QDialog(self);consent.setWindowTitle('External AI: review transmitted data');consent.resize(740,620);l=QVBoxLayout(consent);info=QLabel(f'Provider: {provider}; model: {model}. Calculated placements, age, settings and selected numerical results will be sent. Names, parental information, raw birth details, notes and palm photographs are excluded. Charges may apply; cost estimates require current provider pricing.');info.setWordWrap(True);l.addWidget(info);view=QPlainTextEdit(json.dumps(data,ensure_ascii=False,indent=2));view.setReadOnly(True);l.addWidget(view);checks=[]
        for i in range(len(self.current['calculations'])):
            c=QCheckBox('Person '+str(i+1)+' has explicitly consented to this provider and this payload');l.addWidget(c);checks.append(c)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(lambda:consent.accept() if all(c.isChecked() for c in checks) else QMessageBox.warning(consent,'Consent required','Recorded consent is required from each person.'));buttons.rejected.connect(consent.reject);l.addWidget(buttons)
        if consent.exec()!=QDialog.Accepted:return
        self.current['consents'].append({'provider':provider,'model':model,'payload_hash':digest,'people':len(checks),'consented':True,'timestamp':dt.datetime.now(dt.timezone.utc).isoformat(),'palm_images':False});self.current.update(status='AI generating',ai_provider=provider,ai_model=model);self.window.store.save('reports',self.current,self.current['id']);self.worker=AIWorker(self.current,provider,model,key);self.worker.section_ready.connect(self.ai_section);self.worker.failed.connect(self.ai_failed);self.worker.complete.connect(self.ai_complete);self.worker.start();self.status.setText('Generating selected interpretation sections. Local calculated facts are retained. Cancel stops further sections; an in-flight request may take up to 60 seconds.');self.window.nav.setEnabled(False)
    def ai_section(self,index,section,usage):
        self.current['ai_sections'][str(index)]=section;self.current.setdefault('section_provenance',{})[str(index)]={'provider':self.current['ai_provider'],'model':self.current['ai_model'],'timestamp':dt.datetime.now(dt.timezone.utc).isoformat()};self.current.setdefault('usage',[]).append(usage);self.window.store.save('reports',self.current,self.current['id']);self.progress.setValue(int(100*len(self.current['ai_sections'])/len(self.current['ai_titles'])))
    def ai_failed(self,message):
        self.current['status']='AI paused';self.window.store.save('reports',self.current,self.current['id']);self.status.setText(message);self.window.nav.setEnabled(True)
    def ai_complete(self):
        self.worker.wait()
        # Create an AI-derived version. Preserve the immutable original generated version.
        sections=reports.parse_text(self.current.get('edited_text') or self.current['original_text']);generated={s['title']:s['body'] for s in self.current['ai_sections'].values()}
        merged=[(title,generated.get(title,body)) for title,body in sections];old=self.current['id'];self.current['status']='AI source complete';self.window.store.save('reports',self.current,old)
        child=dict(self.current);new=str(uuid.uuid4());child.update(id=new,parent_version=old,version=child['version']+1,status='AI complete — operator review required',edited_text=reports.text(merged));self.window.store.save('reports',child,new);self.window.store.link(new,[row[0] for row in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(old,))]);self.window.nav.setEnabled(True);self.refresh(new);self.status.setText('AI explanation version saved. Review it before export. Actual token usage is recorded; monetary cost is not estimated without configured current rates.')
    def cancel_ai(self):
        if self.worker and self.worker.isRunning():self.worker.cancel.set();self.status.setText('Cancellation requested; completed sections are preserved.')

class SettingsPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;l=QVBoxLayout(self);heading(l,'Settings','Secure credentials, branding and encrypted backup. No API key is needed for local calculations or template reports.')
        f=QFormLayout();l.addLayout(f);self.provider_name=QLineEdit(window.config.value('provider','Astroguru'));f.addRow('Service provider name',self.provider_name);self.logo=QLineEdit(window.config.value('logo',''));f.addRow('Provider logo path (optional)',self.logo);l.addWidget(button('Choose logo',self.choose_logo));self.ai_provider=QComboBox();self.ai_provider.addItems(['OpenAI','Gemini']);self.ai_provider.setCurrentText(window.config.value('ai_provider','OpenAI'));f.addRow('AI provider',self.ai_provider);self.model=QLineEdit();f.addRow('Model ID (verify access with provider)',self.model);self.key=QLineEdit();self.key.setEchoMode(QLineEdit.Password);self.key.setPlaceholderText('New key — stored in OS credential manager only');f.addRow('API key',self.key);self.ai_provider.currentTextChanged.connect(self.load_model);self.load_model();l.addWidget(button('Save settings / credential',lambda:safe(self,self.save),True));l.addWidget(button('Test connection (no client data)',lambda:safe(self,self.test)))
        self.status=QLabel('External services: optional OpenAI / Gemini; user-triggered OpenStreetMap birthplace lookup. No palm photographs are transmitted in this version.');self.status.setWordWrap(True);l.addWidget(self.status)
        row=QHBoxLayout();row.addWidget(button('Encrypted backup',lambda:safe(self,self.backup)));row.addWidget(button('Restore backup',lambda:safe(self,self.restore)));row.addWidget(button('Lock application',window.lock));l.addLayout(row)
        info=QLabel('Vault: AES-256-GCM encrypted client/report payloads and photographs, password-derived scrypt key. Backups are authenticated and encrypted. Keep your password safe: no recovery backdoor. UUIDs and database structure remain visible. Exported PDFs/PNGs/SVGs are unencrypted; handle them as client documents. Automatic lock after 15 minutes of inactivity.');info.setWordWrap(True);l.addWidget(info);l.addStretch()
    def load_model(self):self.model.setText(self.window.config.value('model_'+self.ai_provider.currentText(),'gpt-4.1' if self.ai_provider.currentText()=='OpenAI' else 'gemini-2.5-flash'));self.key.clear()
    def choose_logo(self):
        filename,_=QFileDialog.getOpenFileName(self,'Choose provider logo','','Images (*.png *.jpg *.jpeg)')
        if filename:self.logo.setText(filename)
    def save(self):
        self.window.config.setValue('provider',self.provider_name.text().strip() or 'Astroguru');self.window.config.setValue('logo',self.logo.text());self.window.config.setValue('ai_provider',self.ai_provider.currentText());self.window.config.setValue('model_'+self.ai_provider.currentText(),self.model.text().strip())
        if self.key.text():
            import keyring
            try:keyring.set_password('Astroguru',self.ai_provider.currentText(),self.key.text())
            except Exception:raise ValueError('OS secure credential store unavailable. API key was not saved. On Windows use Credential Manager; on Linux use a supported Secret Service keyring.')
            self.key.clear()
        self.status.setText('Settings saved. Credentials, when entered, stored only in the OS credential manager.')
    def test(self):
        self.save();import keyring
        key=keyring.get_password('Astroguru',self.ai_provider.currentText())
        if not key:raise ValueError('No key configured.')
        if getattr(self,'test_worker',None) and self.test_worker.isRunning():return
        class Test(QThread):
            done=Signal(str)
            def __init__(self,provider,model,key,parent):super().__init__(parent);self.provider=Provider(provider,model,key)
            def run(self):
                try:self.provider.section('Connection test',{'message':'No client information. Explain that this is a successful connection test.'});self.done.emit('Connection successful. A small API request was billed by the provider.')
                except Exception as e:self.done.emit(str(e))
        self.test_worker=Test(self.ai_provider.currentText(),self.model.text(),key,self);self.test_worker.done.connect(self.status.setText);self.test_worker.start();self.status.setText('Testing provider with no client information…')
    def backup(self):
        filename,_=QFileDialog.getSaveFileName(self,'Save encrypted backup','Astroguru-backup.agbk','Astroguru backup (*.agbk)')
        if filename:self.window.store.backup(filename);self.status.setText('Encrypted backup saved. Keep the vault password separately and securely.')
    def restore(self):
        filename,_=QFileDialog.getOpenFileName(self,'Restore encrypted backup','','Astroguru backup (*.agbk)')
        if not filename:return
        if QMessageBox.warning(self,'Replace current vault data','Restore replaces current records and photographs. Create a backup first if you need to retain them.',QMessageBox.Ok|QMessageBox.Cancel)!=QMessageBox.Ok:return
        password,ok=QInputDialog.getText(self,'Backup password','Password used when this backup was created:',QLineEdit.Password)
        if ok:self.window.store.restore(filename,password);self.window.refresh_clients();self.window.report_page.refresh();self.window.match_page.refresh();self.window.reset_wizard();self.status.setText('Backup restored and authenticated.')

class MainWindow(QMainWindow):
    def __init__(self,store):
        super().__init__();self.store=store
        from PySide6.QtCore import QSettings
        self.config=QSettings('Astroguru','Astroguru');self.setWindowTitle('Astroguru');self.resize(1300,900);self.setMinimumSize(980,700)
        root=QWidget();self.setCentralWidget(root);layout=QHBoxLayout(root);side=QWidget();side.setFixedWidth(205);sl=QVBoxLayout(side);brand=QLabel('✦ Astroguru');brand.setObjectName('Brand');sl.addWidget(brand);self.nav=QListWidget();self.nav.setObjectName('Nav');self.nav.addItems(['Dashboard','Clients','New Reading','Reports','Matchmaking','Settings']);sl.addWidget(self.nav);sl.addWidget(QLabel('Local vault · encrypted\nInterpretive traditions'));sl.addWidget(button('Lock',self.lock));layout.addWidget(side);self.pages=QStackedWidget();layout.addWidget(self.pages,1)
        self.dashboard=QWidget();self.dash_l=QVBoxLayout(self.dashboard);heading(self.dash_l,'Welcome to Astroguru','Thoughtful consultations, clear calculations and professionally formatted reports.');self.counts=QLabel();self.counts.setObjectName('Counts');self.dash_l.addWidget(self.counts);row=QHBoxLayout()
        for title,body,action in [('New reading','Client → palms → settings → review → report',lambda:self.nav.setCurrentRow(2)),('Matchmaking','Two profiles, transparent Guna Milan and separate reflection',lambda:self.nav.setCurrentRow(4))]:
            card=QFrame();card.setObjectName('Card');cl=QVBoxLayout(card);h=QLabel(title);h.setObjectName('Title');cl.addWidget(h);desc=QLabel(body);desc.setWordWrap(True);cl.addWidget(desc);cl.addWidget(button('Open',action));row.addWidget(card)
        self.dash_l.addLayout(row);note=QLabel('Calculated chart facts stay separate from interpretations and client-confirmed life events. Unknown birth times never receive an invented ascendant.\n\nNo key required: client management, palm alignment, deterministic calculations, SVG/PNG charts and PDF template reports work locally.');note.setWordWrap(True);self.dash_l.addWidget(note);self.dash_l.addStretch();self.pages.addWidget(self.dashboard)
        clients=QWidget();cl=QVBoxLayout(clients);heading(cl,'Clients','Search encrypted local records. Matchmaking reports are linked to both people.');self.search=QLineEdit();self.search.setPlaceholderText('Search name, birthplace or notes');self.search.textChanged.connect(self.refresh_clients);cl.addWidget(self.search);self.client_list=QListWidget();self.client_list.itemDoubleClicked.connect(lambda:self.edit_selected());cl.addWidget(self.client_list,1);row=QHBoxLayout()
        for label,action in [('Add client',lambda:self.edit_client()),('Edit selected',self.edit_selected),('Open linked reports',self.client_reports),('Export client JSON',self.export_client),('Delete client',self.delete_client)]:row.addWidget(button(label,lambda checked=False,f=action:safe(self,f)))
        cl.addLayout(row);self.pages.addWidget(clients)
        self.wizard=Wizard(self);self.pages.addWidget(self.wizard);self.report_page=ReportPage(self);self.pages.addWidget(self.report_page);self.match_page=MatchPage(self);self.pages.addWidget(self.match_page);self.settings_page=SettingsPage(self);self.pages.addWidget(self.settings_page);self.nav.currentRowChanged.connect(self.navigate);self.nav.setCurrentRow(0);self.refresh_clients()
        self.idle=QTimer(self);self.idle.setSingleShot(True);self.idle.setInterval(15*60*1000);self.idle.timeout.connect(self.lock);self.idle.start();QApplication.instance().installEventFilter(self)
    def eventFilter(self,obj,event):
        if event.type() in [QEvent.KeyPress,QEvent.MouseButtonPress,QEvent.MouseMove,QEvent.Wheel]:self.idle.start()
        return False
    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        if index==3:self.report_page.refresh()
        if index==4:self.match_page.refresh()
        self.refresh_counts()
    def refresh_counts(self):self.counts.setText(f"{len(self.store.all('clients'))} clients     ·     {len(self.store.all('reports'))} saved report versions")
    def refresh_clients(self,*args):
        text=self.search.text().casefold();self.client_list.clear()
        for key,p in self.store.all('clients'):
            if text and text not in (p['first_name']+' '+p.get('last_name','')+' '+p.get('city','')+' '+p.get('notes','')).casefold():continue
            item=QListWidgetItem(p['first_name']+' '+p.get('last_name','')+'\n'+p.get('city','')+' · '+p['accuracy']+' birth time · '+key[:8]);item.setData(Qt.UserRole,key);self.client_list.addItem(item)
        if hasattr(self,'counts'):self.refresh_counts()
    def selected_client(self):
        item=self.client_list.currentItem()
        if not item:raise ValueError('Select a client.')
        return item.data(Qt.UserRole)
    def edit_client(self,key=None):
        dialog=QDialog(self);dialog.setWindowTitle('Edit client' if key else 'New client');dialog.resize(760,800);l=QVBoxLayout(dialog);form=ProfileForm(self.store.get('clients',key) if key else None);l.addWidget(form);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);l.addWidget(buttons);result={'key':None}
        def save():
            def work():
                p=form.checked()
                if not key and self.store.duplicates(p) and QMessageBox.question(dialog,'Possible duplicate','Matching name and birth date found. Save another record?')!=QMessageBox.Yes:return
                result['key']=self.store.save('clients',p,key);dialog.accept()
            safe(dialog,work)
        buttons.accepted.connect(save);buttons.rejected.connect(dialog.reject);dialog.exec();self.refresh_clients();return result['key']
    def edit_selected(self):return self.edit_client(self.selected_client())
    def client_reports(self):
        links=self.store.linked_reports(self.selected_client())
        if not links:QMessageBox.information(self,'Reports','No saved reports linked to this client.');return
        choices=[self.store.get('reports',key)['title']+' · '+key[:8] for key in links];chosen,ok=QInputDialog.getItem(self,'Client reports','Choose report',choices,0,False)
        if ok:self.nav.setCurrentRow(3);self.open_report(links[choices.index(chosen)])
    def export_client(self):
        key=self.selected_client();filename,_=QFileDialog.getSaveFileName(self,'Export client (unencrypted)','Astroguru-client-'+key[:8]+'.json','JSON (*.json)')
        if filename:Path(filename).write_text(json.dumps(self.store.get('clients',key),ensure_ascii=False,indent=2),encoding='utf-8')
    def delete_client(self):
        key=self.selected_client()
        if QMessageBox.warning(self,'Delete client','Permanently delete this client, photographs and all linked reports, including matchmaking reports containing their details?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:self.store.delete_client(key);self.refresh_clients();self.report_page.refresh();self.match_page.refresh();self.reset_wizard()
    def reset_wizard(self):
        old=self.wizard;self.pages.removeWidget(old);old.deleteLater();self.wizard=Wizard(self);self.pages.insertWidget(2,self.wizard)
    def open_report(self,key):self.report_page.refresh(key)
    def lock(self):
        if self.report_page.worker and self.report_page.worker.isRunning():self.report_page.cancel_ai();self.report_page.status.setText('Lock requested. Cancelling generation first; lock again when the active request ends.');self.idle.start(65000);return
        if getattr(self.settings_page,'test_worker',None) and self.settings_page.test_worker.isRunning():self.idle.start(65000);return
        self.hide();self.store.prune_assets();self.store.close();QApplication.instance().exit(42)
    def closeEvent(self,event):
        if self.report_page.worker and self.report_page.worker.isRunning():self.report_page.cancel_ai();event.ignore();QMessageBox.information(self,'Generation cancelling','Cancellation requested. Close again after the active request ends (up to 60 seconds).');return
        if getattr(self.settings_page,'test_worker',None) and self.settings_page.test_worker.isRunning():event.ignore();return
        super().closeEvent(event)

def main():
    if '--self-test' in sys.argv:os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    app=QApplication(sys.argv);app.setApplicationName('Astroguru');app.setOrganizationName('Astroguru');app.setStyle('Fusion');app.setStyleSheet(STYLE)
    if '--self-test' in sys.argv:
        from smokecheck import run
        return run(app)
    folder=Path(os.environ.get('ASTROGURU_DATA_DIR') or QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation))
    while True:
        exists=(folder/'astroguru.db').exists();password,ok=QInputDialog.getText(None,'Unlock Astroguru' if exists else 'Create encrypted Astroguru vault','Vault password:' if exists else 'Choose a password (at least 10 characters). Store it safely — no recovery backdoor.',QLineEdit.Password)
        if not ok:return 0
        try:store=Store(folder,password)
        except Exception as e:QMessageBox.warning(None,'Vault unavailable',str(e));continue
        password=None;window=MainWindow(store);window.show();code=app.exec();app.removeEventFilter(window)
        if code!=42:store.prune_assets();store.close();return code
        window.deleteLater();app.processEvents()

if __name__=='__main__':sys.exit(main())
