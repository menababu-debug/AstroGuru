# PyInstaller one-directory build: keep Qt DLLs replaceable for LGPL compliance.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files,collect_submodules
root=Path(SPECPATH)
source=[(str(p),'source') for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.txt','.md','.ps1','.cmd','.iss','.spec']]
source += [(str(root/'LICENSE'),'source'),(str(root/'references'),'source/references')]
data=source+collect_data_files('tzdata')+collect_data_files('timezonefinder')+collect_data_files('timezonefinder_data')
a=Analysis([str(root/'app.py')],pathex=[str(root)],binaries=[],datas=data,
 hiddenimports=collect_submodules('keyring.backends')+['google.genai','google.genai.types','openai','swisseph','PIL.Image','PIL.ImageOps'],
 hookspath=[],runtime_hooks=[],excludes=['torch','tensorflow','pandas','matplotlib','IPython','notebook','pytest','PySide6.QtWebEngineCore','PySide6.QtWebEngineWidgets','PySide6.QtWebEngineQuick'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='Astroguru',debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False)
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='Astroguru')
