# Implemented scope and remaining limitations

## Working locally

Desktop client form/search/edit/duplicate warning/deletion; optional right/left palm upload, uniform scaling, rotation, repositioning, crop and manual acceptance; encrypted original/aligned photographs; password-locked encrypted record vault; authenticated encrypted backup/restore; exact report date windows; IANA historical DST validation; deterministic Swiss Ephemeris natal/ascendant/Whole Sign houses, D1/D9, nakshatras/padas/retrograde, Vimshottari/antardasha, selected baseline yogas/Manglik, present and annual transit snapshots; separate tropical houses/aspects; documented Pythagorean calculations; SVG/PNG charts; explicit matching roles and eight-factor Ashtakoota; optional separate synastry/numerology/reflection; report versions, client links, local template generation, editable text, vector PDF contents/page numbers and PDF-backed print preview.

## Implemented but requires external verification

- OpenAI/Gemini adapters: official current SDK interfaces, structured output validation, minimized payload previews, both-person consent, timeouts, transient retries, cancellation, saved sections/resumption and usage records. Live provider authorization/model access requires your API keys and allowed API hosts. No live calls were made in this environment.
- Optional public Nominatim birthplace lookup: implemented with explicit result selection; live endpoint access was not available here. Offline verified coordinates/timezone entry works. TimezoneFinder's current boundary suggestion is not proof of the historic zone.
- Windows PyInstaller and Inno Setup configuration: names are `Astroguru.exe` and `Astroguru-Setup.exe`. Windows compilation/installer, Windows Credential Manager and real printing were not tested in this Linux environment. Exact build steps are in README.md.

## Intentional or unfinished extensions

- Automatic anatomical palm validation and AI palm-image interpretation are unavailable. The manual workflow is explicit; heuristic exposure/detail warnings are not a quality verdict. Palmistry template content records observations without claiming to independently read palm lines.
- Template interpretations are basic, transparent conversation prompts rather than lengthy personalized prose. Optional AI enhances selected interpretation sections; it does not replace deterministic facts, scores or local chronological timelines. Operator review remains required.
- One baseline North Indian matching convention is provided. South Indian **chart layout** is available; Tamil/South Indian matching systems are not implemented. No dosha cancellation, dignity/strength, combustion or advanced yoga rules are claimed.
- D9 interpretation is limited to calculated sign symbolism. No advanced spouse/outcome predictions are implemented.
- Western techniques are natal/tropical placements, chosen houses, five major 6°-orb aspects, present transits and optional inter-chart aspects. Progressions, returns and specialized mundane techniques are not implemented.
- Pythagorean numerology only; Chaldean is not offered. Latin spelling review is required for non-Latin names.
- English report text initially. Hindi **sign labels** are an SVG/PNG chart setting, relying on a Hindi-capable system font. Hindi report text, full translated legends and shaped Hindi PDF typography are not implemented. PDF charts currently use English for portability.
- PNG exports are 1280×1500; SVG is scalable. Very crowded triangular North Indian cells can become dense; exact placement tables accompany the charts and remain readable in reports/adjacent UI.
- One generated text editor, preserving original and edited report versions; rich page-layout editing is not included. Final operator edits are not falsely certified by an automated semantic safety checker.
- No combined compatibility percentage, scientific validation, deterministic relationship/medical/financial outcomes or forbidden event predictions are provided.
- API schema/language checks cannot prove semantic truth or eliminate every unsafe model statement. Review the complete generated version; exact calculation tables remain authoritative.
- Monetary cost estimates are unavailable without current provider pricing; actual provider token usage is retained. Connection testing can incur a small billed request.
- Encryption covers client/report payloads and assets, not database structure/random UUIDs or exported files. Password memory cannot be reliably zeroized by Python. Use OS account controls/full-disk encryption and manage exported PDFs, backups and cloud sync separately. No password recovery is offered.
- Automated matching tests validate reference matrices, explicit-role behavior, manually worked examples and bounds; they are not a professional-service cross-certification. Validate the chosen convention against the service provider's approved examples before commercial rollout.
