"""Mocked API tests; no real credentials, photographs or billable requests."""
import copy,datetime as dt,io,json,time,uuid
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image
from PySide6.QtWidgets import QApplication,QDialog
import core,reports,ai,generation
from storage import Store

@pytest.fixture(scope='module')
def app():return QApplication.instance() or QApplication([])
@pytest.fixture
def calculation():
    profile=dict(first_name='PRIVATE NAME',last_name='CONFIDENTIAL',father_name='PRIVATE PARENT',birth_date='1990-01-01',birth_time='12:00:00',accuracy='exact',latitude=28.6139,longitude=77.209,timezone='Asia/Kolkata',city='New Delhi',country='India',location_verified=True,notes='Client-confirmed voluntary event',interests='Gardening')
    return core.calculate(profile,dict(as_of='2026-10-08',ayanamsa='Lahiri',western_house_system='P',vedic_house_system='Whole Sign'))
@pytest.fixture
def report(calculation,tmp_path):
    return {'id':str(uuid.uuid4()),'title':'Synthetic automated report','kind':'natal','as_of':'2026-10-08','version':1,'calculations':[calculation],'original_text':reports.text(reports.natal_sections(calculation)),'edited_text':'','status':'template complete','ai_sections':{},'consents':[],'ai_titles':[],'ai_options':{'depth':'Very detailed','automatic':True,'auto_pdf':True,'pdf_dir':str(tmp_path/'pdf'),'cover':False,'palm_images':False,'client_context':False,'image_model':'fake-image'}}

def body(job):
    paragraph='Traditional symbolism can invite careful reflection on personal priorities, supportive routines and respectful communication. Choices remain yours, circumstances matter, and practical steps should match voluntarily stated needs. This is an interpretive theme, not a verified event or a promise. '
    text=(paragraph+'\n\n')*20
    if job.get('mode')=='palm':text='Visible observations (uncertain): synthetic fixture only.\n\nTraditional palmistry symbolism: separate symbolic discussion.\n\n'+text
    return text

def test_full_plan_covers_domains_and_all_bounded_years(report):
    jobs=generation.plan(report,report['ai_options']);years=[j for j in jobs if j['mode']=='timeline'];c=report['calculations'][0]
    assert len(years)==len(c['horizons']['history'])+len(c['horizons']['future'])
    assert any(job['title']=='Education and learning' for job in jobs);assert any(job['title']=='Numerology' for job in jobs)
    assert not any(job['target'] in generation.FACTUAL for job in jobs)
    for job in years:
        data=generation.job_data(report,job)['year_context'];assert dt.date.fromisoformat(data['covered_interval']['start'])>=dt.date(1990,1,1)
        if job['future']:assert data['covered_interval']['end']<=c['horizons']['future_end']
    report['ai_jobs']=jobs;report['ai_sections']={job['id']:{'title':job['title'],'body':body(job)} for job in jobs};merged=generation.assemble(report)
    assert reports.placement_lines(c) in merged and 'Life phase:' in merged and 'AI-expanded reflection' in merged
    report['ai_sections'].pop(jobs[-1]['id'])
    with pytest.raises(ValueError,match='incomplete'):generation.assemble(report)

def test_payload_minimization_and_optional_context(report):
    text=json.dumps(ai.payload(report));assert 'PRIVATE NAME' not in text and 'PRIVATE PARENT' not in text and 'Gardening' not in text and '1990-01-01' not in text
    report['ai_options']['client_context']=True;data=ai.payload(report);assert data['charts'][0]['voluntary_client_context']['interests_and_skills']=='Gardening';assert 'PRIVATE PARENT' not in json.dumps(data)
    assert 'birth_name' in data['charts'][0]['numerology'] and 'mapping' not in data['charts'][0]['numerology']['birth_name']

def test_unknown_time_and_minor_plan(calculation,report):
    profile=dict(calculation['profile'],birth_date='2015-02-01',accuracy='unknown',birth_time='');c=core.calculate(profile,calculation['settings']);report['calculations']=[c];report['original_text']=reports.text(reports.natal_sections(c,intimacy=True));report['intimacy']=True
    jobs=generation.plan(report,report['ai_options']);assert not any('intimacy' in job['title'].lower() or 'D9' in job['title'] for job in jobs);data=ai.payload(report);assert not data['adult_intimacy_consented'];assert data['charts'][0]['ascendant'] is None and not data['charts'][0]['d9_signs']
    year=next(job for job in jobs if job['mode']=='timeline');assert generation.job_data(report,year)['year_context']['dasha_at_interval_start'] is None

def test_separate_consent_for_both_people_and_images(app,report):
    from ai_widgets import AIConsentDialog
    report['calculations']*=2;report['ai_jobs']=generation.plan(report,report['ai_options']);report['ai_options']['cover']=True
    buffer=io.BytesIO();Image.new('RGB',(8,8),'white').save(buffer,'PNG');images=[{'person':0,'hand':'right','data':buffer.getvalue()},{'person':1,'hand':'left','data':buffer.getvalue()}]
    dialog=AIConsentDialog(None,report,'Gemini','fake',images);assert len(dialog.checks)==5
    with pytest.raises(ValueError):dialog.record()
    for check in dialog.checks:check.setChecked(True)
    consent=dialog.record();assert consent['people']==2 and consent['palm_images'] and consent['decorative_artwork'];assert len(consent['photo_manifest'])==2;assert 'PRIVATE NAME' not in json.dumps(consent);dialog.deleteLater()

def test_short_or_unsafe_ai_output_rejected(report):
    job=generation.plan(report,report['ai_options'])[0]
    with pytest.raises(ValueError,match='too short'):ai.validate_section({'title':job['title'],'body':'This is a short traditional reflection.'},job['title'],generation.job_data(report,job))
    with pytest.raises(ValueError):ai.validate_section({'title':'Safe','body':'## Other heading\nThese are symbolic themes only.'},'Safe')

def test_openai_and_gemini_request_shapes(monkeypatch):
    import openai
    from google import genai
    captured={}
    class Client:
        def __init__(self,**kwargs):self.responses=self;self.models=self
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def create(self,**kwargs):captured['OpenAI']=kwargs;return SimpleNamespace(output_text=json.dumps({'title':'Test','body':'A respectful symbolic reflection with practical choices.'}),usage=None,model='fake')
        def generate_content(self,**kwargs):captured['Gemini']=kwargs;return SimpleNamespace(text=json.dumps({'title':'Test','body':'A respectful symbolic reflection with practical choices.'}),usage_metadata=None,model_version='fake')
    monkeypatch.setattr(openai,'OpenAI',Client);monkeypatch.setattr(genai,'Client',Client)
    images=[{'person':0,'hand':'right','data':b'synthetic-fixture'}]
    for provider in ['OpenAI','Gemini']:ai.Provider(provider,'fake','not-a-real-key').call('Test',{'accuracy':'unknown'},images)
    assert captured['OpenAI']['input'][0]['content'][2]['type']=='input_image';assert 'right palm' in captured['OpenAI']['input'][0]['content'][1]['text'];assert captured['Gemini']['contents'][2].inline_data.mime_type=='image/png';assert captured['Gemini']['config'].response_mime_type=='application/json'

def test_automatic_submission_runs_to_pdf_with_artwork(app,tmp_path,report,monkeypatch):
    import app as desktop,keyring
    from ai_widgets import AIConsentDialog
    store=Store(tmp_path/'vault','secure-password');window=desktop.MainWindow(store);page=window.report_page
    key=store.save('clients',report['calculations'][0]['profile']);report['client_ids']=[key];report['ai_options']['cover']=True
    # Keep an end-to-end fixture small while exercising real planning, persistence, assembly and PDF rendering.
    report['original_text']=reports.text([('Education and learning','Original locally generated reflection.'),('Final balanced summary','Original balanced summary.')]);store.save('reports',report,report['id']);store.link(report['id'],[key]);window.open_report(report['id']);calls=[]
    class FakeProvider:
        def __init__(self,*args):pass
        def section(self,title,data,images=None):calls.append(title);return ai.Section(title=title,body=body({})),{'total_tokens':20}
        def cover(self,model):buffer=io.BytesIO();Image.new('RGB',(80,80),'lavender').save(buffer,'PNG');return buffer.getvalue(),{'total_tokens':10}
    monkeypatch.setattr(desktop,'Provider',FakeProvider);monkeypatch.setattr(keyring,'get_password',lambda *a:'not-a-real-key')
    def accept(dialog):
        for check in dialog.checks:check.setChecked(True)
        return QDialog.Accepted
    monkeypatch.setattr(AIConsentDialog,'exec',accept);page.start_ai(automatic=True);deadline=time.monotonic()+10
    while time.monotonic()<deadline and (page.worker.isRunning() or not page.current.get('auto_pdf_path')):app.processEvents();page.worker.wait(5)
    app.processEvents();assert calls==['Education and learning','Final balanced summary'];assert Path(page.current['auto_pdf_path']).exists();assert page.current['parent_version']==report['id'];assert page.current['consents'][0]['decorative_artwork'];assert page.current['artwork']['asset'];assert len(store.all('reports'))==2
    asset=page.current['artwork']['asset'];store.prune_assets();assert store.read_asset(asset);assert store.get('reports',report['id'])['original_text']==report['original_text']
    from pypdf import PdfReader
    text=''.join(p.extract_text() for p in PdfReader(page.current['auto_pdf_path']).pages);assert 'decorative artwork' in text
    store.delete_client(key);assert not (store.assets/asset).exists();window.close();store.close()

def test_resumption_skips_completed_jobs_and_cancel(app,report):
    from app import AIWorker
    report['original_text']=reports.text([('Education and learning','Original reflection.'),('Final balanced summary','Original summary.')]);report['ai_jobs']=generation.plan(report,report['ai_options']);first=report['ai_jobs'][0];report['ai_sections']={first['id']:{'title':first['title'],'body':body(first)}};calls=[]
    class Fake:
        def section(self,title,data):calls.append(title);return ai.Section(title=title,body=body({})),{}
    worker=AIWorker(report,'OpenAI','fake','never-real');worker.provider=Fake();worker.run();assert calls==['Final balanced summary'];calls.clear();worker.cancel.set();worker.run();assert calls==[]

def test_optional_art_failure_retains_text(app,report):
    from app import AIWorker
    report['ai_options']['cover']=True;report['ai_titles']=['Final balanced summary'];report['ai_options']['image_model']='fake';failures=[];completed=[]
    class Fake:
        def section(self,title,data):return ai.Section(title=title,body=body({})),{}
        def cover(self,model):raise RuntimeError('Synthetic artwork failure')
    worker=AIWorker(report,'Gemini','fake','never-real');worker.provider=Fake();worker.artwork_failed.connect(failures.append);worker.complete.connect(lambda:completed.append(True));worker.run();assert failures==['Synthetic artwork failure'] and completed

def test_no_photo_never_produces_invented_observations(app,report):
    from app import AIWorker
    report['calculations'][0]['profile']['palms']={'right':{'aligned':'synthetic-missing-asset'}};report['ai_options']['palm_images']=True;report['ai_jobs']=generation.plan(report,report['ai_options']);palm=next(job for job in report['ai_jobs'] if job['mode']=='palm');report['ai_jobs']=[palm];failures=[]
    class Fake:
        def section(self,*args):raise AssertionError('A photo-less palm request must not reach the provider')
    worker=AIWorker(report,'Gemini','fake','never-real');worker.provider=Fake();worker.failed.connect(failures.append);worker.run();assert failures and 'no image observations' in failures[0]

def test_image_generation_adapters_use_decorative_prompt_only(monkeypatch):
    import openai,base64
    from google import genai
    image=io.BytesIO();Image.new('RGB',(20,20),'lavender').save(image,'PNG');data=image.getvalue();captured={}
    class Client:
        def __init__(self,**kwargs):self.images=self;self.models=self
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def generate(self,**kwargs):captured['OpenAI']=kwargs;return SimpleNamespace(data=[SimpleNamespace(b64_json=base64.b64encode(data).decode())],usage=None)
        def generate_content(self,**kwargs):captured['Gemini']=kwargs;return SimpleNamespace(parts=[SimpleNamespace(inline_data=SimpleNamespace(data=data,mime_type='image/png'))],usage_metadata=None)
    monkeypatch.setattr(openai,'OpenAI',Client);monkeypatch.setattr(genai,'Client',Client)
    for provider in ['OpenAI','Gemini']:assert Image.open(io.BytesIO(ai.Provider(provider,'fake','never-real').cover('fake-image')[0])).size==(20,20)
    assert captured['OpenAI']['prompt']==ai.COVER_PROMPT==captured['Gemini']['contents'];assert 'No text, no chart' in ai.COVER_PROMPT
