"""Astroguru Windows-capable local desktop application. AGPL-3.0-or-later."""
from __future__ import annotations
import sys,os,json,uuid,datetime as dt,threading,hashlib
from pathlib import Path
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QDate,QThread,Signal,QByteArray,QTimer,QEvent,QStandardPaths,Slot
from PySide6.QtGui import QFont,QTextDocument,QImage,QPainter
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtPrintSupport import QPrintPreviewDialog,QPrinter
import core,charts,reports,matching
from storage import Store
from widgets import ProfileForm,PalmPanel
from ai import Provider,payload
import generation
from ai_widgets import AIOptions,AIConsentDialog

STYLE='''
QWidget { background: #f7f6f2; color: #302c43; font-family: "Segoe UI", "DejaVu Sans"; font-size: 14px; }
QMainWindow { background: #f7f6f2; }
QWidget#Sidebar { background: #242138; }
QWidget#Sidebar QLabel { background: transparent; color: #bcb5d4; }
QLabel#Brand { font-size: 27px; font-weight: 700; color: #f6efd9; padding: 18px 6px 4px 6px; }
QLabel#Eyebrow { font-size: 11px; font-weight: 600; color: #8c819d; letter-spacing: 1px; }
QLabel#Title { font-size: 28px; font-weight: 700; padding: 4px 0; }
QLabel#SectionTitle { font-size: 23px; font-weight: 650; background: transparent; }
QLabel#Subtitle { color: #766e84; background: transparent; }
QLabel#StepBadge { color: #77559c; font-size: 12px; font-weight: 700; padding: 8px 0; }
QLabel#InfoBanner { background: #eee9f6; border: 1px solid #e3dbee; border-radius: 10px; color: #625272; padding: 14px; }
QLabel#VaultBadge { background: #e8f0ea; color: #446b58; border-radius: 12px; padding: 7px 14px; font-size: 12px; }
QFrame#Card,QFrame#FormCard { background: white; border: 1px solid #e7e2ed; border-radius: 16px; }
QFrame#Card QLabel,QFrame#FormCard QLabel,QFrame#FormCard QCheckBox { background: transparent; }
QFrame#Hero { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #e9e0f6,stop:0.65 #edf0fb,stop:1 #f2ead9); border: 1px solid #e2d9ee; border-radius: 20px; }
QFrame#Hero QLabel { background: transparent; }
QLabel#HeroTitle { font-size: 34px; font-weight: 700; color: #423152; background: transparent; }
QLabel#StatValue { font-size: 36px; font-weight: 700; color: #77579a; background: transparent; }
QLabel#Counts { color: #82788e; padding: 6px; background: transparent; }
QListWidget { background: white; border: 1px solid #e7e2ed; border-radius: 12px; padding: 8px; outline: none; }
QListWidget::item { padding: 15px; border-radius: 8px; margin-bottom: 5px; }
QListWidget::item:selected { background: #eee6f8; color: #523766; }
QListWidget#Nav { background: #242138; border: none; padding: 4px; color: #c9c2da; font-size: 15px; }
QListWidget#Nav::item { padding: 16px 12px; margin: 3px 0; border-radius: 10px; }
QListWidget#Nav::item:hover { background: #343046; }
QListWidget#Nav::item:selected { background: #756092; color: white; }
QPushButton { background: #f0ebf7; border: 1px solid #e0d7eb; border-radius: 10px; padding: 11px 18px; font-weight: 600; }
QPushButton:hover { background: #e7def2; border-color: #c1aed8; }
QPushButton:pressed { background: #dacbe9; }
QPushButton:disabled { color: #a29aa9; background: #eeecf1; border-color: #e8e5eb; }
QPushButton#Primary { background: #70528e; color: white; border: 1px solid #70528e; }
QPushButton#Primary:hover { background: #5c407a; }
QPushButton#Primary:disabled { background: #c8b9d6; color: #eee8f3; border-color: #c8b9d6; }
QLineEdit,QDateEdit,QTimeEdit,QSpinBox,QDoubleSpinBox,QComboBox,QPlainTextEdit,QTextEdit,QTextBrowser { background: white; border: 1px solid #d9d2e2; border-radius: 10px; padding: 10px; selection-background-color: #ddd0ed; min-height: 22px; }
QLineEdit:focus,QDateEdit:focus,QTimeEdit:focus,QComboBox:focus,QPlainTextEdit:focus { border: 2px solid #9b7ec0; }
QLineEdit:read-only { background: #f2f3f7; color: #655971; }
QComboBox::drop-down,QDateEdit::drop-down { border: none; width: 28px; }
QComboBox QAbstractItemView { background: white; selection-background-color: #e8dff2; padding: 8px; border: 1px solid #d9d2e2; }
QCheckBox { spacing: 9px; padding: 5px 0; }
QCheckBox::indicator { width: 18px; height: 18px; border: 1px solid #bfb0cf; border-radius: 4px; background: white; }
QCheckBox::indicator:checked { background: #70528e; border-color: #70528e; image: url(CHECKMARK_PATH); }
QComboBox::down-arrow,QDateEdit::down-arrow { image: url(CHEVRON_PATH); width: 18px; height: 18px; }
QScrollArea { border: none; background: transparent; }
QScrollBar:vertical { background: #f0edf4; width: 8px; margin: 2px; border-radius: 4px; }
QScrollBar::handle:vertical { background: #cec2de; min-height: 28px; border-radius: 4px; }
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical { height: 0; }
QGraphicsView#PalmCanvas { background: #eff1f7; border: 1px solid #dfd9e8; border-radius: 16px; }
QTabWidget::pane { border: 1px solid #e5dfed; border-radius: 12px; background: white; }
QTabBar::tab { padding: 12px 22px; background: #f0ecf7; border-top-left-radius: 8px; border-top-right-radius: 8px; margin-right: 4px; }
QTabBar::tab:selected { background: #ddd0ef; color: #523c6a; }
QProgressBar { border: none; border-radius: 3px; background: #e7e0ef; text-align: center; height: 8px; }
QProgressBar::chunk { background: #9475b7; border-radius: 3px; }
QSlider::groove:horizontal { background: #e7e0ef; height: 5px; border-radius: 2px; }
QSlider::handle:horizontal { background: #8a68ad; width: 16px; margin: -6px 0; border-radius: 8px; }
'''

STYLE=STYLE.replace('CHECKMARK_PATH',Path(__file__).with_name('checkmark.svg').as_posix()).replace('CHEVRON_PATH',Path(__file__).with_name('chevron.svg').as_posix())

def button(label,callback,primary=False):
    b=QPushButton(label);b.clicked.connect(callback)
    if primary:b.setObjectName('Primary')
    return b

def heading(layout,title,subtitle=None):
    h=QLabel(title);h.setObjectName('Title');layout.addWidget(h)
    if subtitle:s=QLabel(subtitle);s.setWordWrap(True);s.setObjectName('Subtitle');layout.addWidget(s)

def safe(parent,action):
    try:return action()
    except Exception as e:QMessageBox.warning(parent,'Astroguru',str(e));return None

class AIWorker(QThread):
    progress_message=Signal(str);section_ready=Signal(object,object,object);failed=Signal(str);complete=Signal();artwork_ready=Signal(bytes,object);artwork_failed=Signal(str)
    def __init__(self,report,provider,model,key,images=None):
        super().__init__();import copy
        self.report=copy.deepcopy(report);self.images=images or [];self.cancel=threading.Event();self.provider=Provider(provider,model,key,self.cancel);self.provider.progress=self.progress_message.emit
    def run(self):
        try:
            if self.report.get('ai_jobs'):
                for job in self.report['ai_jobs']:
                    if self.cancel.is_set():raise InterruptedError('Cancelled')
                    if job['id'] in self.report.get('ai_sections',{}):continue
                    self.progress_message.emit('Preparing section '+str(self.report['ai_jobs'].index(job)+1)+' of '+str(len(self.report['ai_jobs']))+'…')
                    data=generation.job_data(self.report,job);images=[image for image in self.images if image['person']==job.get('person')] if job['mode']=='palm' else []
                    if job['mode']=='palm' and not images:raise ValueError('Palm photographs are unavailable; no image observations will be invented. Check the saved photos or regenerate without AI palm interpretation.')
                    section,usage=self.provider.section(job['title'],data,images) if images else self.provider.section(job['title'],data)
                    self.section_ready.emit(job['id'],section.model_dump(),usage)
            else:
                data=payload(self.report)
                for index,title in enumerate(self.report['ai_titles']):
                    if str(index) in self.report.get('ai_sections',{}):continue
                    section,usage=self.provider.section(title,data);self.section_ready.emit(index,section.model_dump(),usage)
            if self.report.get('ai_options',{}).get('cover') and not self.report.get('artwork'):
                try:
                    image,usage=self.provider.cover(self.report['ai_options']['image_model']);self.artwork_ready.emit(image,usage)
                except InterruptedError:raise
                except Exception as error:self.artwork_failed.emit(str(error))
            self.complete.emit()
        except InterruptedError:self.failed.emit('Cancelled. Completed sections are saved; resume when ready.')
        except Exception as error:self.failed.emit(str(error))

class Wizard(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;self.client_id=None;self.calculation=None
        layout=QVBoxLayout(self);layout.setContentsMargins(28,24,28,24);layout.setSpacing(16);heading(layout,'Create a reading','One clear step at a time. Your work stays in the local encrypted vault.')
        rail=QHBoxLayout();self.steps=QLabel();self.steps.setObjectName('StepBadge');rail.addWidget(self.steps);rail.addStretch();self.stage=QLabel('PROFILE  /  PALMS  /  SETTINGS  /  REVIEW');self.stage.setObjectName('Eyebrow');rail.addWidget(self.stage);layout.addLayout(rail)
        self.progress=QProgressBar();self.progress.setRange(1,10);self.progress.setTextVisible(False);self.progress.setFixedHeight(6);layout.addWidget(self.progress);self.pages=QStackedWidget();layout.addWidget(self.pages,1)
        self.form=ProfileForm(external_navigation=True);client=QWidget();body=QVBoxLayout(client);body.setContentsMargins(0,0,0,0);row=QHBoxLayout();self.existing=QComboBox();self.existing.addItem('Create a new client',None)
        for key,profile in window.store.all('clients'):self.existing.addItem(profile['first_name']+' '+profile.get('last_name','')+' · '+key[:8],key)
        self.existing.currentIndexChanged.connect(self.load_client);row.addWidget(QLabel('Client record'));row.addWidget(self.existing,1);body.addLayout(row);body.addWidget(self.form,1);self.pages.addWidget(client)
        self.palms={}
        for hand in ['right','left']:
            panel=PalmPanel(hand,window.store);self.palms[hand]=panel;self.pages.addWidget(panel)
        self.settings_page=QWidget();body=QVBoxLayout(self.settings_page);body.setContentsMargins(0,0,0,0);heading(body,'Calculation settings','Choose the chart presentation and recorded calculation rules.')
        card=QFrame();card.setObjectName('FormCard');form=QFormLayout(card);form.setContentsMargins(28,24,28,24);form.setVerticalSpacing(20);body.addWidget(card)
        self.asof=QDateEdit(QDate.currentDate());self.asof.setCalendarPopup(True);self.asof.setDisplayFormat('yyyy-MM-dd');form.addRow('Report as-of date',self.asof)
        self.ayanamsa=QComboBox();self.ayanamsa.addItems(core.AYANAMSAS);form.addRow('Sidereal ayanamsa',self.ayanamsa)
        self.house=QComboBox();self.house.addItem('Placidus','P');self.house.addItem('Whole Sign','W');self.house.addItem('Equal','E');form.addRow('Western house system',self.house)
        self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);form.addRow('Kundali layout',self.layout)
        self.hindi=QCheckBox('Hindi sign labels in chart SVG / PNG');form.addRow('Chart labels',self.hindi)
        self.intimacy=QCheckBox('Explicit client consent for adult intimacy reflection');form.addRow('',self.intimacy)
        note=QLabel('Vedic houses: Whole Sign · Mean lunar nodes · Moshier ephemeris\nBirth-time limitations and selected settings are recorded in the report.');note.setWordWrap(True);note.setObjectName('InfoBanner');body.addWidget(note);body.addStretch();self.pages.addWidget(self.settings_page)
        review=QWidget();body=QVBoxLayout(review);body.setContentsMargins(0,0,0,0);heading(body,'Review the details','Confirm the birth information before the local calculations run.');self.review=QTextBrowser();self.review.setOpenExternalLinks(False);body.addWidget(self.review,1);self.confirm=QCheckBox('I have reviewed and confirmed these birth details and settings');body.addWidget(self.confirm);self.pages.addWidget(review)
        final=QWidget();body=QVBoxLayout(final);body.setContentsMargins(0,0,0,0);heading(body,'Ready to generate','Choose a local template or automatic detailed AI generation. API credentials are needed for AI reports.');self.result=QLabel('');self.result.setWordWrap(True);body.addWidget(self.result);self.ai_options=AIOptions(window);body.addWidget(self.ai_options);body.addWidget(button('Submit and generate report',lambda:safe(self,self.generate),True));body.addStretch();final_scroll=QScrollArea();final_scroll.setWidgetResizable(True);final_scroll.setFrameShape(QFrame.NoFrame);final_scroll.setWidget(final);self.pages.addWidget(final_scroll)
        nav=QHBoxLayout();self.back=button('← Back',self.previous);self.skip=button('Skip this palm',lambda:safe(self,self.skip_palm));self.next=button('Continue →',lambda:safe(self,self.advance),True);nav.addWidget(self.back);nav.addStretch();nav.addWidget(self.skip);nav.addWidget(self.next);layout.addLayout(nav);self.form.page_changed.connect(self.update_step);self.update_step()
    def load_client(self):
        if any(getattr(panel,'background_worker',None) and panel.background_worker.isRunning() for panel in self.palms.values()):
            self.existing.blockSignals(True);self.existing.setCurrentIndex(self.existing.findData(self.client_id));self.existing.blockSignals(False);QMessageBox.information(self,'Image processing','Wait for the background preview before switching clients.');return
        key=self.existing.currentData();self.client_id=key
        if key:self.form.load(self.window.store.get('clients',key))
        else:self.form.reset()
        self.form.stack.setCurrentIndex(0);self.confirm.setChecked(False)
        for hand,panel in self.palms.items():
            try:panel.load_record(self.form.palms.get(hand))
            except Exception as error:QMessageBox.warning(self,'Saved palm review',str(error));panel.clear();self.form.palms.pop(hand,None)
        self.update_step()
    def settings(self):return {'as_of':self.asof.date().toString('yyyy-MM-dd'),'ayanamsa':self.ayanamsa.currentText(),'vedic_house_system':'Whole Sign','western_house_system':self.house.currentData(),'nodes':'Mean','ephemeris':'Moshier','leap_day_policy':'February 28 in non-leap years'}
    def update_step(self,*args):
        index=self.pages.currentIndex();step=self.form.stack.currentIndex()+1 if index==0 else index+5
        title=self.form.TITLES[self.form.stack.currentIndex()] if index==0 else ['','Right palm','Left palm','Calculation settings','Review & confirm','Generate report'][index]
        self.progress.setValue(step);self.steps.setText(f'STEP {step:02d} OF 10  ·  {title}');self.back.setEnabled(step>1);self.next.setVisible(index<5);self.skip.setVisible(index in (1,2))
    def previous(self):
        index=self.pages.currentIndex()
        if index==0:self.form.previous_page()
        else:
            self.pages.setCurrentIndex(index-1)
            if index==1:self.form.stack.setCurrentIndex(4)
        self.confirm.setChecked(False);self.update_step()
    def skip_palm(self):
        index=self.pages.currentIndex()
        if index not in (1,2):return
        hand='right' if index==1 else 'left';self.palms[hand].clear();self.form.palms.pop(hand,None);self.advance()
    def advance(self):
        index=self.pages.currentIndex()
        if index==0:
            self.form.check_page()
            if self.form.stack.currentIndex()<4:self.form.next_page();return
            self.form.checked()
        if index in (1,2):
            hand='right' if index==1 else 'left';record=self.palms[hand].record()
            if record:self.form.palms[hand]=record
            else:self.form.palms.pop(hand,None)
        if index==3:
            profile=self.form.checked();core.validate(profile,self.settings()['as_of']);horizon=core.horizons(dt.date.fromisoformat(profile['birth_date']),dt.date.fromisoformat(self.settings()['as_of']))
            if horizon['age']<18 and self.intimacy.isChecked():raise ValueError('Adult intimacy sections are unavailable for children.')
            from html import escape
            rows=[('Client',' '.join([profile['first_name'],profile.get('last_name','')])),('Birth date',profile['birth_date']),('Birth time',profile['birth_time'] or 'Unknown — no ascendant or precise time-dependent chart'),('Time accuracy',profile['accuracy']),('Birthplace',', '.join(profile.get(key,'') for key in ['city','state','country'] if profile.get(key))),('Coordinates',f"{profile['latitude']}, {profile['longitude']}"),('Historical timezone',profile['timezone']),('Time verification','Verified by operator'),('Gender',profile.get('gender','')),('Report language',profile['language']),('Dominant hand',profile['dominant_hand']),('Palm photographs',', '.join(hand.title() for hand in profile['palms']) or 'Skipped'),('Report as of',self.settings()['as_of']),('Completed age',str(horizon['age'])),('Ayanamsa',self.ayanamsa.currentText()),('Western houses',self.house.currentText()),('Chart layout',self.layout.currentText()),('Historical start',horizon['history'][0]['start']),('Future limit','Future horizon ended' if horizon['future_ended'] else horizon['future_end'])]
            markup='<h2>Birth details & calculation settings</h2><table cellspacing="10">'+''.join('<tr><td><b>'+escape(key)+'</b></td><td>'+escape(str(value))+'</td></tr>' for key,value in rows)+'</table><p>Review all five information pages with Back if any detail needs correction. Unknown and approximate times limit the report’s precision.</p>'
            self.review.setHtml(markup);self.confirm.setChecked(False)
        if index==4 and not self.confirm.isChecked():raise ValueError('Confirm the reviewed birth details before calculating.')
        if index<5:self.pages.setCurrentIndex(index+1)
        self.update_step()
    def generate(self):
        if not self.confirm.isChecked():raise ValueError('Birth details must be confirmed.')
        p=self.form.checked();settings=self.settings();calculation=core.calculate(p,settings)
        duplicates=self.window.store.duplicates(p)
        if not self.client_id and duplicates:
            if QMessageBox.question(self,'Possible duplicate','A client with the same name and birth date exists. Save a separate record?')!=QMessageBox.Yes:return
        self.client_id=self.window.store.save('clients',p,self.client_id)
        sections=reports.natal_sections(calculation,intimacy=self.intimacy.isChecked());identifier=str(uuid.uuid4())
        report={'id':identifier,'title':'Personal reading · '+p['first_name'],'kind':'natal','as_of':settings['as_of'],'version':1,'client_ids':[self.client_id],'calculations':[calculation],'original_text':reports.text(sections),'edited_text':'','layout':self.layout.currentText(),'chart_language':'Hindi' if self.hindi.isChecked() else 'English','intimacy':self.intimacy.isChecked(),'status':'template complete','consents':[],'ai_sections':{},'ai_titles':[],'ai_options':self.ai_options.value()}
        self.window.store.save('reports',report,identifier);self.window.store.link(identifier,[self.client_id]);self.window.refresh_clients();self.window.open_report(identifier);self.result.setText('Calculated report saved locally.');self.window.nav.setCurrentRow(3)
        if report['ai_options']['automatic']:self.window.report_page.start_ai(automatic=True)
        else:self.window.report_page.status.setText('Local template saved. No API request was sent: automatic AI is off. Enable automatic generation or click Generate / Resume AI.')

class MatchPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;l=QVBoxLayout(self);heading(l,'Matchmaking','Two calculated profiles. Traditional points remain separate from optional compatibility views.')
        self.people=[];r=QHBoxLayout()
        for i in range(2):
            card=QFrame();card.setObjectName('Card');cl=QVBoxLayout(card);cl.addWidget(QLabel('Person '+str(i+1)));combo=QComboBox();cl.addWidget(combo);cl.addWidget(button('Enter a new profile',lambda checked=False,j=i:self.new_profile(j)));self.people.append(combo);r.addWidget(card)
        l.addLayout(r);self.roles=QComboBox();self.roles.addItem('Select explicit traditional table roles',None);self.roles.addItem('Person 1 = groom role; Person 2 = bride role','groom');self.roles.addItem('Person 1 = bride role; Person 2 = groom role','bride');l.addWidget(self.roles)
        explanation=QLabel('Roles are table conventions, never inferred from names or gender. This baseline North Indian tradition does not establish validation for all pairings. No cancellation rules are applied. Palm images have no effect on the score.');explanation.setWordWrap(True);l.addWidget(explanation)
        f=QFormLayout();self.asof=QDateEdit(QDate.currentDate());self.asof.setCalendarPopup(True);self.asof.setDisplayFormat('yyyy-MM-dd');f.addRow('As of',self.asof);self.ayan=QComboBox();self.ayan.addItems(core.AYANAMSAS);f.addRow('Ayanamsa',self.ayan);self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);f.addRow('Chart layout',self.layout);l.addLayout(f)
        self.western=QCheckBox('Separate Western synastry (tropical calculated aspects)');self.num=QCheckBox('Separate Pythagorean numerology');self.reflection=QCheckBox('Voluntary relationship reflection');self.intimacy=QCheckBox('Both adults explicitly consent to intimacy reflection');
        for w in [self.western,self.num,self.reflection,self.intimacy]:l.addWidget(w)
        self.concerns=QPlainTextEdit();self.concerns.setPlaceholderText('Voluntarily supplied preferences, values and concerns (local only)');self.concerns.setMaximumHeight(110);l.addWidget(self.concerns)
        self.confirm=QCheckBox('Both birth profiles and calculation settings have been reviewed and confirmed');l.addWidget(self.confirm)
        self.ai_options=AIOptions(window);l.addWidget(self.ai_options);l.addWidget(button('Submit and generate matchmaking report',lambda:safe(self,self.generate),True));l.addStretch();self.refresh()
    def refresh(self):
        for combo in self.people:
            chosen=combo.currentData();combo.clear();combo.addItem('Select client',None)
            for key,p in self.window.store.all('clients'):combo.addItem(p['first_name']+' '+p.get('last_name','')+' · '+key[:8],key)
            if chosen:combo.setCurrentIndex(combo.findData(chosen))
    def new_profile(self,index):
        key=self.window.edit_client()
        if key:self.refresh();self.people[index].setCurrentIndex(self.people[index].findData(key))
    def generate(self):
        ids=[combo.currentData() for combo in self.people]
        if not all(ids) or ids[0]==ids[1]:raise ValueError('Select two distinct client records.')
        if not self.roles.currentData():raise ValueError('Assign both traditional table roles explicitly.')
        if not self.confirm.isChecked():raise ValueError('Confirm that both birth profiles and settings have been reviewed.')
        profiles=[self.window.store.get('clients',key) for key in ids]
        dialog=QMessageBox(self);dialog.setWindowTitle('Final birth-details confirmation');dialog.setText('Review both profiles before calculation.');dialog.setDetailedText(json.dumps(profiles,ensure_ascii=False,indent=2));dialog.setStandardButtons(QMessageBox.Ok|QMessageBox.Cancel)
        if dialog.exec()!=QMessageBox.Ok:return
        settings={'as_of':self.asof.date().toString('yyyy-MM-dd'),'ayanamsa':self.ayan.currentText(),'vedic_house_system':'Whole Sign','western_house_system':'P','nodes':'Mean','ephemeris':'Moshier'}
        cs=[core.calculate(p,settings) for p in profiles]
        if self.intimacy.isChecked() and any(c['horizons']['age']<18 for c in cs):raise ValueError('Adult intimacy reflection requires two adults.')
        options={'western':self.western.isChecked(),'numerology':self.num.isChecked(),'reflection':self.reflection.isChecked(),'intimacy':self.intimacy.isChecked(),'concerns':self.concerns.toPlainText()}
        m=matching.match(*cs,self.roles.currentData(),options);sections=reports.match_sections(*cs,m);identifier=str(uuid.uuid4())
        if self.ai_options.palms.isChecked() and any(c['profile'].get('palms') for c in cs):sections.insert(-1,('Optional palm review','Separate optional palm observations; these never alter the traditional compatibility score.'))
        report={'id':identifier,'title':'Matchmaking · '+profiles[0]['first_name']+' & '+profiles[1]['first_name'],'kind':'matchmaking','as_of':settings['as_of'],'version':1,'client_ids':ids,'calculations':cs,'matching':m,'original_text':reports.text(sections),'edited_text':'','layout':self.layout.currentText(),'chart_language':'English','intimacy':options['intimacy'],'status':'template complete','consents':[],'ai_sections':{},'ai_titles':[],'ai_options':self.ai_options.value()}
        self.window.store.save('reports',report,identifier);self.window.store.link(identifier,ids);self.window.open_report(identifier);self.window.nav.setCurrentRow(3)
        if report['ai_options']['automatic']:self.window.report_page.start_ai(automatic=True)
        else:self.window.report_page.status.setText('Local template saved. No API request was sent: automatic AI is off. Enable automatic generation or click Generate / Resume AI.')

class ReportPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;self.current=None;self.worker=None
        l=QVBoxLayout(self);heading(l,'Reports','Preserve calculation snapshots and generated text. Save operator edits as a new version before export.')
        r=QHBoxLayout();self.list=QComboBox();self.list.currentIndexChanged.connect(self.select);r.addWidget(self.list,1);r.addWidget(button('Refresh',self.refresh));l.addLayout(r)
        self.tabs=QTabWidget();l.addWidget(self.tabs,1)
        self.editor=QPlainTextEdit();self.tabs.addTab(self.editor,'Editable report')
        self.ai_preview=QPlainTextEdit();self.ai_preview.setReadOnly(True);self.tabs.addTab(self.ai_preview,'AI live progress');self.ai_clock=QTimer(self);self.ai_clock.setInterval(1000);self.ai_clock.timeout.connect(self.ai_tick);self.ai_elapsed=0;self.ai_stage='Not started'
        self.chart_page=QWidget();self.chart_l=QVBoxLayout(self.chart_page);controls=QHBoxLayout();self.layout=QComboBox();self.layout.addItems(['North Indian','South Indian']);self.division=QComboBox();self.division.addItems(['D1','D9']);self.language=QComboBox();self.language.addItems(['English','Hindi']);
        for w in [self.layout,self.division,self.language]:controls.addWidget(w);w.currentTextChanged.connect(self.render_charts)
        controls.addWidget(button('SVG export',lambda:safe(self,lambda:self.export_chart('svg'))));controls.addWidget(button('PNG export',lambda:safe(self,lambda:self.export_chart('png'))));self.chart_l.addLayout(controls);self.chart_widgets=QHBoxLayout();self.chart_l.addLayout(self.chart_widgets,1);self.chart_hint=QLabel('');self.chart_hint.setWordWrap(True);self.chart_l.addWidget(self.chart_hint);self.chart_summary=QPlainTextEdit();self.chart_summary.setReadOnly(True);self.chart_summary.setMaximumHeight(160);self.chart_l.addWidget(self.chart_summary);self.tabs.addTab(self.chart_page,'Kundali charts')
        self.snapshot=QPlainTextEdit();self.snapshot.setReadOnly(True);self.tabs.addTab(self.snapshot,'Calculation snapshot');self.western_view=QPlainTextEdit();self.western_view.setReadOnly(True);self.tabs.addTab(self.western_view,'Western view');self.cover_preview=QLabel('No AI cover artwork. Calculated charts are available in their own tab.');self.cover_preview.setAlignment(Qt.AlignCenter);self.cover_preview.setWordWrap(True);self.tabs.addTab(self.cover_preview,'Decorative artwork')
        self.status=QLabel('Select a report.');self.status.setWordWrap(True);l.addWidget(self.status);self.progress=QProgressBar();self.progress.setRange(0,100);l.addWidget(self.progress)
        row=QHBoxLayout()
        for label,func in [('Save edited version',self.save_edits),('Regenerate',self.regenerate),('PDF export',self.pdf),('Print preview',self.print_preview),('AI generate / resume',self.start_ai),('Cancel AI',self.cancel_ai)]:row.addWidget(button(label,lambda checked=False,f=func:safe(self,f)))
        l.addLayout(row);extras=QHBoxLayout();extras.addWidget(button('Open automatic PDF',lambda:safe(self,self.open_automatic_pdf)));extras.addWidget(button('Gemini website · manual prompt',lambda:safe(self,self.manual_gemini)));extras.addStretch();l.addLayout(extras)
    def refresh(self,selected=None):
        selected=selected or (self.current or {}).get('id');self.list.blockSignals(True);self.list.clear();self.list.addItem('Select saved report',None)
        for key,p in self.window.store.all('reports'):self.list.addItem(p['title']+' · v'+str(p['version'])+' · '+p['status'],key)
        if selected:self.list.setCurrentIndex(self.list.findData(selected))
        self.list.blockSignals(False);self.select()
    def select(self):
        if self.worker and self.worker.isRunning():
            old=self.list.findData(self.current['id']);self.list.blockSignals(True);self.list.setCurrentIndex(old);self.list.blockSignals(False);return
        key=self.list.currentData();self.current=self.window.store.get('reports',key) if key else None
        if not self.current:self.editor.clear();self.snapshot.clear();return
        self.ai_preview.setPlainText('\n\n'.join(section['title']+'\n'+section['body'] for section in self.current.get('ai_sections',{}).values()) or 'No completed AI sections yet. Use AI generate / resume and accept consent to start.')
        cover=self.cover_bytes();self.cover_preview.clear()
        if cover:
            from PySide6.QtGui import QPixmap
            pix=QPixmap();pix.loadFromData(cover);self.cover_preview.setPixmap(pix.scaled(500,500,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        else:self.cover_preview.setText('No AI cover artwork. Calculated charts are available in their own tab.')
        self.editor.setPlainText(self.current.get('edited_text') or self.current['original_text']);self.snapshot.setPlainText(json.dumps({k:v for k,v in self.current.items() if k not in ['original_text','edited_text','ai_sections']},ensure_ascii=False,indent=2));self.western_view.setPlainText('\n\n'.join('Person '+str(i+1)+'\n'+reports.western_text(c) for i,c in enumerate(self.current['calculations'])));self.layout.setCurrentText(self.current.get('layout','North Indian'));self.language.setCurrentText(self.current.get('chart_language','English'));self.render_charts();self.status.setText('Status: '+self.current['status']+(' · '+self.current['last_ai_error'] if self.current.get('last_ai_error') else '')+' · '+('Operator edited' if self.current.get('edited_text') else 'Original generated template')+' · AI costs unavailable until provider usage is returned.');self.progress.setValue(int(100*len(self.current.get('ai_sections',{}))/max(1,len(self.current['ai_titles']))))
    def render_charts(self):
        while self.chart_widgets.count():
            item=self.chart_widgets.takeAt(0)
            if item.widget():item.widget().deleteLater()
        if not self.current:return
        if self.division.currentText()=='D9' and not all(c['d9_allowed'] for c in self.current['calculations']):
            self.chart_hint.setText('D9 withheld: a confirmed exact birth time is required for each displayed profile.');return
        self.chart_summary.setPlainText('\n\n'.join('Person '+str(i+1)+': '+c['profile']['first_name']+' · '+c['profile']['birth_date']+' · '+(c['profile']['birth_time'] or 'time unknown')+' · '+c['accuracy']+'\n'+c['profile']['city']+' / '+c['profile']['timezone']+' · '+c['settings']['ayanamsa']+' / Whole Sign\n'+reports.placement_lines(c)+'\nTraditional reflection: '+('; '.join(name+' — '+reports.THEMES[name] for name in ['Sun','Moon','Venus']) if c['vedic'] else 'Confirmed birth time is needed for precise natal interpretation.') for i,c in enumerate(self.current['calculations'])))
        for c in self.current['calculations']:
            w=QSvgWidget();w.load(QByteArray(charts.svg(c,self.layout.currentText(),self.division.currentText(),self.language.currentText()).encode()));self.chart_widgets.addWidget(w)
        self.chart_hint.setText('The same saved calculations supply chart graphics and written placement tables. R = retrograde; degrees in D9 are divisional degrees. Approximate-time ascendants/houses are provisional. Hindi sign labels are available in SVG/PNG; PDF currently uses English for font portability.')
    def export_chart(self,kind):
        if not self.current:raise ValueError('Select a report.')
        index=0
        if len(self.current['calculations'])>1:
            chosen,ok=QInputDialog.getItem(self,'Chart export','Person',['Person 1','Person 2'],0,False)
            if not ok:return
            index=0 if chosen=='Person 1' else 1
        value=charts.svg(self.current['calculations'][index],self.layout.currentText(),self.division.currentText(),self.language.currentText())
        filename,_=QFileDialog.getSaveFileName(self,'Export chart','Astroguru-chart-'+self.current['id'][:8]+'.'+kind,kind.upper()+' (*.'+kind+')')
        if filename:
            if kind=='svg':Path(filename).write_text(value,encoding='utf-8')
            else:charts.png(value,filename)
            self.status.setText('Chart exported.')
    def require(self):
        if not self.current:raise ValueError('Select a saved report.')
    def save_edits(self):
        self.require()
        if self.worker and self.worker.isRunning():raise ValueError('Wait for or cancel AI generation before saving edits.')
        value=self.editor.toPlainText()
        if value==(self.current.get('edited_text') or self.current['original_text']):return
        report=dict(self.current);old=report['id'];new=str(uuid.uuid4());report.update(id=new,version=report['version']+1,edited_text=value,parent_version=old,edited_at=dt.datetime.now(dt.timezone.utc).isoformat(),layout=self.layout.currentText(),chart_language=self.language.currentText());self.window.store.save('reports',report,new)
        links=[x[0] for x in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(old,))];self.window.store.link(new,links);self.refresh(new)
    def regenerate(self):
        self.require()
        links=self.current.get('client_ids') or [row[0] for row in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(self.current['id'],))]
        if self.current['kind']=='matchmaking':
            self.window.match_page.refresh()
            for combo,key in zip(self.window.match_page.people,links):combo.setCurrentIndex(combo.findData(key))
            self.window.match_page.roles.setCurrentIndex(self.window.match_page.roles.findData(self.current['matching']['role_a']));self.window.match_page.confirm.setChecked(False);self.window.nav.setCurrentRow(4)
        else:
            self.window.reset_wizard();wizard=self.window.wizard
            if links:wizard.existing.setCurrentIndex(wizard.existing.findData(links[0]))
            self.window.nav.setCurrentRow(2)
    def pdf(self):
        self.require();self.save_edits();filename,_=QFileDialog.getSaveFileName(self,'Export professional PDF','Astroguru-report-'+self.current['id'][:8]+'.pdf','PDF (*.pdf)')
        if filename:reports.export_pdf(self.current,filename,self.window.config.value('provider','Astroguru'),self.window.config.value('logo','') or None,self.cover_bytes());self.status.setText('PDF exported with vector charts, contents and page numbers.')
    def print_preview(self):
        self.require();self.save_edits()
        from PySide6.QtPdf import QPdfDocument
        import tempfile
        # Preview/print the exact PDF export; keeps charts and pagination consistent.
        with tempfile.TemporaryDirectory(prefix='astroguru-print-') as folder:
            path=Path(folder)/'preview.pdf';reports.export_pdf(self.current,path,self.window.config.value('provider','Astroguru'),self.window.config.value('logo','') or None,self.cover_bytes())
            pdf=QPdfDocument(self);pdf.load(str(path));printer=QPrinter(QPrinter.HighResolution)
            from PySide6.QtGui import QPageLayout,QPageSize
            printer.setPageSize(QPageSize(QPageSize.A4));printer.setPageOrientation(QPageLayout.Landscape if len(self.current['calculations'])>1 else QPageLayout.Portrait);preview=QPrintPreviewDialog(printer,self)
            def paint(p):
                painter=QPainter(p)
                for page in range(pdf.pageCount()):
                    if page:p.newPage()
                    rect=p.pageRect(QPrinter.DevicePixel);im=pdf.render(page,rect.size().toSize());painter.drawImage(rect,im)
                painter.end()
            preview.paintRequested.connect(paint);preview.exec();pdf.close();pdf.deleteLater()
    def start_ai(self,automatic=False):
        self.require()
        if self.worker and self.worker.isRunning():raise ValueError('Generation is already running.')
        self.save_edits();provider=self.window.config.value('ai_provider','OpenAI');model=self.window.config.value('model_'+provider,'gpt-4.1' if provider=='OpenAI' else 'gemini-flash-latest')
        import keyring
        try:key=keyring.get_password('Astroguru',provider)
        except Exception:raise ValueError('Secure OS credential store unavailable. Configure Windows Credential Manager. Keys will not be written to files.')
        if not key:raise ValueError('Add the '+provider+' API key in Settings. Your local report is already saved. Gemini keys are available through Google AI Studio using your Google account; consumer website sign-in is not API authorization.')
        options=self.current.setdefault('ai_options',{'depth':'Very detailed','client_context':False,'palm_images':False,'cover':False,'auto_pdf':automatic,'pdf_dir':str(self.window.store.folder/'exports')})
        if not self.current.get('ai_jobs') and not self.current.get('ai_sections'):
            self.current['ai_jobs']=generation.plan(self.current,options);self.current['ai_titles']=[job['title'] for job in self.current['ai_jobs']]
        images=[]
        if options.get('palm_images'):
            for person,calculation in enumerate(self.current['calculations']):
                for hand,photo in calculation['profile'].get('palms',{}).items():
                    if photo.get('aligned'):images.append({'person':person,'hand':hand,'data':self.window.store.read_asset(photo['aligned'])})
        consent=AIConsentDialog(self,self.current,provider,model,images)
        if consent.exec()!=QDialog.Accepted:
            self.status.setText('Awaiting consent. No API request was sent. Click Generate / Resume AI to review and accept consent.');return
        self.current['consents'].append(consent.record());self.current.update(status='AI generating',ai_provider=provider,ai_model=model);self.window.store.save('reports',self.current,self.current['id'])
        self.worker=AIWorker(self.current,provider,model,key,images);self.worker.progress_message.connect(self.ai_progress);self.worker.section_ready.connect(self.ai_section);self.worker.failed.connect(self.ai_failed);self.worker.complete.connect(self.ai_complete);self.worker.artwork_ready.connect(self.ai_artwork_ready);self.worker.artwork_failed.connect(self.ai_artwork_failed);self.ai_elapsed=0;self.ai_stage='Starting provider worker';self.ai_preview.setPlainText('Starting AI generation. Completed sections will appear here; the full report/PDF follows after all sections finish.');self.tabs.setCurrentWidget(self.ai_preview);self.ai_clock.start();self.current.pop('last_ai_error',None);self.worker.start();self.status.setText('Generating the detailed report section by section. Completed work is saved automatically. Optional artwork runs after the text; PDF assembly follows. Cancel preserves completed sections.');self.window.nav.setEnabled(False);self.progress.setValue(int(100*len(self.current['ai_sections'])/max(1,len(self.current['ai_titles']))))
    def ai_artwork_ready(self,image,usage):
        self.current.pop('artwork_error',None);self.current['artwork']={'asset':self.window.store.asset(image),'provider':self.current['ai_provider'],'model':self.current['ai_options']['image_model'],'kind':'AI-generated decorative cover; not a calculated chart','timestamp':dt.datetime.now(dt.timezone.utc).isoformat()};self.current.setdefault('usage',[]).append(usage);self.window.store.save('reports',self.current,self.current['id'])
    def ai_artwork_failed(self,message):
        self.current['artwork_error']=message;self.window.store.save('reports',self.current,self.current['id'])
    def cover_bytes(self):
        artifact=(self.current or {}).get('artwork',{});return self.window.store.read_asset(artifact['asset']) if artifact.get('asset') else None
    def open_automatic_pdf(self):
        self.require();filename=self.current.get('auto_pdf_path')
        if not filename or not Path(filename).exists():raise ValueError('No automatic PDF is available yet. Use PDF export or resume generation.')
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(filename))
    def manual_gemini(self):
        self.require();prompt=generation.manual_prompt(self.current);dialog=QDialog(self);dialog.setWindowTitle('Gemini website · manual fallback');dialog.resize(850,700);layout=QVBoxLayout(dialog);label=QLabel('Sign into Gemini in your own browser. This route requires manual copy/paste; full automation requires the official API key. Review the prompt and record each person’s consent before copying. Palm photographs and direct name/birth-time/location fields are excluded. Selected voluntary notes may contain private information.');label.setWordWrap(True);layout.addWidget(label);view=QPlainTextEdit(prompt);view.setReadOnly(True);layout.addWidget(view,1)
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        checks=[]
        for person in range(len(self.current['calculations'])):
            check=QCheckBox(f'Person {person+1} explicitly consents to sharing this reviewed prompt with the Gemini website');layout.addWidget(check);checks.append(check)
        def copy_prompt():
            if not all(check.isChecked() for check in checks):raise ValueError('Consent is required before copying this client payload for external use.')
            self.current['consents'].append({'provider':'Gemini website — manual operator transfer','payload_hash':hashlib.sha256(prompt.encode()).hexdigest(),'people':len(checks),'consented':True,'timestamp':dt.datetime.now(dt.timezone.utc).isoformat(),'palm_images':False});self.window.store.save('reports',self.current,self.current['id']);QApplication.clipboard().setText(prompt)
        row=QHBoxLayout();copy_button=button('Copy reviewed prompt',lambda:safe(self,copy_prompt));copy_button.setEnabled(False);row.addWidget(copy_button)
        for check in checks:check.toggled.connect(lambda _:copy_button.setEnabled(all(item.isChecked() for item in checks)))
        row.addWidget(button('Open Gemini website',lambda:QDesktopServices.openUrl(QUrl('https://gemini.google.com/'))));row.addWidget(button('Close',dialog.accept));layout.addLayout(row);dialog.exec()
    @Slot(str)
    def ai_progress(self,message):
        self.ai_stage=message;self.ai_tick(increment=False)
    def ai_tick(self,increment=True):
        if increment:self.ai_elapsed+=1
        if self.worker and self.worker.isRunning():
            completed=len(self.current.get('ai_sections',{}));total=len(self.current.get('ai_titles',[]))
            self.status.setText(f'{self.ai_stage} | {completed}/{total} sections saved | {self.ai_elapsed}s elapsed. Full report/PDF is assembled after all sections; completed text is in AI live progress.')
        else:self.ai_clock.stop()
    def ai_section(self,index,section,usage):
        if not self.current.get('ai_sections'):self.ai_preview.clear()
        self.ai_preview.appendPlainText(section['title']+'\n'+section['body']+'\n')
        self.current['ai_sections'][str(index)]=section;self.current.setdefault('section_provenance',{})[str(index)]={'provider':self.current['ai_provider'],'model':self.current['ai_model'],'timestamp':dt.datetime.now(dt.timezone.utc).isoformat()};self.current.setdefault('usage',[]).append(usage);self.window.store.save('reports',self.current,self.current['id']);self.progress.setValue(int(100*len(self.current['ai_sections'])/len(self.current['ai_titles'])))
    def ai_failed(self,message):
        self.ai_clock.stop();self.current['last_ai_error']=message;self.ai_preview.appendPlainText('Generation paused: '+message);self.current['status']='AI paused';self.window.store.save('reports',self.current,self.current['id']);self.status.setText(message);self.window.nav.setEnabled(True)
    def ai_complete(self):
        self.ai_clock.stop();self.worker.wait()
        try:
            merged=generation.assemble(self.current);old=self.current['id'];self.current['status']='AI source complete';self.window.store.save('reports',self.current,old)
            import copy
            child=copy.deepcopy(self.current);new=str(uuid.uuid4());child.update(id=new,parent_version=old,version=child['version']+1,status='AI complete — operator review required',edited_text=merged);self.window.store.save('reports',child,new);self.window.store.link(new,[row[0] for row in self.window.store.conn.execute('SELECT client_id FROM links WHERE report_id=?',(old,))]);self.window.nav.setEnabled(True);self.refresh(new)
            if child.get('ai_options',{}).get('auto_pdf'):
                try:
                    folder=Path(child['ai_options'].get('pdf_dir') or self.window.store.folder/'exports');folder.mkdir(parents=True,exist_ok=True);filename=folder/('Astroguru-report-'+new[:8]+'.pdf');reports.export_pdf(child,filename,self.window.config.value('provider','Astroguru'),self.window.config.value('logo','') or None,self.cover_bytes());child['auto_pdf_path']=str(filename.resolve());self.current=child;self.window.store.save('reports',child,new);self.status.setText('Detailed AI report and PDF saved. Review before sharing. PDF: '+str(filename))
                except Exception:self.current['status']='AI complete — PDF export needs retry';self.window.store.save('reports',self.current,new);self.status.setText('Detailed report saved. Automatic PDF export failed; use PDF export to choose another folder.')
            else:self.status.setText('Detailed AI report saved as a new version. Review before export. Actual token usage is recorded; price depends on your provider account.')
            if child.get('artwork_error'):self.status.setText(self.status.text()+' Optional cover artwork was unavailable; calculated charts and text are retained.')
        except Exception as error:self.ai_failed(str(error))
    def cancel_ai(self):
        if self.worker and self.worker.isRunning():self.worker.cancel.set();self.status.setText('Cancellation requested; completed sections are preserved.')

class SettingsPage(QWidget):
    def __init__(self,window):
        super().__init__();self.window=window;l=QVBoxLayout(self);heading(l,'Settings','Secure credentials, branding and encrypted backup. No API key is needed for local calculations or template reports.')
        f=QFormLayout();l.addLayout(f);self.provider_name=QLineEdit(window.config.value('provider','Astroguru'));f.addRow('Service provider name',self.provider_name);self.logo=QLineEdit(window.config.value('logo',''));f.addRow('Provider logo path (optional)',self.logo);l.addWidget(button('Choose logo',self.choose_logo));self.auto_ai=QCheckBox('Default to automatic AI generation on submission');self.auto_ai.setChecked(window.config.value('auto_ai',False,type=bool));f.addRow('',self.auto_ai);self.report_depth=QComboBox();self.report_depth.addItems(['Detailed','Very detailed']);self.report_depth.setCurrentText(window.config.value('report_depth','Very detailed'));f.addRow('Default report depth',self.report_depth);self.export_dir=QLineEdit(window.config.value('export_dir',str(window.store.folder/'exports')));f.addRow('Automatic PDF folder',self.export_dir);self.ai_provider=QComboBox();self.ai_provider.addItems(['OpenAI','Gemini']);self.ai_provider.setCurrentText(window.config.value('ai_provider','OpenAI'));f.addRow('AI provider',self.ai_provider);self.model=QLineEdit();f.addRow('Text model ID (verify access)',self.model);self.image_model=QLineEdit();f.addRow('Optional image model ID',self.image_model);self.key=QLineEdit();self.key.setEchoMode(QLineEdit.Password);self.key.setPlaceholderText('New key — stored in OS credential manager only');f.addRow('API key',self.key);self.ai_provider.currentTextChanged.connect(self.load_model);self.load_model();l.addWidget(button('Save settings / credential',lambda:safe(self,self.save),True));l.addWidget(button('Test connection (no client data)',lambda:safe(self,self.test)))
        setup=QHBoxLayout();setup.addWidget(button('Google account · get Gemini API key',lambda:self.open_api_setup('Gemini')));setup.addWidget(button('OpenAI API keys',lambda:self.open_api_setup('OpenAI')));l.addLayout(setup)
        self.status=QLabel('Gemini API keys are available through Google AI Studio using your Google account. API billing/model access is separate from consumer ChatGPT/Gemini subscriptions. Optional palm transmission requires separate consent at submission.');self.status.setWordWrap(True);l.addWidget(self.status)
        row=QHBoxLayout();row.addWidget(button('Encrypted backup',lambda:safe(self,self.backup)));row.addWidget(button('Restore backup',lambda:safe(self,self.restore)));row.addWidget(button('Lock application',window.lock));l.addLayout(row)
        info=QLabel('Vault: AES-256-GCM encrypted client/report payloads and photographs, password-derived scrypt key. Backups are authenticated and encrypted. Keep your password safe: no recovery backdoor. UUIDs and database structure remain visible. Exported PDFs/PNGs/SVGs are unencrypted; handle them as client documents. Automatic lock after 15 minutes of inactivity.');info.setWordWrap(True);l.addWidget(info);l.addStretch()
    def load_model(self):self.model.setText(self.window.config.value('model_'+self.ai_provider.currentText(),'gpt-4.1' if self.ai_provider.currentText()=='OpenAI' else 'gemini-flash-latest'));self.image_model.setText(self.window.config.value('image_model_'+self.ai_provider.currentText(),'gpt-image-1.5' if self.ai_provider.currentText()=='OpenAI' else 'gemini-3.1-flash-image'));self.key.clear()
    def open_api_setup(self,provider):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl('https://aistudio.google.com/apikey' if provider=='Gemini' else 'https://platform.openai.com/api-keys'))
    def choose_logo(self):
        filename,_=QFileDialog.getOpenFileName(self,'Choose provider logo','','Images (*.png *.jpg *.jpeg)')
        if filename:self.logo.setText(filename)
    def save(self):
        self.window.config.setValue('provider',self.provider_name.text().strip() or 'Astroguru');self.window.config.setValue('logo',self.logo.text());self.window.config.setValue('ai_provider',self.ai_provider.currentText());self.window.config.setValue('model_'+self.ai_provider.currentText(),self.model.text().strip())
        self.window.config.setValue('auto_ai',self.auto_ai.isChecked());self.window.config.setValue('report_depth',self.report_depth.currentText());self.window.config.setValue('image_model_'+self.ai_provider.currentText(),self.image_model.text().strip());self.window.config.setValue('export_dir',self.export_dir.text().strip() or str(self.window.store.folder/'exports'))
        if self.key.text():
            import keyring
            try:keyring.set_password('Astroguru',self.ai_provider.currentText(),self.key.text())
            except Exception:raise ValueError('OS secure credential store unavailable. API key was not saved. On Windows use Credential Manager; on Linux use a supported Secret Service keyring.')
            self.key.clear();self.auto_ai.setChecked(True);self.window.config.setValue('auto_ai',True)
        for reading_options in (self.window.wizard.ai_options,self.window.match_page.ai_options):reading_options.automatic.setChecked(self.auto_ai.isChecked());reading_options.depth.setCurrentText(self.report_depth.currentText())
        self.status.setText('Settings saved. Automatic AI '+('enabled: submit a reading and accept consent to start requests.' if self.auto_ai.isChecked() else 'off: submission creates a local template. Enable automatic generation to call the API.'))
    @Slot(str)
    def connection_result(self,message):
        self.test_watchdog.stop();self.status.setText(message)
        self.connection_dialog=QMessageBox(self);self.connection_dialog.setWindowTitle('Astroguru '+core.VERSION+' — API connection result');self.connection_dialog.setText(message);self.connection_dialog.setInformativeText('A successful connection test does not generate a client report. Open a report, click AI generate / resume, review the data and accept consent. Completed sections appear in AI live progress.');self.connection_dialog.setStandardButtons(QMessageBox.Ok);self.connection_dialog.open()
    def test_slow(self):
        if self.test_worker.isRunning():self.status.setText('Connection test is still waiting after 40 seconds. Check network/firewall/proxy access. A result window will appear when the request finishes; no client data was sent.')
    def test(self):
        self.save();import keyring
        key=keyring.get_password('Astroguru',self.ai_provider.currentText())
        if not key:raise ValueError('No key configured.')
        if getattr(self,'test_worker',None) and self.test_worker.isRunning():return
        class Test(QThread):
            done=Signal(str)
            def __init__(self,provider,model,key,parent):super().__init__(parent);self.provider=Provider(provider,model,key)
            def run(self):
                try:self.provider.test_connection();self.done.emit('Connection successful. A small API request was billed by the provider.')
                except Exception as e:self.done.emit(str(e))
        self.test_worker=Test(self.ai_provider.currentText(),self.model.text(),key,self);self.test_worker.done.connect(self.connection_result);self.test_watchdog=QTimer(self);self.test_watchdog.setSingleShot(True);self.test_watchdog.timeout.connect(self.test_slow);self.test_watchdog.start(40000);self.test_worker.start();self.status.setText('Testing provider with no client information…')
    def backup(self):
        filename,_=QFileDialog.getSaveFileName(self,'Save encrypted backup','Astroguru-backup.agbk','Astroguru backup (*.agbk)')
        if filename:self.window.store.backup(filename);self.status.setText('Encrypted backup saved. Keep the vault password separately and securely.')
    def restore(self):
        if self.window.local_workers_running():raise ValueError('Wait for image processing or birthplace lookup before restoring the vault.')
        filename,_=QFileDialog.getOpenFileName(self,'Restore encrypted backup','','Astroguru backup (*.agbk)')
        if not filename:return
        if QMessageBox.warning(self,'Replace current vault data','Restore replaces current records and photographs. Create a backup first if you need to retain them.',QMessageBox.Ok|QMessageBox.Cancel)!=QMessageBox.Ok:return
        password,ok=QInputDialog.getText(self,'Backup password','Password used when this backup was created:',QLineEdit.Password)
        if ok:self.window.store.restore(filename,password);self.window.refresh_clients();self.window.report_page.refresh();self.window.match_page.refresh();self.window.reset_wizard();self.status.setText('Backup restored and authenticated.')

class MainWindow(QMainWindow):
    def __init__(self,store):
        super().__init__();self.store=store
        from PySide6.QtCore import QSettings
        self.config=QSettings('Astroguru','Astroguru');self.setWindowTitle('Astroguru');self.resize(1300,900);self.setMinimumSize(980,700)
        root=QWidget();self.setCentralWidget(root);layout=QHBoxLayout(root);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
        side=QWidget();side.setObjectName('Sidebar');side.setFixedWidth(224);sl=QVBoxLayout(side);sl.setContentsMargins(16,18,16,20);sl.setSpacing(12)
        brand=QLabel('✦ Astroguru');brand.setObjectName('Brand');sl.addWidget(brand);tagline=QLabel('CONSULTATION STUDIO');tagline.setObjectName('Eyebrow');sl.addWidget(tagline);sl.addSpacing(26)
        self.nav=QListWidget();self.nav.setObjectName('Nav');self.nav.addItems(['Dashboard','Clients','New Reading','Reports','Matchmaking','Settings']);sl.addWidget(self.nav,1)
        sl.addWidget(QLabel('Encrypted local workspace\nVersion '+core.VERSION));sl.addSpacing(8);sl.addWidget(button('Lock workspace',self.lock));layout.addWidget(side)
        workspace=QWidget();wl=QVBoxLayout(workspace);wl.setContentsMargins(0,0,0,0);wl.setSpacing(0);top=QWidget();tl=QHBoxLayout(top);tl.setContentsMargins(28,18,28,14);eyebrow=QLabel('ASTROGURU  /  YOUR WORKSPACE');eyebrow.setObjectName('Eyebrow');tl.addWidget(eyebrow);tl.addStretch();badge=QLabel('●  Local vault protected');badge.setObjectName('VaultBadge');tl.addWidget(badge);wl.addWidget(top)
        self.pages=QStackedWidget();wl.addWidget(self.pages,1);layout.addWidget(workspace,1)
        self.dashboard=QWidget();self.dash_l=QVBoxLayout(self.dashboard);self.dash_l.setContentsMargins(28,20,28,28);self.dash_l.setSpacing(22)
        title=QHBoxLayout();heading(self.dash_l,'Your consultation studio','A calm workspace for thoughtful readings and meaningful conversations.')
        hero=QFrame();hero.setObjectName('Hero');hl=QVBoxLayout(hero);hl.setContentsMargins(32,30,32,30);hl.setSpacing(14);small=QLabel('A NEW PERSPECTIVE, ONE READING AT A TIME');small.setObjectName('Eyebrow');hl.addWidget(small);headline=QLabel('Chart the sky.\nKeep the person at the center.');headline.setObjectName('HeroTitle');hl.addWidget(headline);description=QLabel('Bring birth details, optional palm observations and clear calculations\ntogether in an editable, professionally formatted report.');description.setObjectName('Subtitle');hl.addWidget(description);cta=QHBoxLayout();cta.addWidget(button('＋  Create a reading',lambda:self.nav.setCurrentRow(2),True));cta.addWidget(button('Open client records',lambda:self.nav.setCurrentRow(1)));cta.addStretch();hl.addLayout(cta);self.dash_l.addWidget(hero)
        stats=QHBoxLayout();self.client_stat=QLabel();self.report_stat=QLabel()
        for value,label,detail in [(self.client_stat,'Client records','Saved in your encrypted vault'),(self.report_stat,'Report versions','Originals and operator revisions')]:
            card=QFrame();card.setObjectName('Card');cl=QVBoxLayout(card);cl.setContentsMargins(24,20,24,20);value.setObjectName('StatValue');cl.addWidget(value);name=QLabel(label);name.setObjectName('SectionTitle');cl.addWidget(name);hint=QLabel(detail);hint.setObjectName('Subtitle');cl.addWidget(hint);stats.addWidget(card)
        self.dash_l.addLayout(stats);row=QHBoxLayout()
        for title,description,label,action in [('Matchmaking','Two profiles, side-by-side charts and a transparent traditional score.','Start a comparison →',lambda:self.nav.setCurrentRow(4)),('Your reports','Review saved readings, refine the text and export a polished PDF.','Explore reports →',lambda:self.nav.setCurrentRow(3))]:
            card=QFrame();card.setObjectName('Card');cl=QVBoxLayout(card);cl.setContentsMargins(24,22,24,22);name=QLabel(title);name.setObjectName('SectionTitle');cl.addWidget(name);desc=QLabel(description);desc.setWordWrap(True);desc.setObjectName('Subtitle');cl.addWidget(desc);cl.addSpacing(8);cl.addWidget(button(label,action));row.addWidget(card)
        self.dash_l.addLayout(row);self.counts=QLabel();self.counts.setObjectName('Counts');self.dash_l.addWidget(self.counts);self.dash_l.addStretch();self.pages.addWidget(self.dashboard)
        clients=QWidget();cl=QVBoxLayout(clients);cl.setContentsMargins(28,24,28,24);cl.setSpacing(16);heading(cl,'Clients','Search encrypted local records. Matchmaking reports are linked to both people.');self.search=QLineEdit();self.search.setPlaceholderText('Search name, birthplace or notes');self.search.textChanged.connect(self.refresh_clients);cl.addWidget(self.search);self.client_list=QListWidget();self.client_list.itemDoubleClicked.connect(lambda:self.edit_selected());cl.addWidget(self.client_list,1);row=QHBoxLayout()
        for label,action in [('Add client',lambda:self.edit_client()),('Edit selected',self.edit_selected),('Open linked reports',self.client_reports),('Export client JSON',self.export_client),('Delete client',self.delete_client)]:row.addWidget(button(label,lambda checked=False,f=action:safe(self,f)))
        cl.addLayout(row);self.pages.addWidget(clients)
        self.wizard=Wizard(self);self.pages.addWidget(self.wizard);self.report_page=ReportPage(self);self.pages.addWidget(self.report_page);self.match_page=MatchPage(self);match_scroll=QScrollArea();match_scroll.setWidgetResizable(True);match_scroll.setFrameShape(QFrame.NoFrame);match_scroll.setWidget(self.match_page);self.pages.addWidget(match_scroll);self.settings_page=SettingsPage(self);settings_scroll=QScrollArea();settings_scroll.setWidgetResizable(True);settings_scroll.setFrameShape(QFrame.NoFrame);settings_scroll.setWidget(self.settings_page);self.pages.addWidget(settings_scroll);self.nav.currentRowChanged.connect(self.navigate);self.nav.setCurrentRow(0);self.refresh_clients()
        self.idle=QTimer(self);self.idle.setSingleShot(True);self.idle.setInterval(15*60*1000);self.idle.timeout.connect(self.lock);self.idle.start();QApplication.instance().installEventFilter(self)
    def eventFilter(self,obj,event):
        if event.type() in [QEvent.KeyPress,QEvent.MouseButtonPress,QEvent.MouseMove,QEvent.Wheel]:self.idle.start()
        return False
    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        if index==3:self.report_page.refresh()
        if index==4:self.match_page.refresh()
        self.refresh_counts()
    def refresh_counts(self):
        clients=len(self.store.all('clients'));saved=len(self.store.all('reports'));self.client_stat.setText(str(clients));self.report_stat.setText(str(saved));self.counts.setText('Offline calculations available · API explanations are optional · Interpretations are traditional reflections')
    def refresh_clients(self,*args):
        text=self.search.text().casefold();self.client_list.clear()
        for key,p in self.store.all('clients'):
            if text and text not in (p['first_name']+' '+p.get('last_name','')+' '+p.get('city','')+' '+p.get('notes','')).casefold():continue
            item=QListWidgetItem(p['first_name']+' '+p.get('last_name','')+'\n'+p.get('city','')+' · '+p['accuracy']+' birth time · '+key[:8]);item.setData(Qt.UserRole,key);self.client_list.addItem(item)
        if hasattr(self,'counts'):self.refresh_counts()
    def selected_client(self):
        item=self.client_list.currentItem()
        if not item:raise ValueError('Select a client.')
        return item.data(Qt.UserRole)
    def edit_client(self,key=None):
        dialog=QDialog(self);dialog.setWindowTitle('Edit client' if key else 'New client');dialog.resize(760,800);l=QVBoxLayout(dialog);form=ProfileForm(self.store.get('clients',key) if key else None);l.addWidget(form);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);l.addWidget(buttons);result={'key':None}
        def save():
            def work():
                p=form.checked()
                if not key and self.store.duplicates(p) and QMessageBox.question(dialog,'Possible duplicate','Matching name and birth date found. Save another record?')!=QMessageBox.Yes:return
                result['key']=self.store.save('clients',p,key);dialog.accept()
            safe(dialog,work)
        buttons.button(QDialogButtonBox.Save).setEnabled(form.stack.currentIndex()==4);form.page_changed.connect(lambda index:buttons.button(QDialogButtonBox.Save).setEnabled(index==4));buttons.accepted.connect(save);buttons.rejected.connect(dialog.reject);dialog.exec();self.refresh_clients();return result['key']
    def edit_selected(self):return self.edit_client(self.selected_client())
    def client_reports(self):
        links=self.store.linked_reports(self.selected_client())
        if not links:QMessageBox.information(self,'Reports','No saved reports linked to this client.');return
        choices=[self.store.get('reports',key)['title']+' · '+key[:8] for key in links];chosen,ok=QInputDialog.getItem(self,'Client reports','Choose report',choices,0,False)
        if ok:self.nav.setCurrentRow(3);self.open_report(links[choices.index(chosen)])
    def export_client(self):
        key=self.selected_client();filename,_=QFileDialog.getSaveFileName(self,'Export client (unencrypted)','Astroguru-client-'+key[:8]+'.json','JSON (*.json)')
        if filename:Path(filename).write_text(json.dumps(self.store.get('clients',key),ensure_ascii=False,indent=2),encoding='utf-8')
    def delete_client(self):
        if self.local_workers_running():raise ValueError('Wait for image processing or birthplace lookup before deleting a client.')
        key=self.selected_client()
        if QMessageBox.warning(self,'Delete client','Permanently delete this client, photographs and all linked reports, including matchmaking reports containing their details?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:self.store.delete_client(key);self.refresh_clients();self.report_page.refresh();self.match_page.refresh();self.reset_wizard()
    def reset_wizard(self):
        if self.local_workers_running():raise ValueError('Wait for image processing or birthplace lookup before restarting the reading.')
        old=self.wizard;self.pages.removeWidget(old);old.deleteLater();self.wizard=Wizard(self);self.pages.insertWidget(2,self.wizard)
    def open_report(self,key):self.report_page.refresh(key)
    def local_workers_running(self):
        return any(thread.isRunning() for thread in QApplication.instance().findChildren(QThread) if thread is not self.report_page.worker and thread is not getattr(self.settings_page,'test_worker',None))
    def lock(self):
        if self.local_workers_running():self.idle.start(30000);return
        if self.report_page.worker and self.report_page.worker.isRunning():self.report_page.cancel_ai();self.report_page.status.setText('Lock requested. Cancelling generation first; lock again when the active request ends.');self.idle.start(65000);return
        if getattr(self.settings_page,'test_worker',None) and self.settings_page.test_worker.isRunning():self.idle.start(65000);return
        self.hide();self.store.prune_assets();self.store.close();QApplication.instance().exit(42)
    def closeEvent(self,event):
        if self.local_workers_running():event.ignore();QMessageBox.information(self,'Finishing local work','Please wait for image processing or birthplace lookup to finish before closing.');return
        if self.report_page.worker and self.report_page.worker.isRunning():self.report_page.cancel_ai();event.ignore();QMessageBox.information(self,'Generation cancelling','Cancellation requested. Close again after the active request ends (up to 60 seconds).');return
        if getattr(self.settings_page,'test_worker',None) and self.settings_page.test_worker.isRunning():event.ignore();return
        super().closeEvent(event)

def main():
    if '--self-test' in sys.argv:os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    app=QApplication(sys.argv);app.setApplicationName('Astroguru');app.setOrganizationName('Astroguru');app.setStyle('Fusion');app.setStyleSheet(STYLE)
    if '--self-test' in sys.argv:
        from smokecheck import run
        return run(app)
    folder=Path(os.environ.get('ASTROGURU_DATA_DIR') or QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation))
    while True:
        exists=(folder/'astroguru.db').exists();password,ok=QInputDialog.getText(None,'Unlock Astroguru' if exists else 'Create encrypted Astroguru vault','Vault password:' if exists else 'Choose a password (at least 10 characters). Store it safely — no recovery backdoor.',QLineEdit.Password)
        if not ok:return 0
        try:store=Store(folder,password)
        except Exception as e:QMessageBox.warning(None,'Vault unavailable',str(e));continue
        password=None;window=MainWindow(store);window.show();code=app.exec();app.removeEventFilter(window)
        if code!=42:store.prune_assets();store.close();return code
        window.deleteLater();app.processEvents()

if __name__=='__main__':sys.exit(main())
