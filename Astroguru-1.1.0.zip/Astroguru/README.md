# Astroguru 1.1.0

A runnable local desktop application for client records, palm review, deterministic astrology/numerology, Kundali charts, matchmaking and versioned reports. Python 3.12 + maintained Qt/PySide6; local SQLite with encrypted payloads and photographs; Swiss Ephemeris calculations; ReportLab vector PDF export. No browser server or AI key is required for the local workflow.

## Update from an earlier version

Close Astroguru, make an encrypted backup in Settings, then extract this update into a **new folder** and run `Start-Astroguru.cmd`. Use your existing vault password. The default data location and vault format are unchanged, so existing clients/reports are retained. If you use `ASTROGURU_DATA_DIR`, keep its same value. Do not delete or replace your vault folder.

## What changed in 1.1.0

- Modern studio dashboard, dark sidebar, spacious cards and a ten-step reading workflow.
- Five separate client-information pages, then client-right palm and client-left palm on separate pages.
- Rectangular palm alignment with uniform scaling and no mirroring or hand silhouette.
- Optional local plain-background removal, tolerance control, preview and original-background restoration. Original files remain preserved; review fingers and wrist manually.
- Offline city selection fills country, coordinates and a suggested timezone. Same-name cities require explicit selection; manual correction remains available.

## Run locally

Windows 10/11 x64: install **CPython 3.12 x64**, extract this folder, then double-click **Start-Astroguru.cmd**. The first launch installs dependencies in a project-local `.venv`. Alternatively:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app.py
```

Linux (tested with CPython 3.12):

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

Linux may need Qt's XCB system libraries (`libxcb-cursor0`, `libxkbcommon-x11-0`, plus a desktop display). A source build of pyswisseph needs GCC/G++ and Python development headers if a platform wheel is unavailable. In this Linux environment the interpreter's compiler setting referenced missing clang; `CC=gcc CXX=g++` resolved this. That setting is not required for Windows wheels.

On first launch create a vault password of at least ten characters. There is no recovery backdoor. Default data location is Qt `AppLocalDataLocation` (typically `%LOCALAPPDATA%\Astroguru\Astroguru` on Windows); `ASTROGURU_DATA_DIR` overrides it for a deployment or test. Never point this at a shared unprotected directory.

## Build the Windows executable and installer

Windows builds cannot be produced by the supplied Linux environment. No Windows executable or installer is claimed to be built or tested here.

1. On Windows x64 install CPython 3.12 x64 and **Inno Setup 6**.
2. Extract the complete source directory to a writable local folder.
3. In PowerShell run `powershell -ExecutionPolicy Bypass -File .\build-windows.ps1`.
4. The script installs pinned dependencies, runs tests, and builds `dist\Astroguru\Astroguru.exe` using `Astroguru.spec`.
5. It then creates `windows-delivery\Astroguru-Setup.exe` using `Astroguru.iss`.
6. Distribute the installer, or the **entire** `dist\Astroguru` folder for portable use; the EXE alone is insufficient.
7. Test installation, launch, Credential Manager, a real print driver, SVG/PNG/PDF export, backup/restore and uninstall on a clean Windows machine before commercial rollout. Authenticode signing is optional and requires your signing certificate; this build is unsigned.

The installer is per-user and does not need administrator permission. Uninstall intentionally preserves the client vault; deleting records or deleting the vault is a separate operator action. Corresponding source, license, dependency and build files are included under the bundle's `_internal/source` directory. Qt is dynamically loaded; do not remove license notices or prevent lawful library replacement.

## Test

```sh
python -m pip install -r requirements-dev.txt
QT_QPA_PLATFORM=offscreen python -m pytest -q
```

PowerShell: `$env:QT_QPA_PLATFORM='offscreen'; .venv\Scripts\python.exe -m pytest -q`.

Read **OPERATOR-GUIDE.md**, **RULES.md**, **LICENSING.md**, **LIMITATIONS.md** and **VERIFICATION.md** before using real client records.

## External services and credentials

- **OpenAI / Gemini:** optional API credentials stored only in the OS credential manager. Configure provider/model in Settings; model availability is account-dependent. Explicit consent from each person is required for every generation/resumption. The exact minimized payload is shown. Live requests have not been tested without credentials. The network configuration in this build environment does not allow their API hosts.
- **Offline birthplace search:** geonamescache/GeoNames CC BY 4.0 city/country data, approximately 34,000 cities at the 15,000 population threshold. Selecting a city fills its country; small towns may need manual entry or optional online lookup. No API key, geolocation or internet is needed. Confirm historical timezone/DST and location.
- **OpenStreetMap Nominatim:** optional, user-triggered birthplace lookup, sending only the city/state/country query. No API key required for the public endpoint. Follow public service limits and attribution; this desktop client makes one lookup per explicit action. Network lookup was unavailable for a live test here. Coordinates and historical timezone remain operator-verifiable and editable; manual entry works offline.
- **Swiss Ephemeris:** local built-in Moshier ephemeris, no calculation-service account. This source release is AGPL-3.0-or-later. A proprietary distribution requires resolving both Swiss Ephemeris and PyJHora-table copyleft licensing; purchasing an ephemeris license alone does not relicense the reference tables.
- No AI image generation, cloud storage, telemetry, automatic palm-anatomy detection or AI palm-image transmission is used.
