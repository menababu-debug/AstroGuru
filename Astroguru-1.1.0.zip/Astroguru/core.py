"""Astroguru deterministic domain engine. AGPL-3.0-or-later."""
from __future__ import annotations
import calendar, datetime as dt, math, unicodedata
from zoneinfo import ZoneInfo
import swisseph as swe
VERSION='1.1.0'
SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
HINDI=['मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुला','वृश्चिक','धनु','मकर','कुंभ','मीन']
NAKSHATRAS=['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','Purva Phalguni','Uttara Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','Purva Ashadha','Uttara Ashadha','Shravana','Dhanishtha','Shatabhisha','Purva Bhadrapada','Uttara Bhadrapada','Revati']
PLANETS={'Sun':swe.SUN,'Moon':swe.MOON,'Mercury':swe.MERCURY,'Venus':swe.VENUS,'Mars':swe.MARS,'Jupiter':swe.JUPITER,'Saturn':swe.SATURN,'Rahu':swe.MEAN_NODE}
ABBR={'Sun':'Su','Moon':'Mo','Mercury':'Me','Venus':'Ve','Mars':'Ma','Jupiter':'Ju','Saturn':'Sa','Rahu':'Ra','Ketu':'Ke'}
AYANAMSAS={'Lahiri':swe.SIDM_LAHIRI,'Raman':swe.SIDM_RAMAN,'Krishnamurti':swe.SIDM_KRISHNAMURTI}
DASHA_LORDS=['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury']
DASHA_YEARS=[7,20,6,10,7,18,16,19,17]

def anniversary(date,year):
    # Feb 29 birthdays and calendar additions use Feb 28 in non-leap years.
    return date.replace(year=year,day=min(date.day,calendar.monthrange(year,date.month)[1]))

def age(birth,asof):
    if asof<birth: raise ValueError('As-of date cannot precede birth.')
    return asof.year-birth.year-(asof<anniversary(birth,asof.year))

def lookback(years):
    for upper,span in [(26,5),(30,10),(35,12),(40,15),(45,25),(49,27),(9999,30)]:
        if years<=upper:return span

def ranges(start,end):
    if end<start:return []
    return [{'start':str(max(start,dt.date(y,1,1))),'end':str(min(end,dt.date(y,12,31))),'year':y} for y in range(start.year,end.year+1)]

def horizons(birth,asof):
    years=age(birth,asof)
    start=max(birth,anniversary(asof,asof.year-lookback(years)))
    end=min(anniversary(asof,asof.year+35),anniversary(birth,birth.year+70))
    return {'age':years,'lookback':lookback(years),'history':ranges(start,asof),'future':ranges(asof+dt.timedelta(days=1),end),'future_end':str(end),'future_ended':end<=asof,'leap_policy':'February 28 in non-leap years'}

def validate(profile,asof=None):
    birth=dt.date.fromisoformat(profile['birth_date']); today=dt.date.today()
    if birth>today:raise ValueError('Future birth dates are not accepted.')
    if asof and dt.date.fromisoformat(asof)<birth:raise ValueError('As-of date cannot precede birth.')
    if not profile.get('first_name','').strip():raise ValueError('Birth first name is required.')
    if profile.get('accuracy') not in ['exact','approximate','unknown']:raise ValueError('Select birth-time accuracy.')
    if not -90<=float(profile['latitude'])<=90 or not -180<=float(profile['longitude'])<=180:raise ValueError('Invalid coordinates.')
    ZoneInfo(profile['timezone'])
    if profile['accuracy']!='unknown':dt.time.fromisoformat(profile['birth_time'])
    if profile['accuracy']=='approximate' and not 1<=int(profile.get('uncertainty_minutes',60))<=720:raise ValueError('Uncertainty must be 1–720 minutes.')
    return birth

def utc_time(profile,time=None):
    local=dt.datetime.fromisoformat(profile['birth_date']+'T'+(time or profile['birth_time']))
    zone=ZoneInfo(profile['timezone']); fold=int(profile.get('fold',0))
    aware=local.replace(tzinfo=zone,fold=fold)
    if aware.astimezone(dt.timezone.utc).astimezone(zone).replace(tzinfo=None)!=local:raise ValueError('Birth time does not exist during this DST transition. Correct the time.')
    ambiguous=local.replace(tzinfo=zone,fold=0).utcoffset()!=local.replace(tzinfo=zone,fold=1).utcoffset()
    if ambiguous and not profile.get('fold_confirmed'):raise ValueError('Ambiguous DST time: confirm first or second occurrence.')
    return aware.astimezone(dt.timezone.utc)

def jd(when):return swe.julday(when.year,when.month,when.day,when.hour+when.minute/60+when.second/3600)

def placement(lon,speed=0):
    lon=lon%360; n=int(lon/(360/27))
    return {'longitude':round(lon,7),'sign':int(lon/30),'degree':round(lon%30,5),'nakshatra':NAKSHATRAS[n],'nakshatra_index':n,'pada':int((lon%(360/27))/(360/108))+1,'retrograde':speed<0,'speed':round(speed,7),'navamsha_sign':int(lon/(10/3))%12}

def positions(when,settings):
    swe.set_sid_mode(AYANAMSAS[settings.get('ayanamsa','Lahiri')]); day=jd(when)
    flags=swe.FLG_MOSEPH|swe.FLG_SPEED
    tropical={};vedic={}
    for name,p in PLANETS.items():
        values,returned=swe.calc_ut(day,p,flags)
        tropical[name]=placement(values[0],values[3])
        values,returned=swe.calc_ut(day,p,flags|swe.FLG_SIDEREAL)
        vedic[name]=placement(values[0],values[3])
    for table in (vedic,tropical):table['Ketu']=placement(table['Rahu']['longitude']+180,table['Rahu']['speed'])
    return vedic,tropical

def aspects(table,other=None):
    out=[]; other=other or table
    for i,(a,x) in enumerate(table.items()):
        for j,(b,y) in enumerate(other.items()):
            if a in ['Rahu','Ketu'] or b in ['Rahu','Ketu'] or (other is table and j<=i):continue
            delta=abs((x['longitude']-y['longitude']+180)%360-180)
            for angle,label in [(0,'Conjunction'),(60,'Sextile'),(90,'Square'),(120,'Trine'),(180,'Opposition')]:
                if abs(delta-angle)<=6:out.append({'a':a,'b':b,'aspect':label,'angle':round(delta,3),'orb':round(abs(delta-angle),3)})
    return out

def moon_category(moon):
    sign=moon['sign'];degree=moon['degree']
    if sign in [0,1] or (sign==8 and degree>=15) or (sign==9 and degree<15):return 0
    if sign in [2,5,6,10] or (sign==8 and degree<15):return 1
    if sign in [3,11] or sign==9:return 2
    return 3 if sign==4 else 4

def stable_moon(samples):
    moons=[p['Moon'] for p in samples]
    signatures={(p['sign'],p['nakshatra_index'],moon_category(p)) for p in moons}
    if len(signatures)==1:
        sign,nak,category=next(iter(signatures));return {'sign':sign,'nakshatra_index':nak,'vashya_category':category}
    return None

def annual_context(h,settings):
    # Transits are sampled at the midpoint of each covered date range, not event dates.
    out={}
    for kind in ['history','future']:
        out[kind]=[]
        for interval in h[kind]:
            start=dt.date.fromisoformat(interval['start']);end=dt.date.fromisoformat(interval['end']);mid=start+(end-start)//2
            vedic,tropical=positions(dt.datetime.combine(mid,dt.time(12),dt.timezone.utc),settings)
            out[kind].append({'year':interval['year'],'sample_date':str(mid),'sidereal':{name:vedic[name] for name in ['Jupiter','Saturn']},'tropical':{name:tropical[name] for name in ['Jupiter','Saturn']},'basis':'Mid-interval transits at 12:00 UTC; broad symbolic context, not a guaranteed event date.'})
    return out

def yogas(vedic):
    return [
        {'name':'Budha Aditya (baseline)','present':vedic['Sun']['sign']==vedic['Mercury']['sign'],'rule':'Sidereal Sun and Mercury in the same sign; strength, combustion and dignity exceptions not assessed.','meaning':'Traditional reflection on learning and self-expression; not proof of intelligence or success.'},
        {'name':'Gajakesari (baseline)','present':(vedic['Jupiter']['sign']-vedic['Moon']['sign'])%12 in [0,3,6,9],'rule':'Jupiter in the 1st, 4th, 7th or 10th Whole Sign position from the Moon; no strength or cancellation rules applied.','meaning':'Traditional reflection on perspective, support and learning; no promised status or wealth.'}
    ]

def calculate(profile,settings):
    birth=validate(profile,settings['as_of']); unknown=profile['accuracy']=='unknown'
    result={'engine':'Swiss Ephemeris '+swe.version,'backend':'Built-in Moshier ephemeris (no downloaded ephemeris files)','version':VERSION,'settings':dict(settings),'profile':dict(profile),'calculated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'horizons':horizons(birth,dt.date.fromisoformat(settings['as_of'])),'accuracy':profile['accuracy'],'warnings':[]}
    result['annual_transits']=annual_context(result['horizons'],settings)
    if unknown:
        start=dt.datetime.combine(birth,dt.time.min,ZoneInfo(profile['timezone'])).astimezone(dt.timezone.utc)
        end=dt.datetime.combine(birth+dt.timedelta(days=1),dt.time.min,ZoneInfo(profile['timezone'])).astimezone(dt.timezone.utc)
        if end<=start:raise ValueError('This local civil birth date does not exist in the selected historical timezone. Verify birthplace/date/zone.')
        samples=[positions(start+(end-start)*i/96,settings) for i in range(97)]
        result['available_ranges']={name:{'signs':sorted({p[0][name]['sign'] for p in samples}),'nakshatras':sorted({p[0][name]['nakshatra'] for p in samples}),'longitude_start':samples[0][0][name]['longitude'],'longitude_end':samples[-1][0][name]['longitude']} for name in PLANETS}
        result['vedic']={};result['tropical']={};result['ascendant']=None;result['d9_allowed']=False;result['dashas']=[]
        result['matching_moon']=stable_moon([p[0] for p in samples]);result['moon_stable']=result['matching_moon'] is not None
        result['numerology']=numerology(profile,dt.date.fromisoformat(settings['as_of']).year)
        result['warnings']=['Birth time unknown. No precise natal chart, degrees, houses, ascendant, D9, or dasha timing is displayed. Sign and nakshatra possibilities are sampled across the full local birth date at 15-minute intervals; boundary cases require confirmation.']
        return result
    when=utc_time(profile);vedic,tropical=positions(when,settings)
    ayan=swe.get_ayanamsa_ex_ut(jd(when),swe.FLG_MOSEPH)[1]; cusps,angles=swe.houses_ex(jd(when),float(profile['latitude']),float(profile['longitude']),b'W',swe.FLG_SIDEREAL)
    asc=placement(angles[0])
    western_system=settings.get('western_house_system','P')
    try:western_cusps,western_angles=swe.houses_ex(jd(when),float(profile['latitude']),float(profile['longitude']),western_system.encode())
    except swe.Error:raise ValueError('Selected Western house system is undefined at this latitude. Select Whole Sign or Equal.')
    for p in vedic.values():p['house']=(p['sign']-asc['sign'])%12+1
    result.update(utc=when.isoformat(),utc_offset=str(dt.datetime.fromisoformat(profile['birth_date']+'T'+profile['birth_time']).replace(tzinfo=ZoneInfo(profile['timezone']),fold=int(profile.get('fold',0))).utcoffset()),ayanamsa_degrees=ayan,vedic=vedic,tropical=tropical,ascendant=asc,western_cusps=list(western_cusps),western_aspects=aspects(tropical),d9_allowed=profile['accuracy']=='exact',dashas=vimshottari(vedic['Moon']['longitude'],when),transits=positions(dt.datetime.combine(dt.date.fromisoformat(settings['as_of']),dt.time(12),dt.timezone.utc),settings)[0])
    if profile['accuracy']=='approximate':
        uncertainty=int(profile.get('uncertainty_minutes',60));count=max(2,math.ceil(2*uncertainty/15));ends=[positions(when+dt.timedelta(minutes=-uncertainty+2*uncertainty*i/count),settings)[0] for i in range(count+1)]
        result['warnings'].append(f'Approximate birth time ±{uncertainty} minutes. Houses and ascendant are provisional; D9 and precise dasha dates are withheld.')
        result['d9_allowed']=False;result['dashas']=[]
        result['matching_moon']=stable_moon(ends);result['moon_stable']=result['matching_moon'] is not None
    else:result['moon_stable']=True;result['matching_moon']=vedic['Moon']
    result['yogas']=yogas(vedic)
    result['western_transits']=positions(dt.datetime.combine(dt.date.fromisoformat(settings['as_of']),dt.time(12),dt.timezone.utc),settings)[1]
    result['numerology']=numerology(profile,dt.date.fromisoformat(settings['as_of']).year)
    return result

def vimshottari(moon,when):
    index=int(moon/(360/27))%9;fraction=(moon%(360/27))/(360/27)
    start=when-dt.timedelta(days=fraction*DASHA_YEARS[index]*365.2425);out=[]
    for cycle in range(10):
        lord=(index+cycle)%9;end=start+dt.timedelta(days=DASHA_YEARS[lord]*365.2425)
        subs=[];substart=start
        for k in range(9):
            sub=(lord+k)%9;subend=substart+dt.timedelta(days=DASHA_YEARS[lord]*DASHA_YEARS[sub]/120*365.2425)
            subs.append({'lord':DASHA_LORDS[sub],'start':substart.isoformat(),'end':subend.isoformat()});substart=subend
        out.append({'lord':DASHA_LORDS[lord],'start':start.isoformat(),'end':end.isoformat(),'antardashas':subs});start=end
    return out

def reduce_number(n,masters=True):
    steps=[n]
    while n>9 and not (masters and n in [11,22,33]):n=sum(map(int,str(n)));steps.append(n)
    return {'total':steps[0],'steps':steps,'number':n}

def spelling(text):return ''.join(c for c in unicodedata.normalize('NFKD',text).upper() if 'A'<=c<='Z')

def name_numbers(text):
    clean=spelling(text)
    if not clean:return {'spelling':'','available':False,'mapping':[],'reason':'Name numbers withheld. Supply a reviewed Latin spelling.'}
    vals=[(ord(c)-65)%9+1 for c in clean]
    return {'spelling':clean,'mapping':list(zip(clean,vals)),'Expression':reduce_number(sum(vals)),'Soul Urge':reduce_number(sum(v for c,v in zip(clean,vals) if c in 'AEIOU')),'Personality':reduce_number(sum(v for c,v in zip(clean,vals) if c not in 'AEIOU'))}

def numerology(profile,year):
    date=dt.date.fromisoformat(profile['birth_date'])
    return {'system':'Pythagorean; digit-sum date method; master numbers 11/22/33 retained at final reduction; Y is consonant; accents decomposed, spaces/punctuation omitted, non-Latin spelling requires reviewed Latin transliteration','Life Path':reduce_number(sum(map(int,date.strftime('%Y%m%d')))),'Birthday':reduce_number(date.day),'Personal Year':reduce_number(sum(map(int,f'{date.month}{date.day}{year}')),False),'birth_name':name_numbers(profile.get('numerology_birth_spelling') or profile['first_name']+' '+profile.get('last_name','')),'current_name':name_numbers(profile.get('numerology_current_spelling') or profile['current_name']) if profile.get('current_name') else None}

def manglik(chart):
    rule='Baseline Whole Sign Mars in houses 1, 2, 4, 7, 8, 12 from sidereal ascendant; no cancellation rules applied.'
    if not chart.get('ascendant') or chart['accuracy']!='exact':return {'available':False,'rule':rule,'explanation':'Confirmed birth time required for this assessment.'}
    house=chart['vedic']['Mars']['house'];return {'available':True,'present':house in [1,2,4,7,8,12],'house':house,'rule':rule,'explanation':'A traditional classification, not evidence of danger, harm to a spouse, or relationship failure.'}
