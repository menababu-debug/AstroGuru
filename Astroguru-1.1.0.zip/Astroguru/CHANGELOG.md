# Astroguru 1.1.0

Updated intake and desktop styling. Separate right/left palm pages with explicit client-hand labels; rectangular clipping and no mirroring; local background removal with tolerance, preview, restoration and preserved original; ten-step wizard and five-page client editor; automatic country from offline city selection, with manual correction and historical timezone verification.

Vault encryption/format and data location remain compatible with 1.0.0. Existing photos are not silently swapped. Original generated report versions remain preserved. Windows binary compilation and real-printer testing are still unverified in this Linux environment.
